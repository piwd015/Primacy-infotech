<!DOCTYPE html>
<html lang="en">






<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<title>Best Digital Marketing and SEO Company in India</title>

	<meta name="description" content="Primacy Infotech is one of the best digital marketing and seo companies in India. Call us on 9088015866 to get your website in affordable prices." />

	<meta name="keywords" content="Best Digital Marketing company in India, Digital Marketing company in Kolkata, SEO development company in Kolkata, Seo company in India " />

	<meta name="robots" content="index, follow">

	<meta name="language" content="EN">

	<meta name="organization" content="Primacy Infotech">

	<link rel="canonical" href="../index.php">

	<meta property="og:locale" content="en_US">

	<meta property="og:type" content="website">

	<meta property="og:title" content="Primacy Infitech Best website development company in kolkata">

	<meta property="og:description" content="Primacy Infotech- It is a website design and development company based in kolkata. We help small and mid sized company to achieve thier marketing goals. Call today - 9088015866">

	<meta property="og:image" content="assets/images/logo-p.png">

	<meta property="og:url" content="index.html">

	<meta property="og:site_name" content="Primacy Infotech">

	<meta name="format-detection" content="telephone=no">


    <?php include '../include/header.php'; ?>






    <!--end fixed header-->
	<!-- header -->

	


	<section class="home-5-banner bg-img main-banner" id="banner">

		<div class="container">

			<div class="row align-items-center">

				<div class="col-lg-6 col-md-7">

					<div class="banner-content">

						<div class="">

							<h2 class="title wow fadeInUp" data-wow-duration=".65s"  data-wow-delay=".1s">Improve Your Website Ranking On <span class="logo-color">GOOGLE SEARCH ENGINE</span></h2>

						</div>

						<div class="">

							<span class="sub-title text-black wow fadeInUp" data-wow-duration=".65s" data-wow-delay=".3s">In order to improve the rankings of the website on Google, certain measures are taken by our company. The package of Digital Marketing starts from Rs 9,999. If you want to contact us, we are just a call away.   <span class="logo-color-red">RS 9,999/-</span></span>

						</div>

						<div class="btn-wrapper">

							<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal" href="#" style="color: #000">Get Started <i class="icon-layers"></i></button>

							 <button type="button" class="btn custom-btn mb" data-toggle="modal" data-target="#callback"href="#" style="color: #000"><i class="icon-phone"></i> Call Back Request</button>

						</div>

					</div>

				</div>

				<div class="col-lg-6 col-md-5">

					<div class="banner-content">

						<img src="../assets/images/seo.gif" class="img-fluid" alt="seo">

<!--

						<div class="video-play">

							<a href="https://www.youtube.com/embed/0CAQtl11vQY" data-rel="lightbox-popup"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="20px">

							<path fill-rule="evenodd"  fill="rgb(255, 255, 255)" d="M-0.001,1.104 C-0.001,2.027 -0.001,18.234 -0.001,18.872 C-0.001,19.698 0.872,20.312 1.734,19.829 C2.425,19.442 13.233,11.631 14.411,10.962 C15.185,10.523 15.172,9.478 14.411,9.038 C13.563,8.548 2.702,0.697 1.699,0.152 C0.964,-0.247 -0.001,0.194 -0.001,1.104 Z"/></svg></a>

						</div>

-->

					</div>

				</div>

			</div>

		</div>

	</section><!-- banner -->

	

		<section class="feature">

		<div class="container">

				<div class="s-title">

					<h2><span class="logo-color">W</span>HY CHOOSE US?</h2>

<!--				<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->

			</div>

			<div class="row justify-content-center">

				<div class="col-lg-4">

					<div class="icon-box style-boxed">

						<div class="icon-box-icon">

							<i class="icofont-lens"></i>

						</div>

						<div class="icon-box-details">

				

							<h3 class="icon-box-title">INCREASE BRAND AWARENESS

</h3>

							<p>•	Brand awareness which is at peak: this is very much true that majority of people use social media platforms like facebook, youtube, twitter, instagram etc. We promote our brand through social media networking and create an awareness for the targeted customers.  </p>

						</div>

					</div>

				</div>

				<div class="col-lg-4">

					<div class="icon-box style-boxed">

						<div class="icon-box-icon">

				<i class="icofont-dashboard-web"></i>

						</div>

						<div class="icon-box-details">

							<h3 class="icon-box-title">INTERACTIVE DISPLAY OF PRODUCTS

</h3>

							<p>•	Interactive and displaying products :Most of the people get in touch with social media websites for getting information, we present the products put some of the questions that are related to questions in a way that the customers find it totally fun. The products are discussed as well as promoted in this way. 



</p>

						</div>

					</div>

				</div>

				<div class="col-lg-4">

					<div class="icon-box style-boxed">

						<div class="icon-box-icon">

							<i class="icofont-eye-alt"></i>

						</div>

						<div class="icon-box-details">

							<h3 class="icon-box-title">SPY ON COMPETITORS</h3>

							<p>•	A watch on competitors : Our digital marketers  follow the competitors  on facebook as well as twitter. Our social media managers keep a watch on the competitors. They keep a track on the deals, so that you come up with the deals which are better than your competitors. 

 </p>

						</div>

					</div>

				</div>

			</div>

		</div>

	</section><!-- feature -->

	<section class="about s-padding">

		<div class="container">

			<div class="row align-items-center">

				<div class="col-lg-5">

					<div class="about-content">

						<h2><span class="logo-color">SEO</span> Search Engine Optimization Services</h2>

						<p> You can contact an SEO  specialist and talk with that person and that person would explain you how digital marketing works and what would help you in achieving the results that  are desired. We take projects which would result in success and guarantee the best outcomes. Our SEO department is highly skilled which would help you in promoting your brand </p>

						<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal" href="#" style="color: #000">Send A Quote <i class="icon-layers"></i></button>

					</div>

				</div>

				<div class="col-lg-6 offset-lg-1 about-images-wrapper">

<!--				<img src="assets/images/app-mockup.png" class="about-img1 wow slideInRightAlt"  alt="#primacy">-->

                    <img src="../assets/images/organic-traffic_Google-Analytics.gif" class="img-fluid about-img1 wow slideInRightAlt" alt="#primacy">

<!--

					<img src="assets/images/about-img1.png" class="about-img1 wow slideInRightAlt"  alt="#primacy">

					<img src="assets/images/about-img2.png" class="about-img2 wow slideInRightAlt"  data-wow-delay=".2s" alt="#primacy">

-->

				</div>

			</div>

		</div>

<!--

		<div class="floating-shapes">

			<span data-parallax='{"x": 150, "y": -20, "rotateZ":500}'><img src="assets/images/fl-shape-1.png" alt="#primacy"></span>

			<span data-parallax='{"x": 250, "y": 150, "rotateZ":500}'><img src="assets/images/fl-shape-2.png" alt="#primacy"></span>

			<span data-parallax='{"x": -180, "y": 80, "rotateY":2000}'><img src="assets/images/fl-shape-3.png" alt="#primacy"></span>

			<span data-parallax='{"x": -20, "y": 180}'><img src="assets/images/fl-shape-4.png" alt="#primacy"></span>

			<span data-parallax='{"x": 300, "y": 70}'><img src="assets/images/fl-shape-5.png" alt="#primacy"></span>

			<span data-parallax='{"x": 250, "y": 180, "rotateZ":1500}'><img src="assets/images/fl-shape-6.png" alt="#primacy"></span>

			<span data-parallax='{"x": 180, "y": 10, "rotateZ":2000}'><img src="assets/images/fl-shape-7.png" alt="#primacy"></span>

			<span data-parallax='{"x": 250, "y": -30, "rotateX":2000}'><img src="assets/images/fl-shape-8.png" alt="#primacy"></span>

			<span data-parallax='{"x": 60, "y": -100}'><img src="assets/images/fl-shape-9.png" alt="#primacy"></span>

			<span data-parallax='{"x": -30, "y": 150, "rotateZ":1500}'><img src="assets/images/fl-shape-10.png" alt="#primacy"></span>

		</div>

-->

	</section><!-- about -->

	

		<section class="quick-overview s-padding">

		<div class="container">

			<div class="s-title">

				<h2><span class="logo-color">Q</span>uick Overview</h2>

<!--				<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->

			</div>

			<div class="row">

				<div class="col-12">

					<div class="quick-overview-tab-wrapper text-center">

						<ul class="nav nav-tabs quick-overview-tab" id="overviewtab" role="tablist">

							<li class="nav-item">

						    	<a class="nav-link active" id="qa-tab1" data-toggle="tab" href="#qa-tab-content1" role="tab">SEO FEATURES</a>

						  	</li>

						  	<li class="nav-item">

						    	<a class="nav-link" id="qa-tab2" data-toggle="tab" href="#qa-tab-content2" role="tab">SMO FEATURES</a>

						  	</li>

						  	<li class="nav-item">

						    	<a class="nav-link" id="qa-tab3" data-toggle="tab" href="#qa-tab-content3" role="tab">Affliate Marketing</a>

						 	</li>

						 	<li class="nav-item">

						    	<a class="nav-link" id="qa-tab4" data-toggle="tab" href="#qa-tab-content4" role="tab">Digital Marketing Functionality</a>

						 	</li>

						</ul>

						<div class="tab-content" id="myTabContent">

						  	<div class="tab-pane fade show active" id="qa-tab-content1" role="tabpanel" aria-labelledby="qa-tab1">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="img-wrapper img-right d-none d-sm-block">

						  					<img src="../assets/images/SEO.png" class="img-fluid" alt="seo_logo">

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

												<h2><span class="logo-color">What is SEO?</span></h2>

						  						<p>Search engine optimization (SEO) is the process of affecting the visibility of a website or a web page in a web search engine’s unpaid results—often referred to as “natural”, “organic”, or “earned” results.</p>

						  					</div>

						  					<ul class="iconic-icon-list">

						  						<li><i class=" arrow_carrot-right"></i> <span>Website Maintenance</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Website Analytics</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Keyword Research</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Email Marketing</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Blog & Content Creation

</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>On Page SEO</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Pay-Per-Click Marketing

</span></li>

						  					

						  						

						  					</ul>

						  					<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal" href="#" style="color: #000">Send A Quote <i class="icon-layers"></i></button>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						  	<div class="tab-pane fade" id="qa-tab-content2" role="tabpanel" aria-labelledby="qa-tab2">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

												<h2><span class="logo-color">Why Social Media Marketing</span></h2>

						  						<p>"Social Media Optimization Services (SMO Services)" has become an inevitable part of the digital marketing. SMO Services has the capability to generate traffic from the social media sites and with a bit fine tuning by the help of the experts like us, you can promote your business/Products to the millions of visitors very easily. </p>

						  					</div>

						  					<ul class="iconic-icon-list">

												<li><i class=" arrow_carrot-right"></i> <span>Social Consultancy</span></li>

												<li><i class=" arrow_carrot-right"></i> <span>Brand Management</span></li>

												<li><i class=" arrow_carrot-right"></i> <span>Social Media Monitoring</span></li>

												<li><i class=" arrow_carrot-right"></i> <span>Social PPC</span></li>

												<li><i class=" arrow_carrot-right"></i> <span>Social PR</span></li>

						  					</ul>

						  					<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal" href="#" style="color: #000">Send A Quote <i class="icon-layers"></i></button>

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="img-wrapper d-none d-sm-block">

						  					<img src="../assets/images/smo.png" class="img-fluid" alt="smo">

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						  	<div class="tab-pane fade" id="qa-tab-content3" role="tabpanel" aria-labelledby="qa-tab3">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="img-wrapper img-right d-none d-sm-block">

						  					<img src="../assets/images/smo.png" class="img-fluid" alt="affliate-marketing">

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

												<h2><span class="logo-color">Affiliate Network</span></h2>

						  						<p>We help you extend your reach! With our affiliate advertising programs, we present you with an opportunity to reap maximum benefits of our widespread affiliate networks. Focused on providing bet ster return on investment, we ensure that you have the best affiliate network promoting your products and services.</p>

						  					</div>

						  					<ul class="iconic-icon-list">

						  			<li><i class=" arrow_carrot-right"></i> <span>Real-time Transaction Monitoring</span></li>

						  		    <li><i class=" arrow_carrot-right"></i> <span>Expedited technical support</span></li>

						  			<li><i class=" arrow_carrot-right"></i> <span>Custom reports & analysis</span></li>

                                    <li><i class=" arrow_carrot-right"></i> <span>Acquire Excellent Tracking Services.</span></li>

						  					</ul>

						  					<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal" href="#" style="color: #000">Send A Quote <i class="icon-layers"></i></button>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						  	<div class="tab-pane fade" id="qa-tab-content4" role="tabpanel" aria-labelledby="qa-tab4">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="img-wrapper img-right d-none d-sm-block">

						  					<img src="../assets/images/smo.png" class="img-fluid" alt="digital-marketing">

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

												<h2><span class="logo-color">Digital Marketing</span></h2>

						  						<p>At a high level, digital marketing refers to advertising delivered through digital channels such as search engines, websites, social media, email, and mobile apps. While this term covers a wide range of marketing activities, all of which are not universally agreed upon, we’ll focus on the most common types below.</p>

						  						<ul class="iconic-icon-list">

						  			<li><i class=" arrow_carrot-right"></i> <span>Paid Search

</span></li>

						  		    <li><i class=" arrow_carrot-right"></i> <span>Search Engine Optimization</span></li>

						  			<li><i class=" arrow_carrot-right"></i> <span>Content Marketing

</span></li>

                                    <li><i class=" arrow_carrot-right"></i> <span>Social Media Marketing</span></li>

                                    

                                    <li><i class=" arrow_carrot-right"></i> <span>Email Marketing

</span></li>

                                    <li><i class=" arrow_carrot-right"></i> <span>Mobile Marketing

</span></li>

                                    <li><i class=" arrow_carrot-right"></i> <span>Marketing Automation

</span></li>

						  					</ul>

						  					<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal" href="#" style="color: #000">Send A Quote <i class="icon-layers"></i></button>

						  						

						  					</div>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						</div>

					</div>

				</div>

			</div>

		</div>

	</section><!-- quick-overview -->

	

		<section class="partners s-padding bg-color">

		<div class="container">

			<div class="s-title">

				<h2><span class="logo-color">O</span>ur Partners</h2>

<!--				<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->

			</div>

			<div class="row">

				<div class="col-12">

					<div class="swiper-container partners-slider">

					    <div class="swiper-wrapper">

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="http://primacyinfotech.com/assets/images/1.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">
					        		<img src="http://primacyinfotech.com/assets/images/3.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="http://primacyinfotech.com/assets/images/6.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="http://primacyinfotech.com/assets/images/7.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="http://primacyinfotech.com/assets/images/9.png" alt="#primacy">

					        	</div>

					        </div>

					    </div>

					    <div class="swiper-pagination"></div>

					</div>

				</div>

			</div>

		</div>

	</section><!-- partners -->

	<section class="fun-fact s-padding bg-img bg-1">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-cloud-down"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">80</span><span>+</span></div>
						<h4>Total Clients</h4>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-thumb-up"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">240</span><span>+</span></div>
						<h4>Website Completed</h4>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-star"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">150</span><span>+</span></div>
						<h4>Sucessfully Run</h4>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-face-smile"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">95</span><span>%</span></div>
						<h4>Return Customer</h4>
					</div>
				</div>
			</div>
		</div>
	</section><!-- fun-fact -->
	
	

	

		<section class="testimonial s-padding bg-color">
		<div class="bg-text">Feedback</div>
		<div class="container">
			<div class="s-title">
				<h2><span class="logo-color">W</span>hat Customer Says</h2>
				<p></p>
			</div>
			<div class="row justify-content-center">
				<div class="col-lg-7">
					<div class="testimonial-slider-wrapper testimonial-one-item-slider-wrapper">
						<div class="swiper-container testimonial-one-item-slider">
						    <div class="swiper-wrapper">
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="http://primacyinfotech.com/assets/images/debasis.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“Great Team to work with, really attentive and react to request immediately. Excellent work and I'm really pleased with the results. Thanks Primacy Infotech Pvt. Ltd..”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">DEBASISH BISWAS
 <span class="reviewer-deg">Chief Instructor of Gpluseducation
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="http://primacyinfotech.com/assets/images/ayon-roy.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“If you are looking for a Web Development company who is fast, organized and very detailed oriented... then you will find it with Primacy Infotech Pvt. Ltd. They designed, our idea of a website to all our specifications. They also made many creative improvements that we never thought of. We would recommend Primacy Infotech Pvt. Ltd. to anyone. ”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">AYAN ROY
 <span class="reviewer-deg">Director of Relaxindia.org
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="http://primacyinfotech.com/assets/images/anwar.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“They provide great quality for the best prices that I have found in the business. I have been very happy with their work to date and recommend them highly. Thanks for the good job ....I LOVE my new website. ”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">ANWAR SEKH
 <span class="reviewer-deg"> MD of Epariseva.com
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="http://primacyinfotech.com/assets/images/sumanta.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“We came to Primacy Infotech Pvt. Ltd. with a vision for our website. you listened, that vision with your constructive criticism and insight, produced a very attractive website! We hear nothing but positive comments! So again, THANK YOU! ”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">SUMANTA BHATTACHARJEE.
 <span class="reviewer-deg">Director of Institute of Alternative Medicines Kolkata
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						    </div>
						    <div class="swiper-pagination"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- testimonial -->

 <section class="h4-contact s-padding bg-color" id="contact">
		<div class="container">
			<div class="row">
				<div class="col-md-4 offset-md-1 ">
					<div class="iconic-contact-info">
						<div class="contact-info-head">
							<h2>Contact Information</h2>
							
						</div>
						<ul class="f-contact-list">
						   <li><span><img  src="http://primacyinfotech.com/assets/images/inddd.png" alt="india"></span><span>India Office</span></li>
							<li> <span><i class="fa fa-map-marker"></i>
</span>BF 79,BF Block ,Sector I,Salt Lake, Kolkata-64,WB,India</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span> +91 9088015866,+91 9088015865</li>
							<li><span><i class="fa fa-envelope"></i></span> info@primacyinfotech.com</li>
						</ul>
						<br/>
						<ul class="f-contact-list">
						<li><span><img style="width:20px;" src="http://primacyinfotech.com/assets/images/canada-flag-xs.png" alt="canada"></span><span>Canada Office</span></li>
						
							<li> <span><i class="fa fa-map-marker"></i>
</span>656 Full Moon Circle Mississauga ON</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span>+1 6474908004</li>
							<li><span><i class="fa fa-envelope"></i></span> info@primacyinfotech.com</li>
						</ul>
						
						<ul class="f-contact-list">
						<li><span><img style="width:20px;" src="http://primacyinfotech.com/assets/images/bangladesh-flag-xs.png" alt="bangladesh"></span><span>Bangladesh Office</span></li>
						
				
			           <li><span><i class="fa fa-map-marker"></i>
</span>31,KR PLAZA,Purana Paltan,Dhaka-1000</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span> +88 01759787636</li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-6 ">
						<br/><br/><br/>
					<form class="contact-form" method="post">
						<div class="form-row">
							<div class="form-group col-md-6">
								<input type="text" name="name" class="form-control" placeholder="Name">
							</div>
							<div class="form-group col-md-6">
								<input type="tel" name="phone" class="form-control" placeholder="Phone">
							</div>
						</div>
						<div class="form-row">
						<div class="form-group col-md-6">
								<input type="email" name="email" class="form-control" placeholder="Email">
							</div>
						<div class="form-group col-md-6">
							<select name="services" class="form-control">
								<option value="">Select Services</option>
								<option value="Web Developemnt">Web Developemnt</option>
								<option value="Web Designing">Web Designing</option>
								<option value="MLM Softawre">MLM Softawre</option>
								<option value="Digital Marketing">Digital Marketing</option>
								<option value="Mobile APP Development">Mobile APP Development</option>
								<option value="Ecommerce Website">Ecommerce Website </option>
								<option value="Grocerry Shop">Grocerry Shop</option>
								<option value="LMS">LMS</option>
								<option value="CMS">CMS</option>
								<option value="Food Delivery App">Food Delivery App</option>
								<option value="Loan Management Software">Loan Management Software</option>
								<option value="OLA/Uber Clone">OLA/Uber Clone</option>
								<option value="Travel Portal Solution">Travel Portal Solution</option>
								<option value="Recharge Portal">Recharge Portal</option>
								<option value="Real Estate Portal">Real Estate Portal</option>
								<option value="Video Portal">Video Portal</option>
								<option value="Billing Software">Billing Software</option>
								<option value="Accounting Portal">Accounting Portal</option>
								
								
								
								
							</select>
						</div>
						</div>
						<div class="form-group">
							<input type="text" name="subject" class="form-control" placeholder="Subject">
						</div>
						<div class="form-group">
							<textarea name="message" class="form-control" rows="5" placeholder="Message"></textarea>
						</div>
						<div class="text-lg-right">
							<button type="submit" name="submit3"  class="btn fill-style">SEND MESSAGE</button>
						</div>
					</form>
				</div>
				
				
			</div>
		</div>
	</section>
	
	<!-- footer -->



    <?php include '../include/menu.php'; ?>


    <?php include '../include/footer.php'; ?>



    </head>



</html>