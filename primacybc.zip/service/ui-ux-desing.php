<!DOCTYPE html>
<html lang="en">



<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<title>Best UI/UX Design company in India</title>

	<meta name="description" content="Primacy Infotech is one of the best UI and UX companies in India. Call us on 9088015866 to get your website in affordable prices." />

	<meta name="keywords" content="Best ui and ux company in India, UI/UX company, UI/UX company in Kolkata" />

	<meta name="robots" content="index, follow">

	<meta name="language" content="EN">

	<meta name="organization" content="Primacy Infotech">

	<link rel="canonical" href="../index.php">

	<meta property="og:locale" content="en_US">

	<meta property="og:type" content="website">

	<meta property="og:title" content="Primacy Infitech Best website development company in kolkata">

	<meta property="og:description" content="Primacy Infotech- It is a website design and development company based in kolkata. We help small and mid sized company to achieve thier marketing goals. Call today - 9088015866">

	<meta property="og:image" content="assets/images/logo-p.png">

	<meta property="og:url" content="index.html">

	<meta property="og:site_name" content="Primacy Infotech">

	<meta name="format-detection" content="telephone=no">



    <?php include '../include/header.php'; ?>




    <!--end fixed header-->
	<!-- header -->

	




<section class="home-1-banner main-banner bg-img bg-6" id="banner">

		<div class="container">

			<div class="row align-items-center">

				<div class="col-lg-6 col-md-7">

					<div class="banner-content">

						<div class="ovh">

							<h2 class="title wow slideInUpBig" data-wow-duration=".65s"  data-wow-delay=".1s">UI/UX DESIGNS  </h2>

						</div>

						<div class="ovh">

							<span class="sub-title wow slideInUpBig" data-wow-duration=".65s" data-wow-delay=".3s">UI/UX design is the type of designs which are considered to be the most confused as well as the most conflated words in the web as well as app designs. They are placed in altogether a single term like UI/UX designs. Though they describe the same thing still it is very hard to find certain descriptions which usually do not descend too much into a jargon. </span>

						</div>



						<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal" href="#" style="color: #000">Get Started <i class="icon-layers"></i></button>

            							 

             							 <button type="button" class="btn custom-btn mb" data-toggle="modal" data-target="#callback"href="#" style="color: #000"><i class="icon-phone

"></i> Call Back Request</button>

					</div>

				</div>

				<div class="col-lg-5 col-md-3 offset-lg-1 offset-md-2 banner-img-wrapper">

					<img src="../assets/images/banner-mobile1.png" class="banner-img-1 wow slideInUpAlt" data-wow-delay=".1s" alt="#primacy">

					<img src="../assets/images/banner-mobile2.png" class="banner-img-2 wow slideInRightAlt" alt="#primacy">

				</div>

			</div>

		</div>

	</section><!-- banner -->

	<section class="feature">

		<div class="container">

			<div class="row justify-content-center">

				<div class="col-lg-4">

					<div class="icon-box style-boxed">

						<div class="icon-box-icon">

<!--							<i class="icofont-lens"></i>-->

					<img src="../assets/svg/responsive_animated.svg" alt="#primacy">

						</div>
						<div class="icon-box-details">

				

							<h3 class="icon-box-title">Creative and familiar</h3>

							<p>If the interface is failing to match up with the demands of the customer/ user. Responsive means being very fast.  Making the user to wait can be bad at times. </p>

							

						</div>

					</div>

				</div>

				<div class="col-lg-4">

					<div class="icon-box style-boxed">

						<div class="icon-box-icon">

				<i class="icofont-dashboard-web"></i>

						</div>

						<div class="icon-box-details">

							<h3 class="icon-box-title">Creative and familiar</h3>

							<p>When an user comes to know about something and it’s behaviour. Navigation becomes easier in this way. Users always appreciate the things which are creative and familiarity component is always appreciated by the customers and users. </p>

						</div>

					</div>

				</div>

				<div class="col-lg-4">

					<div class="icon-box style-boxed">

						<div class="icon-box-icon">

							<i class="icofont-eye-alt"></i>

						</div>

						<div class="icon-box-details">

							<h3 class="icon-box-title">Retina Supported</h3>

							<p>The interface should be understandable and easy for Navigation</p>

						</div>

					</div>

				</div>

			</div>

		</div>

	</section><!-- feature -->

	<section class="about s-padding">

		<div class="container">

			<div class="row align-items-center">

				<div class="col-lg-5">

					<div class="about-content">

						<h2>Dedicate yourself to the things that really matter</h2>

						<p>You should dedicate your time and energy to the things which actually matter.  Time and energy should be invested on the things which would matter and which would actually make a difference in the world of business.  </p>

						<div class="btn-wrapper">

							<a href="#" class="btn fill-style">READ MORE</a>

<!--							<a href="#" class="btn">DOWNLOAD</a>-->

						</div>

					</div>

				</div>

				<div class="col-lg-6 offset-lg-1 about-images-wrapper">

<!--				<img src="assets/images/app-mockup.png" class="about-img1 wow slideInRightAlt"  alt="#primacy">-->

                    <img src="../assets/images/81Jl.gif" class="about-img1 wow slideInRightAlt" alt="#primacy">

<!--

					<img src="assets/images/about-img1.png" class="about-img1 wow slideInRightAlt"  alt="#primacy">

					<img src="assets/images/about-img2.png" class="about-img2 wow slideInRightAlt"  data-wow-delay=".2s" alt="#primacy">

-->

				</div>

			</div>

		</div>

<!--

		<div class="floating-shapes">

			<span data-parallax='{"x": 150, "y": -20, "rotateZ":500}'><img src="assets/images/fl-shape-1.png" alt="#primacy"></span>

			<span data-parallax='{"x": 250, "y": 150, "rotateZ":500}'><img src="assets/images/fl-shape-2.png" alt="#primacy"></span>

			<span data-parallax='{"x": -180, "y": 80, "rotateY":2000}'><img src="assets/images/fl-shape-3.png" alt="#primacy"></span>

			<span data-parallax='{"x": -20, "y": 180}'><img src="assets/images/fl-shape-4.png" alt="#primacy"></span>

			<span data-parallax='{"x": 300, "y": 70}'><img src="assets/images/fl-shape-5.png" alt="#primacy"></span>

			<span data-parallax='{"x": 250, "y": 180, "rotateZ":1500}'><img src="assets/images/fl-shape-6.png" alt="#primacy"></span>

			<span data-parallax='{"x": 180, "y": 10, "rotateZ":2000}'><img src="assets/images/fl-shape-7.png" alt="#primacy"></span>

			<span data-parallax='{"x": 250, "y": -30, "rotateX":2000}'><img src="assets/images/fl-shape-8.png" alt="#primacy"></span>

			<span data-parallax='{"x": 60, "y": -100}'><img src="assets/images/fl-shape-9.png" alt="#primacy"></span>

			<span data-parallax='{"x": -30, "y": 150, "rotateZ":1500}'><img src="assets/images/fl-shape-10.png" alt="#primacy"></span>

		</div>

-->

	</section><!-- about -->

	

	

	

<!--

		<section class="awesome-feature bg-color s-padding" id="feature">

			<div class="container">

				<div class="s-title">

					<h2 class="wow">Awesome Features</h2>

					<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>

				</div>

				<div class="row align-items-center justify-content-center">

					<div class="col-lg-3">

						<div class="ovh">

							<div class="icon-box text-center text-lg-right awf-item  wow slideInUp">

								<div class="icon-box-icon">

									<i class="ti-mobile"></i>

								</div>

								<div class="icon-box-details">

									<h3 class="icon-box-title">Retina Ready</h3>

									<p>Magna exercitation! Dolor accumsan sapiente, curabitur voluptate minim<br> quidem placeat.</p>

								</div>

							</div>

						</div>

						<div class="ovh">

							<div class="icon-box text-center text-lg-right awf-item mb-0 wow slideInUp" data-wow-delay=".1s">

								<div class="icon-box-icon">

									<i class="ti-loop"></i>

								</div>

								<div class="icon-box-details">

									<h3 class="icon-box-title">Constant Updates</h3>

									<p>Magna exercitation! Dolor accumsan sapiente, curabitur voluptate minim<br> quidem placeat.</p>

								</div>

							</div>

						</div>

					</div>

					<div class="col-lg-4">

						<div class="awesome-feature-img">

							<img src="assets/images/a-feature-img.png" alt="#primacy">

						</div>

					</div>

					<div class="col-lg-3">

						<div class="ovh">

							<div class="icon-box text-lg-left text-center awf-item wow slideInUp">

								<div class="icon-box-icon">

									<i class="ti-bookmark-alt"></i>

								</div>

								<div class="icon-box-details">

									<h3 class="icon-box-title">Premium Quality</h3>

									<p>Magna exercitation! Dolor accumsan sapiente, curabitur voluptate minim<br> quidem placeat.</p>

								</div>

							</div>

						</div>

						<div class="ovh">

							<div class="icon-box text-lg-left text-center awf-item mb-0 wow slideInUp" data-wow-delay=".1s">

								<div class="icon-box-icon">

									<i class="ti-headphone-alt"></i>

								</div>

								<div class="icon-box-details">

									<h3 class="icon-box-title">Excellent Support</h3>

									<p>Magna exercitation! Dolor accumsan sapiente, curabitur voluptate minim<br> quidem placeat.</p>

								</div>

							</div>

						</div>

					</div>

				</div>

			</div>

		</section>



-->

	<!-- awesome-feature -->

	<section class="app-screenshot s-padding" id="screenshot">

		<div class="container">

			<div class="s-title">

				<h2>App Screenshots</h2>

<!--				<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->

			</div>

			<div class="row app-screenshot-slider-row">

				<div class="col-12">

					<div class="swiper-container app-screenshot-slider">

					    <div class="swiper-wrapper">

					        <div class="swiper-slide">

					        	<div class="app-screenshot-item">

					        		<a href="../assets/images/anis.png" data-rel="lightbox-popup:screenshot"><img src="../assets/images/anis.png" alt="#primacy"></a>

					        		<div class="asi-icon-wr"><span class="asi-icon"><i class="icon_plus"></i></span></div>

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="app-screenshot-item">

					        		<a href="../assets/images/jwellery.png" data-rel="lightbox-popup:screenshot"><img src="../assets/images/jwellery.png" alt="#primacy"></a>

					        		<div class="asi-icon-wr"><span class="asi-icon"><i class="icon_plus"></i></span></div>

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="app-screenshot-item">

					        		<a href="../assets/images/anis.png" data-rel="lightbox-popup:screenshot"><img src="../assets/images/anis.png" alt="#primacy"></a>

					        		<div class="asi-icon-wr"><span class="asi-icon"><i class="icon_plus"></i></span></div>

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="app-screenshot-item">

					        		<a href="../assets/images/epareseva.png" data-rel="lightbox-popup:screenshot"><img src="../assets/images/epareseva.png" alt="#primacy"></a>

					        		<div class="asi-icon-wr"><span class="asi-icon"><i class="icon_plus"></i></span></div>

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="app-screenshot-item">

					        		<a href="../assets/images/anis.html" data-rel="lightbox-popup:screenshot"><img src="../assets/images/anis.html" alt="#primacy"></a>

					        		<div class="asi-icon-wr"><span class="asi-icon"><i class="icon_plus"></i></span></div>

					        	</div>

					        </div>

					       

					    </div>

					    <div class="swiper-pagination"></div>

					</div>

				</div>

			</div>

		</div>

	</section><!-- app-screenshot -->

	<section class="fun-fact s-padding bg-img bg-1">

		<div class="overlay"></div>

		<div class="container">

			<div class="row">

				<div class="col-lg-3 col-sm-6">

					<div class="counter-item boxed-style">

						<div class="counter-item-icon">

							<i class="ti-cloud-down"></i>

						</div>

						<div class="counter-item-count"><span class="counter-count">240</span><span>K</span></div>

						<h4>App Download</h4>

					</div>

				</div>

				<div class="col-lg-3 col-sm-6">

					<div class="counter-item boxed-style">

						<div class="counter-item-icon">

							<i class="ti-thumb-up"></i>

						</div>

						<div class="counter-item-count"><span class="counter-count">120</span><span>K</span></div>

						<h4>Free Download</h4>

					</div>

				</div>

				<div class="col-lg-3 col-sm-6">

					<div class="counter-item boxed-style">

						<div class="counter-item-icon">

							<i class="ti-star"></i>

						</div>

						<div class="counter-item-count"><span class="counter-count">10</span><span>+</span></div>

						<h4>Best Award</h4>

					</div>

				</div>

				<div class="col-lg-3 col-sm-6">

					<div class="counter-item boxed-style">

						<div class="counter-item-icon">

							<i class="ti-face-smile"></i>

						</div>

						<div class="counter-item-count"><span class="counter-count">95</span><span>%</span></div>

						<h4>Return Customer</h4>

					</div>

				</div>

			</div>

		</div>

	</section><!-- fun-fact -->

<!--

	<section class="quick-overview s-padding">

		<div class="container">

			<div class="s-title">

				<h2>Quick Overview</h2>

				<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>

			</div>

			<div class="row">

				<div class="col-12">

					<div class="quick-overview-tab-wrapper text-center">

						<ul class="nav nav-tabs quick-overview-tab" id="overviewtab" role="tablist">

							<li class="nav-item">

						    	<a class="nav-link active" id="qa-tab1" data-toggle="tab" href="#qa-tab-content1" role="tab">Best User Experience</a>

						  	</li>

						  	<li class="nav-item">

						    	<a class="nav-link" id="qa-tab2" data-toggle="tab" href="#qa-tab-content2" role="tab">Simple &amp; Minimal Design</a>

						  	</li>

						  	<li class="nav-item">

						    	<a class="nav-link" id="qa-tab3" data-toggle="tab" href="#qa-tab-content3" role="tab">Super Fast Performance</a>

						 	</li>

						 	<li class="nav-item">

						    	<a class="nav-link" id="qa-tab4" data-toggle="tab" href="#qa-tab-content4" role="tab">Ultra Level Functionality</a>

						 	</li>

						</ul>

						<div class="tab-content" id="myTabContent">

						  	<div class="tab-pane fade show active" id="qa-tab-content1" role="tabpanel" aria-labelledby="qa-tab1">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="img-wrapper img-right">

						  					<img src="assets/images/app-mockup.png" alt="#primacy">

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

						  						<h2>Simple & Minimal Design</h2>

						  						<p>Optimism ecosystem incubator, compelling philanthropy corporate social responsibility philanthropy social impact impact. think tank framework compassion!</p>

						  					</div>

						  					<ul class="iconic-icon-list">

						  						<li><i class=" arrow_carrot-right"></i> <span>We must stand up the targeted empathetic.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Think tank framework compassion.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Optimism ecosystem incubator compelling.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Optimism ecosystem incubator compelling.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Improve the world justice empower communities.</span></li>

						  					</ul>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						  	<div class="tab-pane fade" id="qa-tab-content2" role="tabpanel" aria-labelledby="qa-tab2">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

						  						<h2>Simple & Minimal Design</h2>

						  						<p>Optimism ecosystem incubator, compelling philanthropy corporate social responsibility philanthropy social impact impact. think tank framework compassion!</p>

						  					</div>

						  					<ul class="iconic-icon-list">

						  						<li><i class=" arrow_carrot-right"></i> <span>We must stand up the targeted empathetic.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Think tank framework compassion.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Optimism ecosystem incubator compelling.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Optimism ecosystem incubator compelling.</span></li>

						  					</ul>

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="img-wrapper">

						  					<img src="assets/images/app-mockup.png" alt="#primacy">

						  				</div>

						  			</div>

						  		</div>
						  	</div>

						  	<div class="tab-pane fade" id="qa-tab-content3" role="tabpanel" aria-labelledby="qa-tab3">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="img-wrapper img-right">

						  					<img src="assets/images/app-mockup.png" alt="#primacy">

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

						  						<h2>Simple & Minimal Design</h2>

						  						<p>Optimism ecosystem incubator, compelling philanthropy corporate social responsibility philanthropy social impact impact. think tank framework compassion!</p>

						  					</div>

						  					<ul class="iconic-icon-list">

						  						<li><i class=" arrow_carrot-right"></i> <span>We must stand up the targeted empathetic.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Think tank framework compassion.</span></li>

						  						<li><i class=" arrow_carrot-right"></i> <span>Optimism ecosystem incubator compelling.</span></li>

						  					</ul>

						  					<div class="btn-wrapper mt-5">

  												<a href="#" class="btn">LEARN MORE</a>

  											</div>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						  	<div class="tab-pane fade" id="qa-tab-content4" role="tabpanel" aria-labelledby="qa-tab4">

						  		<div class="row align-items-center">

						  			<div class="col-lg-5">

						  				<div class="img-wrapper img-right">

						  					<img src="assets/images/app-mockup.png" alt="#primacy">

						  				</div>

						  			</div>

						  			<div class="col-lg-5 offset-lg-1">

						  				<div class="quick-overview-content">

						  					<div class="quick-overview-content-head">

						  						<h2>Simple & Minimal Design</h2>

						  						<p>Optimism ecosystem incubator, compelling philanthropy corporate social responsibility philanthropy social impact impact. think tank framework compassion!</p>

						  						<p>Quisque velit nisi, pretium ut lacinia in, elementum id enim. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.</p>

						  						<p>Optimism ecosystem incubator, compelling philanthropy corporate social responsibility philanthropy social impact impact. think tank framework compassion!</p>

						  					</div>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						</div>

					</div>

				</div>

			</div>

		</div>

	</section>

	

-->

	 

	<!-- quick-overview -->

	

	

	

	

	

	

<!--

	<section class="pricing s-padding" id="pricing">

		<div class="container">

			<div class="s-title">

				<h2>Do More with Incubator</h2>

				<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>

			</div>

			<div class="row">

				<div class="col-12">

					<div class="pricing-tables-wrapper">

						<ul class="nav nav-tabs pricing-tab" id="pricing-tab" role="tablist">

							<li class="nav-item">

						    	<a class=" active" id="monthly-pricing" data-toggle="tab" href="#monthly-pricing-tables" role="tab">Monthly</a>

						  	</li>

						  	<li class="nav-item">

						    	<a class="" id="yearly-pricing" data-toggle="tab" href="#yearly-pricing-tables" role="tab">Yearly</a>

						  	</li>

						</ul>

						<div class="tab-content" id="pricing-tab-content">

						  	<div class="tab-pane fade show active" id="monthly-pricing-tables" role="tabpanel" aria-labelledby="monthly-pricing">

						  		<div class="row">

						  			<div class="col-lg-4">

						  				<div class="pricing-table">

						  					<div class="pricing-head">

						  						<h2 class="title">Starter</h2>

						  						<span class="sub-title">Basic Solution</span>

						  					</div>

						  					<div class="pricing-price">

						  						<span class="price-tag">

						  							<span class="price-currency">$</span>25

						  						</span>

						  						<span class="price-period">/month</span>

						  					</div>

						  					<div class="pricing-body">

						  						<ul>

						  							<li><i class="icon_check"></i> Push Notifications</li>

						  							<li><i class="icon_check"></i> Offline Synchronization</li>

						  							<li><i class="icon_close"></i> SQL Database</li>

						  							<li><i class="icon_close"></i> Data Transfer</li>

						  							<li><i class="icon_close"></i> Speech & Text Analytics</li>

						  							<li><i class="icon_check"></i> 24/7 Support</li>

						  						</ul>

						  					</div>

						  					<div class="pricing-footer">

						  						<a href="#">CHOOSE THIS</a>

						  					</div>

						  				</div>

						  			</div>

						  			<div class="col-lg-4">

						  				<div class="pricing-table featured">

						  					<div class="pricing-badge">

						  						<span class="badge-name">POPULAR</span>

						  					</div>

						  					<div class="pricing-head">

						  						<h2 class="title">Professional</h2>

						  						<span class="sub-title">Advance Platform</span>

						  					</div>

						  					<div class="pricing-price">

						  						<span class="price-tag">

						  							<span class="price-currency">$</span>50

						  						</span>

						  						<span class="price-period">/month</span>

						  					</div>

						  					<div class="pricing-body">

						  						<ul>

						  							<li><i class="icon_check"></i> Push Notifications</li>

						  							<li><i class="icon_check"></i> Offline Synchronization</li>

						  							<li><i class="icon_close"></i> SQL Database</li>

						  							<li><i class="icon_close"></i> Data Transfer</li>

						  							<li><i class="icon_check"></i> Speech & Text Analytics</li>

						  							<li><i class="icon_check"></i> 24/7 Support</li>

						  						</ul>

						  					</div>

						  					<div class="pricing-footer">

						  						<a href="#">CHOOSE THIS</a>

						  					</div>

						  				</div>

						  			</div>

						  			<div class="col-lg-4">

						  				<div class="pricing-table">

						  					<div class="pricing-head">

						  						<h2 class="title">Business</h2>

						  						<span class="sub-title">Customizable Platform</span>

						  					</div>

						  					<div class="pricing-price">

						  						<span class="price-tag">

						  							<span class="price-currency">$</span>99

						  						</span>

						  						<span class="price-period">/month</span>

						  					</div>

						  					<div class="pricing-body">

						  						<ul>

						  							<li><i class="icon_check"></i> Push Notifications</li>

						  							<li><i class="icon_check"></i> Offline Synchronization</li>

						  							<li><i class="icon_check"></i> SQL Database</li>

						  							<li><i class="icon_check"></i> Data Transfer</li>

						  							<li><i class="icon_check"></i> Speech & Text Analytics</li>

						  							<li><i class="icon_check"></i> 24/7 Support</li>

						  						</ul>

						  					</div>

						  					<div class="pricing-footer">

						  						<a href="#">CHOOSE THIS</a>

						  					</div>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						  	<div class="tab-pane fade" id="yearly-pricing-tables" role="tabpanel" aria-labelledby="yearly-pricing">

						  		<div class="row">

						  			<div class="col-lg-4">

						  				<div class="pricing-table">

						  					<div class="pricing-head">

						  						<h2 class="title">Starter</h2>

						  						<span class="sub-title">Basic Solution</span>

						  					</div>

						  					<div class="pricing-price">

						  						<span class="price-tag">

						  							<span class="price-currency">$</span>20

						  						</span>

						  						<span class="price-period">/month</span>

						  					</div>

						  					<div class="pricing-body">

						  						<ul>

						  							<li><i class="icon_check"></i> Push Notifications</li>

						  							<li><i class="icon_check"></i> Offline Synchronization</li>

						  							<li><i class="icon_close"></i> SQL Database</li>

						  							<li><i class="icon_close"></i> Data Transfer</li>

						  							<li><i class="icon_close"></i> Speech & Text Analytics</li>

						  							<li><i class="icon_check"></i> 24/7 Support</li>

						  						</ul>

						  					</div>

						  					<div class="pricing-footer">

						  						<a href="#">CHOOSE THIS</a>

						  					</div>

						  				</div>

						  			</div>

						  			<div class="col-lg-4">

						  				<div class="pricing-table featured">

						  					<div class="pricing-badge">

						  						<span class="badge-name">POPULAR</span>

						  					</div>

						  					<div class="pricing-head">

						  						<h2 class="title">Professional</h2>

						  						<span class="sub-title">Advance Platform</span>

						  					</div>

						  					<div class="pricing-price">

						  						<span class="price-tag">

						  							<span class="price-currency">$</span>40

						  						</span>

						  						<span class="price-period">/month</span>

						  					</div>

						  					<div class="pricing-body">

						  						<ul>

						  							<li><i class="icon_check"></i> Push Notifications</li>

						  							<li><i class="icon_check"></i> Offline Synchronization</li>

						  							<li><i class="icon_close"></i> SQL Database</li>

						  							<li><i class="icon_close"></i> Data Transfer</li>

						  							<li><i class="icon_check"></i> Speech & Text Analytics</li>

						  							<li><i class="icon_check"></i> 24/7 Support</li>

						  						</ul>

						  					</div>

						  					<div class="pricing-footer">

						  						<a href="#">CHOOSE THIS</a>

						  					</div>

						  				</div>

						  			</div>

						  			<div class="col-lg-4">

						  				<div class="pricing-table">

						  					<div class="pricing-head">

						  						<h2 class="title">Business</h2>

						  						<span class="sub-title">Customizable Platform</span>

						  					</div>

						  					<div class="pricing-price">

						  						<span class="price-tag">

						  							<span class="price-currency">$</span>89

						  						</span>

						  						<span class="price-period">/month</span>

						  					</div>

						  					<div class="pricing-body">

						  						<ul>

						  							<li><i class="icon_check"></i> Push Notifications</li>

						  							<li><i class="icon_check"></i> Offline Synchronization</li>

						  							<li><i class="icon_check"></i> SQL Database</li>

						  							<li><i class="icon_check"></i> Data Transfer</li>

						  							<li><i class="icon_check"></i> Speech & Text Analytics</li>

						  							<li><i class="icon_check"></i> 24/7 Support</li>

						  						</ul>

						  					</div>

						  					<div class="pricing-footer">

						  						<a href="#">CHOOSE THIS</a>

						  					</div>

						  				</div>

						  			</div>

						  		</div>

						  	</div>

						</div>

					</div>

				</div>

			</div> 

		</div>

	</section>

	

-->

	

	

<!--

	<section class="get-the-app bg-img bg-7 s-padding" id="download">

		<div class="container">

			<div class="row align-items-center">

				<div class="col-lg-6">

					<div class="get-the-app-content">

						<h2>Get this App, Available on</h2>

						<p>Social enterprise, empower communities, paradigm vibrant revolutionary resist. Save the world compassion triple bottom line; global revolutionary green space correlation transparent collaborate.!</p>

						<div class="apps-store-btn-wrpper">

							<a href="#" class="app-store-btn">

								<img src="assets/images/play-store-btn.png" alt="#primacy">

								<img src="assets/images/play-store-btn-alt.png" alt="#primacy">

							</a>

							<a href="#" class="app-store-btn">

								<img src="assets/images/app-store-btn.png" alt="#primacy">

								<img src="assets/images/app-store-btn-alt.png" alt="#primacy">

							</a>

						</div>

					</div>

				</div>

			</div>

		</div>

	</section>

-->

	<!-- get-the-app -->



	

	

	

	<section class="partners s-padding bg-color">

		<div class="container">

			<div class="s-title">

				<h2>Our Partners</h2>

<!--				<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->

			</div>

			<div class="row">

				<div class="col-12">

					<div class="swiper-container partners-slider">

					    <div class="swiper-wrapper">

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="../assets/images/1.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="../assets/images/3.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="../assets/images/6.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="../assets/images/7.png" alt="#primacy">

					        	</div>

					        </div>

					        <div class="swiper-slide">

					        	<div class="partner-logo">

					        		<img src="../assets/images/9.png" alt="#primacy">

					        	</div>

					        </div>

					    </div>

					    <div class="swiper-pagination"></div>

					</div>

				</div>

			</div>

		</div>

	</section><!-- partners -->

	     <section class="h4-contact s-padding bg-color" id="contact">
		<div class="container">
			<div class="row">
				<div class="col-md-4 offset-md-1 ">
					<div class="iconic-contact-info">
						<div class="contact-info-head">
							<h2>Contact Information</h2>
							
						</div>
						<ul class="f-contact-list">
						   <li><span><img src="../assets/images/inddd.png" alt="india"></span><span>India Office</span></li>
							<li> <span><i class="fa fa-map-marker"></i>
</span>BF 79,BF Block ,Sector I,Salt Lake, Kolkata-64,WB,India</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span> +91 9088015866,+91 9088015865</li>
							<li><span><i class="fa fa-envelope"></i></span> info@primacyinfotech.com</li>
						</ul>
						<br/>
						<ul class="f-contact-list">
						<li><span><img style="width:20px;" src="../assets/images/canada-flag-xs.png" alt="canada"></span><span>Canada Office</span></li>
						
							<li> <span><i class="fa fa-map-marker"></i>
</span>656 Full Moon Circle Mississauga ON</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span>+1 6474908004</li>
							<li><span><i class="fa fa-envelope"></i></span> info@primacyinfotech.com</li>
						</ul>
						
						<ul class="f-contact-list">
						<li><span><img style="width:20px;" src="../assets/images/bangladesh-flag-xs.png" alt="bangladesh"></span><span>Bangladesh Office</span></li>
						
				
			           <li><span><i class="fa fa-map-marker"></i>
</span>31,KR PLAZA,Purana Paltan,Dhaka-1000</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span> +88 01759787636</li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-6 ">
						<br/><br/><br/>
					<form class="contact-form" method="post">
						<div class="form-row">
							<div class="form-group col-md-6">
								<input type="text" name="name" class="form-control" placeholder="Name">
							</div>
							<div class="form-group col-md-6">
								<input type="tel" name="phone" class="form-control" placeholder="Phone">
							</div>
						</div>
						<div class="form-row">
						<div class="form-group col-md-6">
								<input type="email" name="email" class="form-control" placeholder="Email">
							</div>
						<div class="form-group col-md-6">
							<select name="services" class="form-control">
								<option value="">Select Services</option>
								<option value="Web Developemnt">Web Developemnt</option>
								<option value="Web Designing">Web Designing</option>
								<option value="MLM Softawre">MLM Softawre</option>
								<option value="Digital Marketing">Digital Marketing</option>
								<option value="Mobile APP Development">Mobile APP Development</option>
								<option value="Ecommerce Website">Ecommerce Website </option>
								<option value="Grocerry Shop">Grocerry Shop</option>
								<option value="LMS">LMS</option>
								<option value="CMS">CMS</option>
								<option value="Food Delivery App">Food Delivery App</option>
								<option value="Loan Management Software">Loan Management Software</option>
								<option value="OLA/Uber Clone">OLA/Uber Clone</option>
								<option value="Travel Portal Solution">Travel Portal Solution</option>
								<option value="Recharge Portal">Recharge Portal</option>
								<option value="Real Estate Portal">Real Estate Portal</option>
								<option value="Video Portal">Video Portal</option>
								<option value="Billing Software">Billing Software</option>
								<option value="Accounting Portal">Accounting Portal</option>
								
								
								
								
							</select>
						</div>
						</div>
						<div class="form-group">
							<input type="text" name="subject" class="form-control" placeholder="Subject">
						</div>
						<div class="form-group">
							<textarea name="message" class="form-control" rows="5" placeholder="Message"></textarea>
						</div>
						<div class="text-lg-right">
							<button type="submit" name="submit3"  class="btn fill-style">SEND MESSAGE</button>
						</div>
					</form>
				</div>
				
				
			</div>
		</div>
	</section>
	
	<!-- footer -->



    <?php include '../include/menu.php'; ?>


    <?php include '../include/footer.php'; ?>

</head>




</html>
