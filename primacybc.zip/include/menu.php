

<!--side menuu on desktop-->
<div id="menuwrapper">
    <ul id="sidemenu">
        <li><a class="" href="../"><i class="fas fa-home"></i><br/>Home</a></li>

        <li><a href="#"><i class="fas fa-desktop">	</i><br>
                    Service</a>
            <ul class="my-col-2">
                <!--
                                    <li><a href="web-developemnt"><img src="assets/images/small/software.png"><br />
                                        <div class="txt">Software Development</div>
                                        </a>
                                    </li>
                -->
                <li>
                    <a href="../service/web-developement"><i class="icofont-code icofont-2x"></i><br />
                        <div class="txt">Web Development</div>
                    </a>
                </li>
                <li><a href="../service/web-designing"><i class="icofont-dashboard-web icofont-2x"></i>

                        <div class="txt">Web Designing</div>
                    </a>
                </li>
                <li><a href="../service/mobile-app-developemnt"><i class="icofont-brand-android-robot icofont-2x"></i><br />
                        <div class="txt">Apps Development</div>
                    </a>
                </li>

                <li><a href="../service/crm-erp-portal-development"><i class="icofont-computer icofont-2x"></i><br />
                        <div class="txt">CRM & ERP Portal Development </div>
                    </a>
                </li>


                <li><a href="../service/digital-marketing"><i class="icofont-automation icofont-2x"></i><br />
                        <div class="txt">Digital Marketing</div>
                    </a>
                </li>

                <li><a href="../service/ui-ux-desing"><i class="icofont-penalty-card icofont-2x"></i><br />
                        <div class="txt">UI/UX Design</div>
                    </a>
                </li>
                <li><a href="../service/mlm-software-development"><i class="icofont-company icofont-2x"></i><br />
                        <div class="txt">MLM Software Development</div></a>



                <li><a href="../service/health-care-mangment"><i class="icofont-company icofont-2x"></i><br />
                        <div class="txt">Halthcare Portal Development</div></a>







            </ul>

        </li>
        <!--
                    <a href="#"><i class="fas fa-server fas-2x"><br>
                                Solution</i></a>
        -->
        <li><a href="#"><i class="far fa-compass"></i><br>
                    Solution</a>
            <ul class="my-col-2">
                <li><a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel Portal </div>
                    </a>
                </li>
                <li>
                    <a href="http://primacycms.com/"><i class="icofont-building-alt icofont-2x"></i><br />
                        <div class="txt">PrimacyCMS</div></a>
                <li>
                    <a href="../product/school-managmest-system"><i class="icofont-building-alt icofont-2x"></i><br />
                        <div class="txt">School Management</div></a>
                </li>
                <li><a href="../product/portal-accounting"><i class="icofont-paper icofont-2x"></i><br />
                        <div class="txt">Accounting & Pos Software</div></a>
                </li>
				<li><a href="../product/ludo-gaming-app.php"><i class="icofont-paper icofont-2x"></i><br />
                        <div class="txt">Ludo Game Development</div></a>
                </li>
				<li><a href="../product/tambola-gaming.php"><i class="icofont-paper icofont-2x"></i><br />
                        <div class="txt">Tambola Game Development</div></a>
                </li>

            </ul>

        </li>
        <li><a href="#"><i class="fas fa-globe"></i><br>
                    Product</a>
            <ul class="my-col-2">
                <li><a href="../product/readymade-ecommerces-app"><i class="icofont-shopping-cart icofont-2x"></i><br />
                        <div class="txt">Ecommerce App </div>
                    </a>
                </li>
                <li><a href="../product/readymade-pharmacy-app"><i class="icofont-doctor icofont-2x"></i><br />
                        <div class="txt">Pharmacy App</div></a>
                </li>
                <li><a href="../product/readymade-grocery-delivery-app"><i class="icofont-grocery icofont-2x"></i><br />
                        <div class="txt">Grocery Delivery App</div>
                    </a>
                </li>
                <li><a href="../product/readymade-food-delivery-app"><i class="icofont-fast-food icofont-2x"></i><br />
                        <div class="txt">Food Delivery App</div>
                    </a>
                </li>

                <li><a href="../product/recharge-bill-payment-portal-b2b-b2c"><i class="icofont-brand-china-mobile icofont-2x"></i><br />
                        <div class="txt">B2B & b2C Portal</div>
                    </a>
                </li>

                <li>
                    <a href="../product/readymade-online-education-app"><i class="icofont-learn icofont-2x"></i><br />
                        <div class="txt">Online Education App</div></a>
                </li>
                <li><a href="../product/loan-mangment-system"><i class="icofont-money-bag icofont-2x"></i><br />
                        <div class="txt">Loan Management System </div></a>
                </li>



                <li><a href="../product/readymade-video-streaming-app"><i class="icofont-video-cam icofont-2x"></i>

                        <div class="txt">Video streaming app</div>
                    </a>
                </li>

                </li>
                <li><a href="../product/readymade-realestate-portal"><i class="icofont-search-property icofont-2x"></i>

                        <div class="txt">Realestate Portal</div>
                    </a>
                </li>
                <li><a href="../product/readymade-cab-booking-app"> <i class="icofont-car-alt-1 icofont-2x"></i>

                        <div class="txt">Cab booking App</div>
                    </a>
                </li>





            </ul>

        </li>

        <li><a href="#"><i class="fas fa-industry"></i><br>
                    Industry</a>
            <ul class="my-col-2">
                <li><a href="../industry/industry-healthcare"><i class="icofont-doctor icofont-2x"></i><br />
                        <div class="txt">Healthcare</div>
                    </a>
                </li>
                <li>
                    <a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel</div>
                    </a>
                </li>
                <li><a href="../industry/industry-education"><i class="icofont-paper icofont-2x"></i><br />
                        <div class="txt">Education</div>
                    </a>
                </li>
                <li><a href="../industry/industry-retail"><i class="icofont-ui-cart icofont-2x"></i><br />
                        <div class="txt">Retail</div>
                    </a>
                </li>
                <!--   <li><a href="../industry/industry-insurance"><i class="icofont-holding-hands icofont-2x"></i><br />
                          <div class="txt">Insurance</div>
                      </a>
                  </li>-->
                <li><a href="../industry/industry-media"><i class="icofont-newspaper icofont-2x"></i>

                        <div class="txt">Media </div>
                    </a>
                </li>
                  <li><a href="../industry/industry-bankin-finance"><i class="icofont-bank icofont-2x"></i>

                          <div class="txt">Banking</div>
                      </a>
                  </li>
                  <li><a href="../industry/industry-goverment"><i class="icofont-man-in-glasses icofont-2x"></i>

                          <div class="txt">Goverment</div>
                      </a>
                  </li>
				   <li><a href="../industry/industry-insurance"><i class="icofont-company icofont-2x"></i>

                          <div class="txt">Insurance</div>
                      </a>
                  </li>











              </ul>

          </li>



          <li><a href="#"><i class="fas fa-paper-plane"></i><br>
                      About Us</a>

              <ul class="my-col-2">
                  <!--  <li><a href="#"><i class="icofont-question-square icofont-2x"></i><br />
                           <div class="txt">Why Us</div>
                       </a>
                   </li>-->
                   <li>
                       <a href="../about/our-company"><i class="icofont-building icofont-2x"></i><br />
                           <div class="txt">Company</div>
                       </a>
                  </li>
                  <li><a href="../about/career"><i class="icofont-search-job icofont-2x"></i><br />
                          <div class="txt">Career</div>
                      </a>
                  </li>
                  <!-- <li><a href="#"><i class="icofont-building-alt icofont-2x"></i><br />
                          <div class="txt">Infrastructure</div>
                      </a>
                  </li>
                  <li><a href="#"><i class="icofont-team icofont-2x"></i><br />
                          <div class="txt">Team</div>
                      </a>
                  </li>-->
                  <li><a href="../about/our-portfolios"><i class="icofont-notebook icofont-2x"></i><br />
                          <div class="txt">Our Case Study</div>
                      </a>
                  </li>

              </ul>



          </li>

          <li><a class="noflyout selected" href="../about/contact"><i class="fas fa-envelope"></i><br>Contact Us</a></li>

      </ul>

  </div>
  <!--end side menuu on desktop-->




<div class="nav-side-menu" id="slide_menu2" style="display:none;">



    <div class="brand">Menu</div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

    <div class="menu-list">

        <ul id="menu-content" class="menu-content collapse out">
            <li>
                <a href="../">
                    <i class="fas fa-home fa-lg"></i> Home
                </a>
            </li>

            <li  data-toggle="collapse" data-target="#products" class="collapsed active">
                <a href="#"><i class="fas fa-desktop"></i> Services<span class="arrow"></span></a>
            </li>
            <ul class="sub-menu collapse" id="products" >
                <li class="active"><a href="../service/web-developement">Web Development</a></li>
                <li><a href="../service/web-designing">Web Designing</a>
                </li>
                <li>
                    <a href="../service/mobile-app-developemnt">Apps Development</a>
                </li>
                <li><a href="../service/crm-erp-portal-development">CRM & ERP Development </a>
                </li>

                <li><a href="../service/digital-marketing">Digital Marketing</a>
                </li>
                <li><a href="../service/ui-ux-desing">UI/UX Design</a>
                </li>
                <li><a href="../service/mlm-software-development.php">MLM Software Development</a></li>
                <li><a href="../service/health-care-mangment">Halthcare Portal Development</a></li>


.


            </ul>


            <li data-toggle="collapse" data-target="#service2" class="collapsed">
                <a href="#"><i class="fa fa-globe fa-lg"></i> Solution <span class="arrow"></span></a>
            </li>
            <ul class="sub-menu collapse" id="service2">
                <li class="active"><a href="http://www.travelbusinessportal.com/">Travel Portal</a></li>
                <li>
                    <a href="http://primacycms.com/"></i>PrimacyCMS</a>

                <li><a href="../product/school-managmest-system">School Management System</a>
                </li>
                <li><a href="../product/portal-accounting">Accounting & Pos Software</a>
                </li>


            </ul>
            <li data-toggle="collapse" data-target="#service" class="collapsed">
                <a href="#"><i class="far fa-compass fa-lg"></i> Product <span class="arrow"></span></a>
            </li>
            <ul class="sub-menu collapse" id="service">

                <li><a href="../product/readymade-grocery-delivery-app">Grocery Delivery App</a>
                </li>
                <li><a href="../product/readymade-ecommerces-app">E-commerces  App</a>
                <li><a href="../product/readymade-pharmacy-app">Pharmacy App</a>
                <li><a href="../product/readymade-food-delivery-app">Food Delivery App</a>
                </li>

                </li>
                <li><a href="../product/recharge-bill-payment-portal-b2b-b2c">B2B & b2C Portal</a>
                </li>

                <li><a href="../product/readymade-online-education-app">Online Education App</a>
                </li>
                <li><a href="../product/loan-mangment-system">Loan Management System </a>
                </li>



                </li>
                <li><a href="../service/mlm-software-development">MLM Software</a>
                </li>

                <li><a href="../product/readymade-video-streaming-app">Video streaming app</a>
                </li>
                <li><a href="../product/readymade-realestate-portal">Realestate Portal</a>
                </li>
                <li><a href="../product/readymade-cab-booking-app">Cab Booking App</a>
                </li>
 <li><a href="../product/tambola-gaming.php">Tambola Game Development</a>
                </li>
				 <li><a href="../product/ludo-gaming-app.php">Ludo Game Development</a>
                </li>

            </ul>

            <li data-toggle="collapse" data-target="#about" class="collapsed">
                <a href="#"><i class="fas fa-industry fa-lg"></i> Industry<span class="arrow"></span></a>
            </li>
            <ul class="sub-menu collapse" id="about">

                <li><a href="../industry/industry-healthcare">Healthcare</a>
                </li>
                <li><a href="../industry/industry-travel">Travel</a>
                </li>
                <li><a href="../industry/industry-education">Financial</a>
                </li>
                <li><a href="../industry/industry-retail">Retail</a>
                </li>
                <li><a href="../industry/industry-insurance">Insurance</a>
                </li>
                <li><a href="../industry/industry-bankin-finance">Banking</a>
                </li>
                <li><a href="../industry/industry-goverment">Goverment</a>
                </li>
                <li><a href="../industry/industry-media">Media</a>
                </li>


            </ul>


            <!--
                            <li data-toggle="collapse" data-target="#about" class="collapsed">
                              <a href="#"><i class="fa fa-globe fa-lg"></i> Industry<span class="arrow"></span></a>
                            </li>
                            <ul class="sub-menu collapse" id="about">

                                       <li><a href="why-us">Why Us</a>
                                </li>
                                  <li><a href="our-company">Company</a>
                                </li>
                                  <li><a href="career">Career</a>
                                </li>
                                   <li><a href="#">Infrastructure</a>
                                </li>
                                <li><a href="#">Team</a>
                                </li>
                                <li><a href="industry-media">Media</a>
                                </li>


                            </ul>
            -->
            <li data-toggle="collapse" data-target="#about3" class="collapsed">
                <a href="#"><i class="fas fa-paper-plane fa-lg"></i> About Us <span class="arrow"></span></a>
            </li>
            <ul class="sub-menu collapse" id="about3">

                <!--                           <li><a href="why-us">Why Us</a>-->
                <!--<li><a href="#">Why Us</a>
                </li>-->
                <li><a href="../about/our-company">Company</a>
                </li>
                <li><a href="../about/career">Career</a>
                </li>
                <!-- <li><a href="#">Infrastructure</a>
                 </li>
                 <li><a href="#">Team</a>
                 </li>
                 --><li>
                     <!--                    <a href="sucess-story">Our Case Study</a>-->
                    <a href="../about/our-portfolios">Our Case Study</a>
                </li>


            </ul>
            <!--   <li>
               <a href="about">
               <i class="fa fa-user fa-lg"></i> About Us
               </a>
               </li>-->
            <!-- vb
                             <li>
                              <a href="our-company">
                              <i class="fa fa-user fa-lg"></i> Company
                              </a>
                              </li>
            -->

            <li>
                <a href="../about/contact">
                    <i class="fas fa-envelope fa-lg"></i> Contact Us
                </a>
            </li>
        </ul>
    </div>
    <ul class="list-unstyled list-inline social text-center">
        <li class="list-inline-item"><a href="https://www.facebook.com/primacyit/"><i class="fab fa-facebook-f"></i></a></li>
        <li class="list-inline-item"><a href="https://api.whatsapp.com/send?phone=919875627563"><i class="fab fa-whatsapp"></i></a></li>

        <li class="list-inline-item"><a href="https://in.linkedin.com/company/primacy-infotech-pvt-ltd"><i class="fab fa-linkedin-in"></i></a></li>
        <!--<li class="list-inline-item"><a href=""><i class="fab fa-skype"></i></a></li>
-->
        <li class="list-inline-item"><a href="mailto:info@primacyinfotech.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
    </ul>
</div>




<div class="menu-footer">

    <ul class="menu2">
        <li><a class="" href="../"><i class="fas fa-home"></i>Home</a></li>
        <li><a href="../about/about"><i class="fas fa-paper-plane">&nbsp;
                    </i>About Us</a></li>

        <li><a class="noflyout selected" href="../about/our-company"><i class="fas fa-building">&nbsp;</i>Company</a></li>
        <li><a class="noflyout selected" href="../about/contact"><i class="fas fa-envelope">&nbsp;</i>Contact Us</a></li>
        <li class="menu-icon"><img src="../assets/images/icon_footer-toggle.png"></li>



    </ul>
</div>

    
    