     <footer>
        <div class="row d-flex justify-content-center">
          <div class="col-lg-10">
            <p>Protected by <strong><a href="https://primacyinfotech.com/" target="_blank">PRIMACY SITE SECURITY by Primacy Infotech Pvt. Ltd.</a></strong></p>
          </div>
        </div>
      </footer>
    
    </div>
	
  </body>
</html>