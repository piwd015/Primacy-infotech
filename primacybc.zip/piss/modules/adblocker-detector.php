<?php
//AdBlock Detector
$table = $prefix . 'adblocker-settings';
$query = $mysqli->query("SELECT * FROM `$table`");
$row   = $query->fetch_assoc();

if ($row['detection'] == 1) {
    
    if ($row['popup'] == 1) {
        
        $tablewp = $prefix . 'pages-layolt';
        $querywp = $mysqli->query("SELECT * FROM `$tablewp` WHERE page='AdBlocker'");
        $rowwp   = mysqli_fetch_array($querywp);
        
        $table   = $prefix . 'settings';
        $queryst = $mysqli->query("SELECT email FROM `$table` LIMIT 1");
        $rowst   = mysqli_fetch_array($queryst);
        
        echo '
<style>
.psec_overlay{z-index: 1;overflow: auto;position:fixed;top:0;bottom:0;left:0;right:0;background:rgba(0,0,0,.7);opacity:1;display: none;}.psec_popup{margin:100px auto;padding:20px;background:#fff;border-radius:1px;width:60%;position:relative}.psec_popup h2{background-color:#d9534f;color:#fff;margin-top:0;border-radius:4px;font-family:Tahoma,Arial,sans-serif}.psec_popup .content{max-height:60%;overflow:auto}@media screen and (max-width:700px){.psec_popup{width:70%}}
</style>
<div id="psec_popup1" class="psec_overlay">
	<div class="psec_popup" style="border-radius: 6px;">
		<center><h2>AdBlocker Detected</h2>
		<div class="content">
			<br /><p>' . html_entity_decode($rowwp['text']) . '</p>
            <p>Please contact with the webmaster of the website if you think something is wrong.</p><br />

			<input type="button" onclick="location.href=\'mailto:' . $rowst['email'] . '\';" style="width: 100%; background-color: blue; color: white; font-size: 16px; border-radius: 6px; padding: 6px;" value="Contact" />
            <br />
			
	        <button style="width: 100%; background-color: #008CBA; color: white; font-size: 16px; border-radius: 6px; padding: 10px;" onclick="window.location.reload();">I disabled my AdBlocker. Let me see the website</button>
		</div></center><br />
		<p>Protected by <strong><a href="https://codecanyon.net/item/project-security-website-security-antivirus-firewall/15487703?ref=Antonov_WEB" target="_blank">Project SECURITY</a></strong></p>
	</div>
	
</div>
';
    }
    
    echo '
<script type="text/javascript">
function adBlockDetected() {
';
    if ($row['popup'] == 1) {
        echo '
		$(\'.psec_overlay\').css(\'display\',\'block\');
';
    } else {
        echo '
	window.location = "' . $row['redirect'] . '";
';
    }
    echo '
}

if(typeof fuckAdBlock !== "undefined" || typeof FuckAdBlock !== "undefined") {
	adBlockDetected();
} else {
	var importFAB = document.createElement("script");
	importFAB.onload = function() {
		fuckAdBlock.onDetected(adBlockDetected)
	};
	importFAB.onerror = function() {
		adBlockDetected(); 
	};
	importFAB.integrity = "sha256-xjwKUY/NgkPjZZBOtOxRYtK20GaqTwUCf7WYCJ1z69w=";
	importFAB.crossOrigin = "anonymous";
	importFAB.src = "https://cdnjs.cloudflare.com/ajax/libs/fuckadblock/3.2.1/fuckadblock.min.js";
	document.head.appendChild(importFAB);
}
</script>
	';
    
}
?>