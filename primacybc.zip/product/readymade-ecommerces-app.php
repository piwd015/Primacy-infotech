<!DOCTYPE html>
<html lang="en">


<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Event snippet for ledes conversion page
In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-717269907/OfKrCJ_rs6sBEJPXgtYC',
      'event_callback': callback
  });
  return false;
}
</script>

		<title>Ecommerce app development company in india| Readymade Ecommerce app Solution|Affordable Ecommerce App Development Company : Primacy Infotech </title>

	<meta name="description" content="Primacy Infotech is one of the best grocery app development companies in India. Call us on 9088015866 to Get demo and prices." />

	<meta name="keywords" content="grocery app development, grocery mobile app development, bigbasket clone app, readymade grocery app, grocery app development company india, grocery shopping app development, grocery app development company in kolkata." />

	<meta name="robots" content="index, follow">

	<meta name="language" content="EN">

	<meta name="organization" content="Primacy Infotech">

	<link rel="canonical" href="../index.php">

	<meta property="og:locale" content="en_US">

	<meta property="og:type" content="website">

	<meta property="og:title" content="Primacy Infitech Best website development company in kolkata">

	<meta property="og:description" content="Primacy Infotech- It is a website design and development company based in kolkata. We help small and mid sized company to achieve thier marketing goals. Call today - 9088015866">

	<meta property="og:image" content="http://primacyinfotech.com/assets/images/logo-p.png">

	<meta property="og:url" content="http://primacyinfotech.com/">

	<meta property="og:site_name" content="Primacy Infotech">

	<meta name="format-detection" content="telephone=no">
	<link rel="icon" href="../pilogofab.png" type="image/gif" sizes="HeightxWidth|any">



    <?php include '../include/header.php'; ?>
<!--end fixed header-->
	<!-- header -->

	

	
	<!--start model end-->

	<div id="myModal_grocery" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

		<div class="modal-dialog">

			<div class="modal-content">

				<div class="modal-header">

					<h3 class="text-danger" id="myModalLabel"><b>Submit Detail & Get discount</b></h3><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>



				</div>

				<div class="modal-body">

					<form class="form-horizontal col-sm-12" method="post">

						<div class="form-group"><label><b>Name</b></label>

							<input class="form-control required" placeholder="Your name" type="text" name="name" required></div>



						<div class="form-group"><label><b>E-Mail</b></label><input class="form-control email" placeholder="email@you.com (so that we can contact you)" type="email" name="email" required></div>



						<div class="form-group"><label><b>Phone</b></label><input class="form-control phone" placeholder="999-999-9999" name="phone" type="tel" required></div>



						<div class="form-group">

							<label><b>Select Services</b></label>

							<select name="services" class="form-control" required>

								<option value="">Select Services</option>

								<option value="Web Developemnt">Web Developemnt</option>

								<option value="Web Designing">Web Designing</option>

								<option value="MLM Softawre">MLM Softawre</option>

								<option value="Digital Marketing">Digital Marketing</option>

								<option value="Mobile APP Development">Mobile APP Development</option>

								<option value="Ecommerce Website">Ecommerce Website </option>

								<option selected value="Grocery Shop">Grocery Shop</option>

								<option value="LMS">Learning Mamagement System</option>

								<option value="CMS">Content Management System</option>

								<option value="Food Delivery App">Food Delivery App</option>

								<option value="Loan Management Software">Loan Management Software</option>

								<option value="OLA/Uber Clone">OLA/Uber Clone</option>

								<option value="Travel Portal Solution">Travel Portal Solution</option>

								<option value="Recharge Portal">Recharge Portal</option>

								<option value="Real Estate Portal">Real Estate Portal</option>

								<option value="Video Portal">Video Portal</option>

								<option value="Billing Software">Billing Software</option>

								<option value="Accounting Portal">Accounting Portal</option>









							</select>

						</div>

						<div class="form-group"><label><b>Message</b></label>

							<textarea class="form-control" name="message" placeholder="Your message here.." required></textarea></div>

						<div class="form-group">



							<!--          <p class="help-block pull-left text-danger hide" id="form-error">&nbsp; The form is not valid. </p>-->

						</div>

						<div class="modal-footer">

							<button type="submit" name="submit1" class="btn btn-success pull-right">Send It!</button>

							<button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>

						</div>

					</form>

				</div>



			</div>

		</div>

	</div>


	<!--end model-->

	<section class="home-1-banner main-banner bg-img bg-6" id="home">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-6 col-md-7">
					<div class="banner-content">
						<div class="ovh">
<h3 class="title wow slideInDownBig" data-wow-duration=".65s" data-wow-delay=".1s" style="visibility: visible; animation-duration: 0.65s; animation-delay: 0.1s; animation-name: slideInDownBig;">Launch Your Online Ecommerce App Without Any Hassle! Our Package Start From <span class="hightlight-price">1700/pm*</span> <br>CALL-<span class="title-header"> <a href="tel:+91 9088015866" class="">+91 9088015866</a> / <a href="tel:+91 9088015865" class="">65</a> </span></h3>
						</div>
						<div class="ovh">
							<p>Ecommerce App – Get Your Own online Ecommerce App like Flipkart, Amazon, Sanpdeal, Jabong, Bewakoof within 7 days. Primacy Infotech  introduces the ready-made mobile app solution for Ecommerce App. We have designed this mobile app solution with keeping in the mind the requirements of all sorts of Ecommerce app: Single Vendor, Multi Vendor and Multi Store. This app is a fully customizable solution which means it can be packaged for particular store, with Your brand name. </p>
						</div>
						<div class="btn-wrapper ovh">
	<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal_grocery" href="#"style="color: #000">Get Started <i class="icon-layers"></i></button>



							<button type="button" class="btn custom-btn mb" data-toggle="modal" data-target="#callback" href="#" style="color: #000"><i class="icon-phone"></i> Call Back Request</button>
						</div>
					</div>
				</div>
				<div class="col-lg-5 col-md-3 offset-lg-1 offset-md-2 banner-img-wrapper d-none d-md-block">
					<img src="../assets/images/pistore.png" class="banner-img-1 wow slideInUpAlt" data-wow-delay=".1s" alt="">
					<img src="../assets/images/pistore.png" class="banner-img-2 wow slideInRightAlt" alt="">
				</div>
			</div>
		</div>
	</section><!-- banner -->
	<div class="my-tab" id="my-tab">

		<div class="container">

			<div class="row">

				<div class="col-4 col-md-4">

					<div class="my-sec1">



						<a href="#feature">

							<div class="text-center">Features</div>

						</a>

					</div>

				</div>

				<div class="col-4 col-md-4">

					<div class="my-sec1">



						<a href="#demo">

							<div class="text-center">Demo</div>

						</a>

					</div>

				</div>

				<div class="col-4 col-md-4">

					<div class="my-sec1">



						<a href="#pricing">

							<div class="text-center" id="">Our Package</div>

						</a>

					</div>

				</div>





			</div>

		</div>

	</div>
<section class="h6-feature s-padding bg-color" id="feature">
		<div class="container">
			<div class="s-title">
				<h2>We offer Your Needs</h2>
				<!--<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->
			</div>
			<div class="row justify-content-center">
				<div class="col-lg-4">
					<div class="icon-box style-centered">
						<div class="icon-box-icon">
							<i class="icon_ribbon_alt"></i>
						</div>
						<div class="icon-box-details">
							<h3 class="icon-box-title">Top Grade Quality</h3>
							<p>We believe in quality rather than quantity that satisfy our clients. Many of our work approves at first attempt.</p>
						</div> 
					</div>
				</div>
				<div class="col-lg-4">
					<div class="icon-box style-centered">
						<div class="icon-box-icon">
							<i class="icon-diamond"></i>
						</div>
						<div class="icon-box-details">
							<h3 class="icon-box-title">Awesome Design</h3>
							<p>Your eCommerce website will be mobile friendly and Works on any mobile device so that you pass Google’s algorithm.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="icon-box style-centered">
						<div class="icon-box-icon">
							<i class="icon_headphones"></i>
						</div>
						<div class="icon-box-details">
							<h3 class="icon-box-title">Best Customer Support</h3>
							<p>This continuous communication with customers also creates a sense of belongingness between you and your customers.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="icon-box style-centered">
						<div class="icon-box-icon">
							<i class="icon-support"></i>
						</div>
						<div class="icon-box-details">
							<h3 class="icon-box-title">Free Regular Update</h3>
							<p>This continuous communication with customers also creates a sense of belongingness between you and your customers.</p>
						</div> 
					</div>
				</div>
				<div class="col-lg-4">
					<div class="icon-box style-centered">
						<div class="icon-box-icon">
							<i class="icon_genius"></i>
						</div>
						<div class="icon-box-details">
							<h3 class="icon-box-title">Highly Rated By Clients</h3>
							<p>Till the work goes we continue in touch with our clients by providing them regular work progress report and interacting them by online chatting or phone to know their views and ideas.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="icon-box style-centered">
						<div class="icon-box-icon">
							<i class="icon-rocket"></i>
						</div>
						<div class="icon-box-details">
							<h3 class="icon-box-title">Featured On TutsPlus</h3>
							<p>We don’t restrict to ourselves with old web development technologies but using latest ones like PSD to responsive HTML5 template, high quality graphic, responsive PSD design and many more.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- feature -->
		
<section class="faq-sec s-padding bg-color" id="faq">
		<div class="s-title">
			<h2>Product App Features</h2>
			<!--<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->
		</div>
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-5 d-none d-md-block">
					<div class="faq-sec-img">
					
						<img class="wow slideInLeft" src="../assets/images/sd2.png" alt="">
					</div>
				</div>
				<div class="col-lg-6 offset-lg-1">
					<div class="accordion" id="iconicAccordion">
					  	<div class="card accordion-item">
					   		<div class="accordion-header" id="accordionHeading1">
						      	<h5 class="mb-0">
						        	<button class="accordion-btn" type="button" data-toggle="collapse" data-target="#accordionItem1" aria-expanded="false" aria-controls="accordionItem1">
						        		<span class="accordion-icon"><i class="icon-settings"></i></span>
						        		<span class="accordion-title">Android App Features</span>
						        		<span class="accordion-arrow"><i class="arrow_carrot-down"></i></span>
						        	</button>
						      	</h5>
					    	</div>
					    	<div id="accordionItem1" class="collapse show" aria-labelledby="accordionHeading1" data-parent="#iconicAccordion">
					      		<div class="card-body accordion-body">
					        	   <ul class="">
					        	        <li>Selected Categories, Sub Categories and Products</li>
					        	         <li>Product Search and Filter</li>
					        	          <li> Product Details</li>
					        	           <li>Add To Cart</li>
					        	           <li>Basket Management</li>
					        	           <li>Checkout Transaction</li>
										   <li>Discount Products</li>
					        	         <li>Coupon Discount</li>
					        	          <li> Products Collection</li>
					        	           <li>User Favourite Product</li>
					        	           <li>User Login, Register and Logout</li>
					        	           <li>Facebook Login</li>
										   <li>Multi-Language ( Build In 16 Languages )</li>
					        	         <li> Support RTL</li>
					        	          <li> Push Notification (FCM)</li>
					        	           <li>Rating & Review</li>
					        	           <li>User Comment</li>
					        	           <li>Blog</li>
										   <li>Shipping Method</li>
					        	         <li>Payment getaway Integrated</li>
					        	          <li> About App</li>
					        	           <li>Integrated with Whatsapp and Facebook Messenger</li>
					        	         
					        	   </ul>
					      		</div>
					    	</div>
					  	</div>
					  	<div class="card accordion-item">
					    	<div class="accordion-header" id="accordionHeading2">
					      		<h5 class="mb-0">
					        		<button class="accordion-btn collapsed" type="button" data-toggle="collapse" data-target="#accordionItem2" aria-expanded="false" aria-controls="accordionItem2">
					          			<span class="accordion-icon"><i class="icon-support"></i></span>
						        		<span class="accordion-title">Admin Features</span>
						        		<span class="accordion-arrow"><i class="arrow_carrot-down"></i></span>
					        		</button>
					      		</h5>
					    	</div>
					    	<div id="accordionItem2" class="collapse" aria-labelledby="accordionHeading2" data-parent="#iconicAccordion">
					      		<div class="card-body accordion-body">
					        		   <ul class="">
					        	        <li>Shop Management</li>
					        	         <li>Category Management</li>
					        	          <li>Sub Category Management</li>
					        	           <li>Products Management</li>
					        	           <li>Discount Management</li>
										    <li>Products Collection Management</li>
					        	         <li> Blog Coupon Discount</li>
					        	          <li> Shipping Method Management</li>
					        	           <li>Product Comments Management</li>
					        	           <li>Product Favourite Management</li>
										    <li>Transaction Report</li>
					        	         <li>Most Popular Products</li>
					        	          <li>Most Purchase Products</li>
					        	           <li>Most Popular Categories</li>
					        	           <li>Most Purchase Categories</li>
										   <li>Most Rated Products</li>
					        	         <li>Push Notification</li>
					        	          <li> About App</li>
					        	           <li>App Version Control</li>
					        	       </ul>
					      		</div>
					    	</div>
					  	</div>
					  	
					  	<div class="card accordion-item">
					    	<div class="accordion-header" id="accordionHeading3">
					      		<h5 class="mb-0">
					        		<button class="accordion-btn collapsed" type="button" data-toggle="collapse" data-target="#accordionItem3" aria-expanded="false" aria-controls="accordionItem3">
					          			<span class="accordion-icon"><i class="icon-rocket"></i></span>
						        		<span class="accordion-title">Payment Feature</span>
						        		<span class="accordion-arrow"><i class="arrow_carrot-down"></i></span>
					        		</button>
					      		</h5>
					    	</div>
					    	<div id="accordionItem3" class="collapse" aria-labelledby="accordionHeading3" data-parent="#iconicAccordion">
					      		<div class="card-body accordion-body">
					      		    <ul class>
					        	<li>Paypal Integrated</li>
								<li>Credit card Integrated</li>
								<li>Debit card Integrated</li>
								<li>Paytm Integrated</li>
								<li>Phonepe Integrated</li>
								<li>UPI Integrated</li>
								<li>Amazon Integrated</li>
								<li>Google pay Integrated</li>
								<li>NetBanking Integrated</li>
					        	</ul>
					      		</div>
					    	</div>
					  	</div>
					  	<div class="card accordion-item">
					    	<div class="accordion-header" id="accordionHeading4">
					      		<h5 class="mb-0">
					        		<button class="accordion-btn collapsed" type="button" data-toggle="collapse" data-target="#accordionItem4" aria-expanded="false" aria-controls="accordionItem4">
					          			<span class="accordion-icon"><i class="icon-diamond"></i></span>
						        		<span class="accordion-title">Amet Consequateta Adipisicing?</span>
						        		<span class="accordion-arrow"><i class="arrow_carrot-down"></i></span>
					        		</button>
					      		</h5>
					    	</div>
					    	<div id="accordionItem4" class="collapse" aria-labelledby="accordionHeading4" data-parent="#iconicAccordion">
					      		<div class="card-body accordion-body">
					        		Think tank bandwidth academic; effective then activate circular paradigm deep dive. Contextualize support inclusion, entrepreneur ideate; mass incarceration social return on investment collective.!
					      		</div>
					    	</div>
					  	</div>
					</div>
				</div>
			</div>
		</div>
	</section>	
	
	
<section class="h6-app-screenshot s-padding" id="demo">
		<div class="container">
			<div class="s-title">
				<h2>App Screenshots</h2>
				<!--<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->
			</div>
			<div class="row justify-content-center">
				<div class="col-lg-10">
					<div class="swiper-container app-screenshot-slider-2">
					    <div class="swiper-wrapper">
					        <div class="swiper-slide">
					        	<div class="app-screenshot-item style-2">
					        		<img src="../assets/images/processed.jpeg" alt="">
					        	</div>
					        </div>
					        <div class="swiper-slide">
					        	<div class="app-screenshot-item style-2">
					        		<img src="../assets/images/processed-3.jpeg" alt="">
					        	</div>
					        </div>
					        <div class="swiper-slide">
					        	<div class="app-screenshot-item style-2">
					        		<img src="../assets/images/processed-6.jpeg" alt="">
					        	</div>
					        </div>
					        <div class="swiper-slide">
					        	<div class="app-screenshot-item style-2">
					        		<img src="../assets/images/processed-3.jpeg" alt="">
					        	</div>
					        </div>
					        <div class="swiper-slide">
					        	<div class="app-screenshot-item style-2">
					        		<img src="../assets/images/processed-4.jpeg" alt="">
					        	</div>
					        </div>
					             <div class="swiper-slide">
					        	<div class="app-screenshot-item style-2">
					        		<img src="../assets/images/processed.jpeg" alt="">
					        	</div>
					        </div>
					             <div class="swiper-slide">
					        	<div class="app-screenshot-item style-2">
					        		<img src="../assets/images/processed-6.jpeg" alt="">
					        	</div>
					        </div>
					    </div>
					    <div class="swiper-pagination"></div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- app-screenshot -->
	
<section class="pricing s-padding" id="pricing">
		<div class="container">
			<div class="s-title">
				<h2>Our Packages</h2>
				<!--<p>Ut totam hymenaeos a quasi enim, duis erat mollitia, pellentesque ac metus!</p>-->
			</div>
			<div class="row">
				<div class="col-12">
					<div class="pricing-tables-wrapper">
						<ul class="nav nav-tabs pricing-tab" id="pricing-tab" role="tablist">
							<li class="nav-item">
						    	<a class="" id="monthly-pricing" data-toggle="tab" href="#monthly-pricing-tables" role="tab">One Time</a>
						  	</li>
						  
						  		<li class="nav-item">
						    	<a class="active" id="halfyearly-pricing" data-toggle="tab" href="#halfyearly-pricing-tables" role="tab">Half Yearly</a>
						  	</li>
						  		<li class="nav-item">
						    	<a class="" id="yearly-pricing" data-toggle="tab" href="#yearly-pricing-tables" role="tab">Yearly</a>
						  	</li>
						</ul>
						<div class="tab-content" id="pricing-tab-content">
				<div class="tab-pane fade" id="monthly-pricing-tables" role="tabpanel" aria-labelledby="monthly-pricing">
						  		<div class="row">
				<div class="col-md-4 ftco-animate fadeInUp ftco-animated">
                    <div class="pricing-entry pb-5 text-center">
                        <div>
                            <h3 class="mb-4">Starter</h3>
                                    <!--<p><span class="price">INR 15000<span class="tcs-star">*</span> / </span><span class="label label-danger"><del>INR 2000</del> / Month</span> </p>-->
                            <p><span class="price">Rs 15,000</span></p>
<!--                                     <span class="tcs-star">*</span> / </span><span class="label label-danger"><del>INR 20000</del> </span> -->
                                   
<!--                                    <p><span class="alert btn-warning">25 % OFF</span> <span class="btn alert-success">Save INR 500 / Month</span></p>-->


                            
                        </div>
                        <ul>
<!--                            <li><span class="pricing-validity btn alert alert-primary">Setup Charges - INR 7000</span></li>-->
                                <li>Cloud Separate Server</li>
                                <li>Unlimited Products &amp; Customers</li>
                                <li> Website, Admin &amp; <del> Android APP</del></li>
                               
                                <li>Branding, Custom icon, Logo, Splash screen</li>
                                <li>App Analytics</li>
                                <li>Free Payment Gateway Setup</li>
                                <li>COD</li>
                                <li><del>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</del></li>
                                <li>Push Notifications</li>
                                <li><del>Bulk Import / Export</del></li>
                                <li><del>Bulk SMS - Custom SMS Templates</del></li>
                                <li>Multi Admin Control</li>
                                <li>Multi Language Options</li>
                                <li><del>National / International Currencies</del></li>
                                <li>Easy and Quick Checkout</li>
                                <li><del>National Payment Gateways</del></li>
                                <li>Postcode Shipping</li>
                                <li><del>Delivery Slots</del></li>
                                <li><del>Refer and Earn, Rewards</del></li>
                                <li>SEO</li>
                                <li>Report Management</li>
                                <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                                <li><div class="pricing-validity btn alert alert-primary"><p style="color: #004085;"><b>* Excluding Server and support<br></b></p></div>
                                </li>
                                <!--<li><div class="pricing-validity btn alert alert-primary"><p style="color: #004085;"><b>* Excluding Server and support<br>-->
                                <!-- Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 1500 + Setup Charges 7000 = 25000*">Yearly - INR 1500 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 1615 + Setup Charges 7000 = 16690*">Half Yearly - INR 1615 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 1750 + Setup Charges 7000 = 12250*">Quarterly - INR 1750 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 2000 + Setup Charges 7000 = 9000*">Monthly - INR 2000 / month</h6><p></p>-->
                                
                                 
                        </ul>
                        <p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
                    </div>
                </div>
                <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
                    <div class="pricing-entry pb-5 text-center">
                        <div>
                            <h3 class="mb-4">Professional</h3>
                                    <!--<p><span class="price">INR 25000<span class="tcs-star">*</span> / </span><span class="label label-danger"><del>INR 30000</del> / Month</span> </p>-->
                                      <p><span class="price">Rs 25,000</span> </p>
<!--
                                      <span class="tcs-star">*</span> / </span><span class="label label-danger"><del>INR 30000</del> 
                                    <p><span class="alert btn-warning">30 % OFF</span> <span class="btn alert-success">Save INR 900 / Month</span></p>
-->

                        </div>
                        <ul>
<!--                            <li><span class="pricing-validity btn alert alert-primary">Setup Charges - INR 7000</span></li>-->
                                <li>Cloud Separate Server</li>
                                <li>Unlimited Products &amp; Customers</li>
                                <li>Android APP, <del>Website</del> &amp; Admin </li>
                                <li>Branding, Custom icon, Logo, Splash screen</li>
                                <li>App Analytics</li>
                                <li><del>Free Payment Gateway Setup</del></li>
                                <li>COD</li>
                                <li>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</li>
                                <li>Push Notifications</li>
                                <li>Bulk Import / Export</li>
                                <li>Bulk SMS - Custom SMS Templates</li>
                                <li>Multi Admin Control</li>
                                <li>Multi Language Options</li>
                                <li>National / International Currencies</li>
                                <li>Easy and Quick Checkout</li>
                                <li>National Payment Gateways</li>
                                <li>Postcode Shipping</li>
                                <li>Delivery Slots</li>
                                <li>Refer and Earn, Rewards</li>
                                <li>SEO</li>
                                <li>Report Management</li>
                                <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                                  <li><div class="pricing-validity btn alert alert-primary"><p style="color: #004085;"><b>* Excluding Server and support<br></b></p>
                                <!--<li><div class="pricing-validity btn alert alert-primary"><p style="color: #004085;"><b>* Excluding Server and support<br>-->
                                <!-- Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 1500 + Setup Charges 7000 = 25000*">Yearly - INR 1500 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 1615 + Setup Charges 7000 = 16690*">Half Yearly - INR 1615 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 1750 + Setup Charges 7000 = 12250*">Quarterly - INR 1750 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 2000 + Setup Charges 7000 = 9000*">Monthly - INR 2000 / month</h6><p></p>-->
                                
                                 </div>
                                </li>
                        </ul>
                       <p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
                    </div>
                </div>
                <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
                    <div class="pricing-entry pb-5 text-center">
                        <div>
                            <h3 class="mb-4">Advance</h3>
                                    <!--<p><span class="price">INR 45000<span class="tcs-star">*</span> / </span><span class="label label-danger"><del>INR 50000</del> / Month</span> </p>-->
                                    <p><span class="price">Rs 45,000</span> </p>
<!--
                                    <span class="tcs-star">*</span> / </span><span class="label label-danger"><del>INR 50000</del>
                                    <p><span class="alert btn-warning">40 % OFF</span> <span class="btn alert-success">Save INR 200 / Month</span></p>
-->
                                <p>
                                    <span class="pricing-new">
                                        <img src="../assets/images/new.png">
                                    </span>
                                </p>
                                <p class="button text-center pricing-rec">
                                    <span class=" alert btn btn-primary">
                                        Recommended
                                    </span>
                                </p>
                        </div>
                        <ul>
<!--                            <li><span class="pricing-validity btn alert alert-primary">Setup Charges - INR 7000</span></li>-->
                                <li>Cloud Separate Server [Double RAM]</li>
                                <li>Unlimited Products &amp; Customers</li>
                                <li>Android APP, Website &amp; Admin </li>
                                <li>Branding, Custom icon, Logo, Splash screen</li>
                                <li>App Analytics</li>
                                <li>Free Payment Gateway Setup</li>
                                <li>COD</li>
                                <li>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</li>
                                <li>Push Notifications</li>
                                <li>Bulk Import / Export</li>
                                <li>Bulk SMS - Custom SMS Templates</li>
                                <li>Multi Admin Control</li>
                                <li>Multi Language Options</li>
                                <li>National / International Currencies</li>
                                <li>Easy and Quick Checkout</li>
                                <li>National Payment Gateways</li>
                                <li>Postcode Shipping</li>
                                <li>Delivery Slots</li>
                                <li>Refer and Earn, Rewards</li>
                                <li>SEO</li>
                                <li>Report Management</li>
                                <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                                <li><div class="pricing-validity btn alert alert-primary"><p style="color: #004085;"><b>* Excluding Server and support<br></b></p>
                                <!--<li><div class="pricing-validity btn alert alert-primary"><p style="color: #004085;"><b>* Excluding Server and support<br>-->
                                <!-- Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 1500 + Setup Charges 7000 = 25000*">Yearly - INR 1500 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 1615 + Setup Charges 7000 = 16690*">Half Yearly - INR 1615 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 1750 + Setup Charges 7000 = 12250*">Quarterly - INR 1750 / month</h6>-->
                                 <!--<h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 2000 + Setup Charges 7000 = 9000*">Monthly - INR 2000 / month</h6><p></p>-->
                                 </div>
                                </li>
                        </ul>
                       <p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
                    </div>
                </div>
						  		
						  		</div>
						  	</div>
                <div class="tab-pane fade show active" id="halfyearly-pricing-tables" role="tabpanel" aria-labelledby="halfyearly-pricing">
                    <div class="row">
                                 <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h3 class="mb-4">Starter</h3>
                        <!--<p><span class="price">INR 13200<span class="tcs-star">*</span> / </span><span class="label label-danger"><del>INR 220000</del> / Month</span> </p>-->
                        <p><span class="price">Rs 1700<span class="tcs-star">/</span> pm </span><span class="label label-danger"><del>Rs 2000/pm</del> </span> </p>
                         <p><span class="alert btn-warning">20 % OFF</span> <span class="btn alert-success">Save Rs 300 / Month</span></p>
<!--                        <p><span class="alert btn-warning">15% OFF</span> <span class="btn alert-success">Save Rs 300 / Month</span></p>-->
            </div>
            <ul>
                <li><span class="pricing-validity btn alert alert-primary">Setup Charges - Rs 3000</span></li>
                   
                   <li><span class="pricing-validity btn alert alert-primary">First Payment (1700*6+3000)=13200</span></li>
                    <li>Cloud Separate Server</li>
                    <li>Unlimited Products &amp; Customers</li>
                    <li> Website,Admin &amp; <del> Android APP,</del></li>
                    <li>Branding, Custom icon, Logo, Splash screen</li>
                    <li>App Analytics</li>
                    <li>Free Payment Gateway Setup</li>
                    <li>COD</li>
                    <li><del>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</del></li>
                    <li>Push Notifications</li>
                    <li><del>Bulk Import / Export</del></li>
                    <li><del>Bulk SMS - Custom SMS Templates</del></li>
                    <li>Multi Admin Control</li>
                    <li>Multi Language Options</li>
                    <li><del>National / International Currencies</del></li>
                    <li>Easy and Quick Checkout</li>
                    <li><del>National Payment Gateways</del></li>
                    <li>Postcode Shipping</li>
                    <li><del>Delivery Slots</del></li>
                    <li><del>Refer and Earn, Rewards</del></li>
                    <li>SEO</li>
                    <li>Report Management</li>
                    <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                    <li>
                        <div class="pricing-validity btn alert alert-primary">
                            <p style="color: #004085;font-size: 12px;"><b>* Including Server and 6 month Support<br> Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>
<!--
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 1500 + Setup Charges 7000 = 25000*">Yearly - INR 1500 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 1615 + Setup Charges 7000 = 16690*">Half Yearly - INR 1615 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 1750 + Setup Charges 7000 = 12250*">Quarterly - INR 1750 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 2000 + Setup Charges 7000 = 9000*">Monthly - INR 2000 / month</h6>
-->
                            <p></p>
                        </div>
                    </li>
            </ul>
<p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
       
        </div>
        
    </div>
    <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h3 class="mb-4">Professional</h3>
                        <p><span class="price">Rs 2500<span class="tcs-star">/</span> pm </span><span class="label label-danger"><del>Rs 3100/pm</del></span> </p>
                        <p><span class="alert btn-warning">30 % OFF</span> <span class="btn alert-success">Save Rs 600 / Month</span></p>
            </div>
            <ul>
                <li><span class="pricing-validity btn alert alert-primary">Setup Charges - Rs 3000</span></li>
            <li><span class="pricing-validity btn alert alert-primary">First Payment (2500x6+3000)=18000</span></li>
                                                <li>Cloud Separate Server</li>
                    <li>Unlimited Products &amp; Customers</li>
                    <li>Android APP, <del>Website </del>&amp; Admin </li>
                    <li>Branding, Custom icon, Logo, Splash screen</li>
                    <li>App Analytics</li>
                    <li>Free Payment Gateway Setup</li>
                    <li>COD</li>
                    <li>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</li>
                    <li>Push Notifications</li>
                    <li>Bulk Import / Export</li>
                    <li>Bulk SMS - Custom SMS Templates</li>
                    <li>Multi Admin Control</li>
                    <li>Multi Language Options</li>
                    <li>National / International Currencies</li>
                    <li>Easy and Quick Checkout</li>
                    <li>National Payment Gateways</li>
                    <li>Postcode Shipping</li>
                    <li>Delivery Slots</li>
                    <li>Refer and Earn, Rewards</li>
                    <li>SEO</li>
                    <li>Report Management</li>
                    <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                    <li>
                        <div class="pricing-validity btn alert alert-primary">
                            <p style="color: #004085;font-size: 12px;"><b>* Including Server and 6 month Support<br> Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>
<!--
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 2100 + Setup Charges 7000 = 32200*">Yearly - INR 2100 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 2261 + Setup Charges 7000 = 20566*">Half Yearly - INR 2261 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 2450 + Setup Charges 7000 = 14350*">Quarterly - INR 2450 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 3000 + Setup Charges 7000 = 10000*">Monthly - INR 3000 / month</h6>
-->
                            <p></p>
                        </div>
                    </li>
                    </ul>
<p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
        
    </div>
    <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h3 class="mb-4">Advance</h3>
                        <p><span class="price">Rs 3900<span class="tcs-star">/</span> pm </span><span class="label label-danger"><del>Rs 4600/pm</del></span> </p>
                        <p><span class="alert btn-warning">40 % OFF</span> <span class="btn alert-success">Save Rs 700 / Month</span></p>
                    <p>
                        <span class="pricing-new">
                            <img src="../assets/images/new.png">
                        </span>
                    </p>
                    <p class="button text-center pricing-rec">
                        <span class=" alert btn btn-primary">
                            Recommended
                        </span>
                    </p>
            </div>
            <ul>
                <li><span class="pricing-validity btn alert alert-primary">Setup Charges - Rs 3000</span></li>
                 <li><span class="pricing-validity btn alert alert-primary">First Payment 3900x6+3000=[26400]</span></li>
                                                <li>Cloud Separate Server [Double RAM]</li>
                    <li>Unlimited Products &amp; Customers</li>
                    <li>Android APP, Website &amp; Admin </li>
                    <li>Branding, Custom icon, Logo, Splash screen</li>
                    <li>App Analytics</li>
                    <li>Free Payment Gateway Setup</li>
                    <li>COD</li>
                    <li>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</li>
                    <li>Push Notifications</li>
                    <li>Bulk Import / Export</li>
                    <li>Bulk SMS - Custom SMS Templates</li>
                    <li>Multi Admin Control</li>
                    <li>Multi Language Options</li>
                    <li>National / International Currencies</li>
                    <li>Easy and Quick Checkout</li>
                    <li>National Payment Gateways</li>
                    <li>Postcode Shipping</li>
                    <li>Delivery Slots</li>
                    <li>Refer and Earn, Rewards</li>
                    <li>SEO</li>
                    <li>Report Management</li>
                    <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                    <li>
                        <div class="pricing-validity btn alert alert-primary">
                            <p style="color: #004085;font-size: 12px;"><b>* Including Server and 6 month Support<br> Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>
<!--
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 3000 + Setup Charges 7000 = *43000">Yearly - INR 3000 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 3231 + Setup Charges 7000 = *26386">Half Yearly - INR 3231 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 3500 + Setup Charges 7000 = *17500">Quarterly - INR 3500 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 5000 + Setup Charges 7000 = *12000">Monthly - INR 5000 / month</h6>
-->
                            <p></p>
                        </div>
                    </li>
            </ul>
<p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
        
    </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="yearly-pricing-tables" role="tabpanel" aria-labelledby="yearly-pricing">
                    <div class="row">
                                 <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h3 class="mb-4">Starter</h3>
                        <p><span class="price">Rs 1400<span class="tcs-star">/</span> pm </span><span class="label label-danger"><del>Rs 1700/pm</del> </span> </p>
                        <p><span class="alert btn-warning">25 % OFF</span> <span class="btn alert-success">Save INR 300 / Month</span></p>
            </div>
            <ul>
                <li><span class="pricing-validity btn alert alert-primary">Setup Charges - INR 3000</span></li>
                   <li><span class="pricing-validity btn alert alert-primary">First Payment (1400x12+3000)=19800</span></li>
                    <li>Cloud Separate Server</li>
                    <li>Unlimited Products &amp; Customers</li>
                    <li>Website,Admin &amp; <del> Android APP</del></li>
                    <li>Branding, Custom icon, Logo, Splash screen</li>
                    <li>App Analytics</li>
                    <li>Free Payment Gateway Setup</li>
                    <li>COD</li>
                    <li><del>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</del></li>
                    <li>Push Notifications</li>
                    <li><del>Bulk Import / Export</del></li>
                    <li><del>Bulk SMS - Custom SMS Templates</del></li>
                    <li>Multi Admin Control</li>
                    <li>Multi Language Options</li>
                    <li><del>National / International Currencies</del></li>
                    <li>Easy and Quick Checkout</li>
                    <li><del>National Payment Gateways</del></li>
                    <li>Postcode Shipping</li>
                    <li><del>Delivery Slots</del></li>
                    <li><del>Refer and Earn, Rewards</del></li>
                    <li>SEO</li>
                    <li>Report Management</li>
                    <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                    <li>
                        <div class="pricing-validity btn alert alert-primary">
                            <p style="color: #004085;font-size:12px;"><b>* Including 1 Year Support and Server
                                    <br> Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>
<!--
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 1500 + Setup Charges 7000 = 25000*">Yearly - INR 1500 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 1615 + Setup Charges 7000 = 16690*">Half Yearly - INR 1615 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 1750 + Setup Charges 7000 = 12250*">Quarterly - INR 1750 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 2000 + Setup Charges 7000 = 9000*">Monthly - INR 2000 / month</h6>
-->
                            <p></p>
                        </div>
                    </li>
            </ul>
<p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
   
    </div>
    <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h3 class="mb-4">Professional</h3>
                        <p><span class="price">Rs 2200<span class="tcs-star">/</span> pm </span><span class="label label-danger"><del>Rs 2600/pm</del> </span> </p>
                        <p><span class="alert btn-warning">30 % OFF</span> <span class="btn alert-success">Save Rs 400 / Month</span></p>

            </div>
            <ul>
                <li><span class="pricing-validity btn alert alert-primary">Setup Charges - Rs 3000</span></li>
               <li><span class="pricing-validity btn alert alert-primary">First Payment (2200x12+3000)=29400</span></li>
                    <li>Cloud Separate Server</li>
                    <li>Unlimited Products &amp; Customers</li>
                    <li>Android APP, <del>Website </del>&amp; Admin </li>
                    <li><del>iOS App</del></li>
                    <li>Branding, Custom icon, Logo, Splash screen</li>
                    <li>App Analytics</li>
                    <li>Free Payment Gateway Setup</li>
                    <li>COD</li>
                    <li>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</li>
                    <li>Push Notifications</li>
                    <li>Bulk Import / Export</li>
                    <li>Bulk SMS - Custom SMS Templates</li>
                    <li>Multi Admin Control</li>
                    <li>Multi Language Options</li>
                    <li>National / International Currencies</li>
                    <li>Easy and Quick Checkout</li>
                    <li>National Payment Gateways</li>
                    <li>Postcode Shipping</li>
                    <li>Delivery Slots</li>
                    <li>Wallet System, Money Transfer</li>
                    <li>Refer and Earn, Rewards</li>
                    <li>SEO</li>
                    <li>Report Management</li>
                    <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                    <li>
                        <div class="pricing-validity btn alert alert-primary">
                            <p style="color: #004085;font-size: 12px;"><b>* Including 1 Year Support and Server
                                    <br> Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>
<!--
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="12 Months X 2100 + Setup Charges 7000 = 32200*">Yearly - INR 2100 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 2261 + Setup Charges 7000 = 20566*">Half Yearly - INR 2261 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="3 Months X 2450 + Setup Charges 7000 = 14350*">Quarterly - INR 2450 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1 Month X 3000 + Setup Charges 7000 = 10000*">Monthly - INR 3000 / month</h6>
-->
                            <p></p>
                        </div>
                    </li>
            </ul>
<!--            <p class="button text-center"><a href="/Contact" class="btn btn-primary px-4 py-3">Get Offer</a></p>-->
       <p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
       
    </div>
    <div class="col-md-4 ftco-animate fadeInUp ftco-animated">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h3 class="mb-4">Advance</h3>
                        <p><span class="price">Rs 3300<span class="tcs-star">/</span> pm </span><span class="label label-danger"><del>Rs 3800/pm</del> </span> </p>
                        <p><span class="alert btn-warning">40 % OFF</span> <span class="btn alert-success">Save Rs 500 / Month</span></p>
                    <p>
                        <span class="pricing-new">
                            <img src="../assets/images/new.png">
                        </span>
                    </p>
                    <p class="button text-center pricing-rec">
                        <span class=" alert btn btn-primary">
                            Recommended
                        </span>
                    </p>
            </div>
            <ul>
                <li><span class="pricing-validity btn alert alert-primary">Setup Charges - Rs 3000</span></li>
                   <li><span class="pricing-validity btn alert alert-primary">First Payment (3300x12+3000)=42600</span></li>
                    <li>Cloud Separate Server [Double RAM]</li>
                    <li>Unlimited Products &amp; Customers</li>
                    <li>Android APP, Website &amp; Admin </li>
                    <li>iOS App</li>
                    <li>Branding, Custom icon, Logo, Splash screen</li>
                    <li>App Analytics</li>
                    <li>Free Payment Gateway Setup</li>
                    <li>COD</li>
                    <li>Online Payment - Credit, Debit, Net transfer, BHIM, UPI</li>
                    <li>Push Notifications</li>
                    <li>Bulk Import / Export</li>
                    <li>Bulk SMS - Custom SMS Templates</li>
                    <li>Multi Admin Control</li>
                    <li>Multi Language Options</li>
                    <li>National / International Currencies</li>
                    <li>Easy and Quick Checkout</li>
                    <li>National Payment Gateways</li>
                    <li>Postcode Shipping</li>
                    <li>Delivery Slots</li>
                    <li>Wallet System, Money Transfer</li>
                    <li>Refer and Earn, Rewards</li>
                    <li>SEO</li>
                    <li>Report Management</li>
                    <li>Promotional Coupons, Customer Reviews, Feedback, etc.</li>
                    <li>
                        <div class="pricing-validity btn alert alert-primary">
                            <p style="color: #004085;font-size: 12px;"><b>* Including 1 Year Support and Server
                            <br> Yearly, Half Yearly, Quarterly, Monthly<br> Payment Options are available</b></p>
<!--
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" >Yearly - Rs 3300 / month</h6>
                            <h6 class="alert alert-warning" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="6 Months X 3231 + Setup Charges 7000 = *26386">Half Yearly - INR 3231 / month</h6>
-->
                            
                            <p></p>
                        </div>
                    </li>
            </ul>
           <p class="button text-center"><a data-toggle="modal" data-target="#myModal_grocery" href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
<!--        <button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal_grocery" href="#">Get Started <i class="icon-layers"></i></button>-->
  
    </div>
                    </div>
                </div>


						  	
						  	
						</div>
					</div>
				</div>
			</div> 
		</div>
	</section><!-- pricing -->		
	
	
	
	
	
	
	
	
			
		
		
	
	<section class="fun-fact s-padding bg-img bg-1">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-cloud-down"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">80</span><span>+</span></div>
						<h4>Total Clients</h4>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-thumb-up"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">240</span><span>+</span></div>
						<h4>Website Completed</h4>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-star"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">150</span><span>+</span></div>
						<h4>Sucessfully Run</h4>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="counter-item boxed-style">
						<div class="counter-item-icon">
							<i class="ti-face-smile"></i>
						</div>
						<div class="counter-item-count"><span class="counter-count">95</span><span>%</span></div>
						<h4>Return Customer</h4>
					</div>
				</div>
			</div>
		</div>
	</section><!-- fun-fact -->
	<section class="testimonial s-padding bg-color">
		<div class="bg-text">Feedback</div>
		<div class="container">
			<div class="s-title">
				<h2><span class="logo-color">W</span>hat Customer Says</h2>
				<p></p>
			</div>
			<div class="row justify-content-center">
				<div class="col-lg-7">
					<div class="testimonial-slider-wrapper testimonial-one-item-slider-wrapper">
						<div class="swiper-container testimonial-one-item-slider">
						    <div class="swiper-wrapper">
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="../assets/images/debasis.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“Great Team to work with, really attentive and react to request immediately. Excellent work and I'm really pleased with the results. Thanks Primacy Infotech Pvt. Ltd..”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">DEBASISH BISWAS
 <span class="reviewer-deg">Chief Instructor of Gpluseducation
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="../assets/images/ayon-roy.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“If you are looking for a Web Development company who is fast, organized and very detailed oriented... then you will find it with Primacy Infotech Pvt. Ltd. They designed, our idea of a website to all our specifications. They also made many creative improvements that we never thought of. We would recommend Primacy Infotech Pvt. Ltd. to anyone. ”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">AYAN ROY
 <span class="reviewer-deg">Director of Relaxindia.org
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="../assets/images/anwar.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“They provide great quality for the best prices that I have found in the business. I have been very happy with their work to date and recommend them highly. Thanks for the good job ....I LOVE my new website. ”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">ANWAR SEKH
 <span class="reviewer-deg"> MD of Epariseva.com
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="testimonial-item style-5">
						        		<div class="author-img">
						        			<img src="../assets/images/sumanta.jpg" alt="">
						        		</div>
						        		<div class="testimonial-content">
						        			“We came to Primacy Infotech Pvt. Ltd. with a vision for our website. you listened, that vision with your constructive criticism and insight, produced a very attractive website! We hear nothing but positive comments! So again, THANK YOU! ”
						        		</div>
						        		<div class="testimonial-meta">
						        			<div class="t-meta-info">
						        				<h4 class="reviewer-name">SUMANTA BHATTACHARJEE.
 <span class="reviewer-deg">Director of Institute of Alternative Medicines Kolkata
</span></h4>
							        			<div class="rating-star">
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<i class=" icon_star_alt"></i>
													<span>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star"></i>
														<i class="icon_star-half_alt"></i>
													</span>
												</div>
						        			</div>
						        		</div>
						        	</div>
						        </div>
						    </div>
						    <div class="swiper-pagination"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- testimonial -->
 <section class="h4-contact s-padding bg-color" id="contact">
		<div class="container">
			<div class="row">
				<div class="col-md-4 offset-md-1 ">
					<div class="iconic-contact-info">
						<div class="contact-info-head">
							<h2>Contact Information</h2>
							
						</div>
						<ul class="f-contact-list">
						   <li><span><img src="../assets/images/inddd.png" alt="india"></span><span>India Office</span></li>
							<li> <span><i class="fa fa-map-marker"></i>
</span>BF 79,BF Block ,Sector I,Salt Lake, Kolkata-64,WB,India</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span> +91 9088015866,+91 9088015865</li>
							<li><span><i class="fa fa-envelope"></i></span> info@primacyinfotech.com</li>
						</ul>
						<br/>
						<ul class="f-contact-list">
						<li><span><img style="width:20px;" src="../assets/images/canada-flag-xs.png" alt="canada"></span><span>Canada Office</span></li>
						
							<li> <span><i class="fa fa-map-marker"></i>
</span>656 Full Moon Circle Mississauga ON</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span>+1 6474908004</li>
							<li><span><i class="fa fa-envelope"></i></span> info@primacyinfotech.com</li>
						</ul>
						
						<ul class="f-contact-list">
						<li><span><img style="width:20px;" src="../assets/images/bangladesh-flag-xs.png" alt="bangladesh"></span><span>Bangladesh Office</span></li>
						
				
			           <li><span><i class="fa fa-map-marker"></i>
</span>31,KR PLAZA,Purana Paltan,Dhaka-1000</li>
							
							<li><span><i class="fa fa-volume-control-phone" ></i></span> +88 01759787636</li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-6 ">
						<br/><br/><br/>
					<form class="contact-form" method="post">
						<div class="form-row">
							<div class="form-group col-md-6">
								<input type="text" name="name" class="form-control" placeholder="Name">
							</div>
							<div class="form-group col-md-6">
								<input type="tel" name="phone" class="form-control" placeholder="Phone">
							</div>
						</div>
						<div class="form-row">
						<div class="form-group col-md-6">
								<input type="email" name="email" class="form-control" placeholder="Email">
							</div>
						<div class="form-group col-md-6">
							<select name="services" class="form-control">
								<option value="">Select Services</option>
								<option value="Web Developemnt">Web Developemnt</option>
								<option value="Web Designing">Web Designing</option>
								<option value="MLM Softawre">MLM Softawre</option>
								<option value="Digital Marketing">Digital Marketing</option>
								<option value="Mobile APP Development">Mobile APP Development</option>
								<option value="Ecommerce Website">Ecommerce Website </option>
								<option value="Grocerry Shop">Grocerry Shop</option>
								<option value="LMS">LMS</option>
								<option value="CMS">CMS</option>
								<option value="Food Delivery App">Food Delivery App</option>
								<option value="Loan Management Software">Loan Management Software</option>
								<option value="OLA/Uber Clone">OLA/Uber Clone</option>
								<option value="Travel Portal Solution">Travel Portal Solution</option>
								<option value="Recharge Portal">Recharge Portal</option>
								<option value="Real Estate Portal">Real Estate Portal</option>
								<option value="Video Portal">Video Portal</option>
								<option value="Billing Software">Billing Software</option>
								<option value="Accounting Portal">Accounting Portal</option>
								
								
								
								
							</select>
						</div>
						</div>
						<div class="form-group">
							<input type="text" name="subject" class="form-control" placeholder="Subject">
						</div>
						<div class="form-group">
							<textarea name="message" class="form-control" rows="5" placeholder="Message"></textarea>
						</div>
						<div class="text-lg-right">
							<button type="submit" name="submit3"  class="btn fill-style">SEND MESSAGE</button>
						</div>
					</form>
				</div>
				
				
			</div>
		</div>
	</section>
	
		<!-- footer -->

    <?php include '../include/menu.php'; ?>


    <?php include '../include/footer.php'; ?>


</head>



</html>	<script>
		$(window).load(function() {
			$('#myModal_grocery').modal('show');
		});
	</script>
