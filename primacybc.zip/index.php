<!DOCTYPE html>
<html lang="en-US" class="mob">
   

<hader>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  			<!-- Chrome, Firefox OS and Opera -->
<meta name="theme-color" content="#ba1217">
    <title>Primacy Infotech Best web &amp; Mobile Application Development Company in India</title>
<!-- This site is optimized with the Yoast SEO Premium plugin v4.0 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="description" content="We are one of the best web & app development company in India.We provide IT Service in reasonable price. Contact 09875627563"/>
<meta name="robots" content="noodp"/>
<meta name="keywords" content="Best Website Design &amp; Development Company in India, Digital Marketing company in India, App development company in India, Online groccery shop in India, Online Groccery, SEO Development Company in India, Travel Portal, School Management Software in India "/>

<link rel="publisher" href="https://plus.google.com/+PrimacyInfotechPvtLtdBaruipur/"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Primacy Infotech Best web &amp; Mobile Application Development Company in India" />
<meta property="og:description" content="Primacy Infotech Pvt. Ltd. is one of the best website design development company" />
<meta property="og:url" content="index.html" />
<meta property="og:site_name" content="Primacy Infotech" />
<meta property="og:image" content="../primacyinfotech.in/wp-content/uploads/2015/04/FotoJet.jpg" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="Primacy Infotech is one of the best website design &amp; development company in Kolkata. We provide affordable all type of IT solution. Contact Us : 09875627563" />
<meta name="twitter:title" content="website design &amp; development company, Affordable Price" />
<meta name="twitter:site" content="@primacyinfotech" />
<meta name="twitter:image" content="../primacyinfotech.in/wp-content/uploads/2015/04/FotoJet.jpg" />
<meta name="twitter:creator" content="@primacyinfotech" />
<meta property="DC.date.issued" content="2015-04-24T00:22:56+05:30" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/primacyinfotech.in\/","name":"Primacy Infotech Pvt. Ltd.","alternateName":"Best Webdesign Company in Kokata","potentialAction":{"@type":"SearchAction","target":"https:\/\/primacyinfotech.in\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"Organization","url":"https:\/\/primacyinfotech.in\/","sameAs":["https:\/\/www.facebook.com\/primacyit\/","index.html\/\/www.linkedin.com\/company\/primacy-infotech-pvt-ltd","index.html\/\/plus.google.com\/+PrimacyInfotechPvtLtdBaruipur\/","index.html\/\/www.youtube.com\/channel\/UCa4mcQ046494I8Vieqhg0Ow","index.html\/\/www.pinterest.com\/primacyinfotech\/","https:\/\/twitter.com\/primacyinfotech"],"@id":"#organization","name":"Primacy Infotech Pvt. Ltd.","logo":"http:\/\/primacyinfotech.in\/wp-content\/uploads\/2016\/05\/primacy-infotech-logo-n1.png"}</script>
<meta name="msvalidate.01" content="AFE60094AC8A24AC50C83C66A278D2B0" />
<meta name="google-site-verification" content="i6toY7ZSmG-v6ScE-4uIBP0_wYWV1ayIEikgFmxnM8Q" />
<!-- / Yoast SEO Premium plugin. -->
<style>
.grecaptcha-badge {
    bottom: 60px !important;
}
</style>



    <?php include 'h_header.php'; ?>
	

<!--end fixed header-->
  <!--side menuu on desktop-->
    <?php include 'include/menu.php'; ?>




   
    <div class="split-slideshow" id="content">
        <div class="slideshow">
            <div class="slider">
                
                <div class="item">
                    <section class="still">
                        <div class="sfirst" id="home">
                           
                           <div class="row">
                               <div class="col-md-12">
                                <h1>Primacy Infotech</h1><br>
                                   <p>Our company is specialised in Web Design and Development. Apart from this, we are into necessary services like Web hosting, development of software, development of mobile applications, graphic designing, Registration of domain, SEO services, Digital marketing and bulk sms/messaging services at affordable rates. If you need any of the above services, feel free to contact us 9088015866</p>
                                </div>
                           </div> 
                        
                                <div class="container-fluid">
                                <div class="row marg">
                            
                            
                             <div id="mee" class="owl-carousel owl-theme">

                                    <div data-tilt class="home_box">

                                        <h2><i class="far fa-lightbulb"></i> Creative & Technical</h2>
                                        <hr>
                                        <p class="homep">Be it web designing or graphic designing, web development or custom programming we provide with the best services. We are here to solve all your problems related to the above genres. </p>
                                    </div>
                             
                                        <div class="home_box">

                                        <h2><i class="fas fa-chart-line"></i> EXPERIENCE</h2>
                                        <hr>
                                        <p class="homep">As a company we are carrying out with our services since the year, 2012. We excel in discussing as well as planning out brand new projects and strategize the processes of making it successful.  We have sufficient knowledge and experience in the specified fields with the excellent technical team. Our technical as well as digital marketing team , both are outstanding. </p>
                                    </div>
                                <div class="home_box">

                                        <h2><i class="fas fa-hand-holding-usd"></i> AFFORDABLE COST</h2>
                                        <hr>
                                        <p class="homep">Our company is known for fixing excellent rates which attracts different kinds of customers. Affordable rates as well as attractive packages are provided in order to meet the corporate needs. Websites are made in low prices which would not make a hole in your pocket. Satisfactory prices are the main attractions. </p>
                                    </div>
                                
                               </div>
                                
                                
                                
                            </div>
                            </div>
                           
                            
                        </div>
                    </section>
                </div>
                
                
                
                
                
                
                     <div class="item">

                    <div class="container">
                        <div class="row">
                           
                            <div class="col-md-12">
                                <div class="sheading">
                                    <h2>Our Services</h2>
									<br/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                         
                          <!-- <div class="col-md-0 "></div>-->
                           <div class="col-xs-12 col-md-12">
           
                                           
                         
								
									
									<div class="flex-container">
											
											   <div>
										       <a href="http://primacyinfotech.com/service/web-designing">
											   <img alt="#primacy" src="images/thumnail/development/des.png">
											    <h5>Web Designing</h5>
												</a>
											  </div>
											  
												<div class="imn">
												 <a href="http://primacyinfotech.com/service/web-developement">
											  <img src="images/thumnail/coding.png" alt="#primacy">
											  <h5>Web Development</h5>
											  </a>
											  </div>
												<div class="imn">
												 <a href="http://primacyinfotech.com/service/mobile-app-developemnt">
											  <img src="images/thumnail/development/user.pn_.png" alt="#primacy">
											   <h5>App Development</h5>
											   </a>
											  </div>
											  <div>
											   <a href="http://primacyinfotech.com/service/crm-erp-portal-development">
											 <img src="images/thumnail/development/user.png"alt="#primacy">
											 <h5>CRM & ERP Portal</h5>
											 </a>
											  </div>
												<div class="imn">
												 <a href="http://primacyinfotech.com/service/digital-marketing">
											  <img src="images/thumnail/hosting/name.png"alt="#primacy">
											   <h5>Digital Marketing</h5>
											   </a>
											  </div>
												<div class="imn">
												 <a href="http://primacyinfotech.com/service/ui-ux-desing">
											  <img src="images/thumnail/development/des.png" alt="#primacy">
											   <h5>UI/UX Design</h5>
											   </a>
											  </div>
											  	<div class="imn">
												 <a href="http://primacyinfotech.com/service/mlm-software-development">
											  <img src="images/thumnail/mlm/web.png" alt="#primacy">
											   <h5>MLM Software</h5>
											   </a>
											  </div>
											  	<div class="imn">
												 <a href="http://primacyinfotech.com/service/health-care-mangment">
											  <img src="images/thumnail/development/rupress.png" alt="#primacy">
											   <h5>Healthcare Portal</h5>
											   </a>
											  </div>


											</div>
										
									
							
							
							  
                          
                            
                            </div>
                           <!--<div class="col-md-0"></div>-->
                           </div>
                            
                            
                    </div>
				</div>
             
 

                           
                      <div class="item">

                    <div class="container">
                        <div class="row">
                           
                            <div class="col-md-12">
                                <div class="sheading">
                                    <h2>Our Product</h2>
									<br/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                         
                          <!-- <div class="col-md-0 "></div>-->
                           <div class="col-xs-12 col-md-12">
           
                                           
                         
								
									
									<div class="flex-container">
											 <div>
											 <a href="http://primacyinfotech.com/product/readymade-ecommerces-app">
										<img alt="#primacy" src="images/thumnail/product/screen.png">
											 <h5>Ecommerc App</h5>
												</a>
											  </div>
												<div class="imn">
												<a href="http://primacyinfotech.com/product/readymade-pharmacy-app">
											  <img src="images/thumnail/product/website.png" alt="#primacy">
											  <h5>Pharmacy App</h5>
											  </a>
											  </div>
												<div class="imn">
												<a href="http://primacyinfotech.com/product/readymade-grocery-delivery-app">
											  <img src="images/thumnail/product/shopping.png" alt="#primacy">
											   <h5>Grocery Delivery App</h5>
											   </a>
											  </div>
											  <div>
											  <a href="http://primacyinfotech.com/product/readymade-food-delivery-app">
											 <img src="images/thumnail/product/scooter.png" alt="#primacy">
											 <h5>Food Delivery App</h5>
											 </a>
											  </div>
												<div class="imn">
												<a href="http://primacyinfotech.com/product/readymade-online-education-app">
											  <img src="images/thumnail/product/mortarboard.png"alt="#primacy">
											   <h5>Online Education App</h5>
											   </a>
											  </div>
												<div class="imn">
												<a href="http://primacyinfotech.com/product/readymade-video-streaming-app">
											  <img src="images/thumnail/product/computer.png" alt="#primacy">
											   <h5>Video Streaming App</h5>
											   <a/>
											  </div>
											  	<div class="imn">
												<a href="http://primacyinfotech.com/product/readymade-realestate-portal">
											  <img src="images/thumnail/product/suitcase.png" alt="#primacy">
											   <h5>Realestate Portal</h5>
											   </a>
											  </div>
											  	<div class="imn">
												<a href="http://primacyinfotech.com/product/readymade-cab-booking-app">
											  <img src="images/thumnail/product/mobile.png" alt="#primacy">
											   <h5>Car Booking App</h5>
											   </a>
											  </div>


											</div>
										
									
							
							
							  
                          
                            
                            </div>
                           <!--<div class="col-md-0"></div>-->
                           </div>
                            
                            
                    </div>
				</div>
                
                
               
                <div class="item">
                    <div class="container marg2">
                        <div class="project">
                            <h1>Our Project</h1>
                        </div>
                    </div>
                    <!--afterservice-->
                 <section class="portfolio" id="portfolio">
	<div class="container">
		<div class="row">
<!--

			<div class="gallery col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="gallery-title">Gallery</h1>
			</div>
-->

			<div align="center">
				<button class="filter-button" data-filter="all">All</button>
				<button class="filter-button" data-filter="category1">Designing</button>
				<button class="filter-button" data-filter="category2">Development</button>
				<button class="filter-button" data-filter="category3">App</button>
			</div>
			
			<br/>

            <div class="gallery_product col-sm-3 col-xs-6 filter all category1 ">
                <a class="fancybox" rel="ligthbox" href="assets/images/jwellery.png">
                    <img class="img-responsive" alt="#primacy" src="assets/images/jwellery-small.png" />
                    <div class='img-info'>
                        <h4>REYNA</h4>
						<p>Jwellery Website Developed In Wordpress,Html5,Css3,Jquery</p>
                    </div>
                </a>
            </div>

            <div class="gallery_product col-sm-3 col-xs-6 filter category3 ">
                <a class="fancybox" rel="ligthbox" href="assets/images/muddiz.jpg">
                    <img class="img-responsive" alt="#primacy" src="assets/images/muddiz-small.jpg" />
                    <div class='img-info'>
                        <h4>MUDDIZ</h4>
						<p>Grocerry Website Developed In Codeigniter,Html5,Css3,Jquery </p>
                    </div>
                </a>
            </div>

            <div class="gallery_product col-sm-3 col-xs-6 filter category2">
                 <a class="fancybox" rel="ligthbox" href="assets/images/netwood.png">
                    <img class="img-responsive" alt="#primacy" src="assets/images/netwood-small.png" />
                    <div class='img-info'>
                        <h4>NETWOOD</h4>
						<p>Video Portal Website Developed In Codeigniter,Html5,Css3,Jquery</p>
                    </div>
                </a>
            </div>

            <div class="gallery_product col-sm-3 col-xs-6 filter category2">
                <a class="fancybox" rel="ligthbox" href="assets/images/boi.png">
                    <img class="img-responsive" alt="#primacy" src="assets/images/boi-small.jpg" />
                    <div class='img-info'>
                        <h4>BOI BIPANI</h4>
						<p>BOI Bipani Ecommerce Website Developed In Wordpress,Html5,Css3,Jquery</p>
                    </div>
                </a>
            </div>
            <br/>

            <a href="about/our-portfolios.php" class="btn btn-lg btn-danger my-bt9">View More</a>
		</div>
	</div>
</section>

           
                    <!--afterservice-->
                </div>

                <div class="item">
               <div class="container marg2">
                        <div class="project">
                            <h1>Our Solution</h1>
                        </div>
                    </div>
                    <div class="circle">
                        <div class="container">
                            <div class="row">

                                <div class="col-md-12 col-xs-12 circle">
                                    <ul class="menu">
                                        <li class="active one">
                                           
                                            <a href="#">
                                                <span class="active icon"><img src="images/briefcase.png" alt="#primacy"></span>
                                                 
                                            </a>
                                        </li>
                                        <li class="two">

                                            <a href="#">
                                                <span class="icon"><img src="images/school.png" alt="#primacy"></span>
                                            </a>
                                        </li>
                                        <li class="three">

                                            <a href="#">
                                                <span class="icon"><img src="images/loan.png" alt="#primacy"></span>
                                            </a>
                                        </li>
                                        <li class="four">

                                            <a href="#">
                                                <span class="icon"><img src="images/doctor.png" alt="#primacy"></span>
                                            </a>
                                        </li>
                                        <li class="five">

                                            <a href="#">
                                                <span class="icon"><img src="images/pyramid.png" alt="#primacy"></span>
                                            </a>
                                        </li>
                                        <li class="six">

                                            <a href="#">
                                                <span class="icon"><img src="images/shopping.png" alt="#primacy"></span>
                                            </a>
                                        </li>
                                    </ul>

                                    <svg height="0" width="0">
                                        <defs>
                                            <clipPath clipPathUnits="objectBoundingBox" id="sector">
                                                <path fill="none" stroke="#111" stroke-width="1" class="sector" d="M0.5,0.5 l0.5,0 A0.5,0.5 0 0,0 0.75,.066987298 z"></path>
                                            </clipPath>
                                        </defs>
                                    </svg>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                  <!--testimonial part-->
        
                <!--testimonial part-->


                <!--testimonial part-->
                <div class="item">
                    <div class="container">
                        <div class="row">
                            <div class="test_heading">
                                <h1>Testimonial</h1>
                            </div>
                           <div class="col-md-1"></div>
                            <div class="col-md-10">
                            <div id="mee2" class="owl-carousel owl-theme">
 
                                <div class="testimonial">
                                    <h2><i class="fas fa-quote-left"></i></h2>
                                    <p>“Primacy Infotech Pvt. Ltd. greatly exceeded our expectations for developing a reasonably priced church website. I found kabir to be very professional and easy to work with. His punctuality, communication skills, and patient explanations of website design terminology and concepts made the process a very positive experience for our church leadership.”</p>
                                    <h1>Md Azar Sk</h1>
                                    <h4>MD OF ATBSS.ORG</h4>
                                </div>
                                
                                <div class="testimonial">
                                    <h2><i class="fas fa-quote-left"></i></h2>
                                    <p>“If you are looking for a Web design company who is fast, organized and very detailed oriented... then you will find it with Primacy Infotech Pvt. Ltd. They designed, our idea of a website to all our specifications. They also made many creative improvements that we never thought of. We would recommend Primacy Infotech Pvt. Ltd. to anyone. ”

</p>
                                    <h1>Picasso Sengupta
</h1>
                                    <h4>Director of Adhyann.com</h4>
                                </div>
                                
                                <div class="testimonial">
                                    <h2><i class="fas fa-quote-left"></i></h2>
                                    <p>“We came to Primacy Infotech Pvt. Ltd. with a vision for our website. you listened, that vision with your constructive criticism and insight, produced a very attractive website! We hear nothing but positive comments! So again, THANK YOU! ”</p>
                                    <h1>Manish Gadia</h1>
                                    <h4>Chief Instructor of Gpluseducation</h4>
                                </div>
                                    <div class="testimonial">
                                    <h2><i class="fas fa-quote-left"></i></h2>
                                    <p>“They provide great quality for the best prices that I have found in the business. I have been very happy with their work to date and recommend them highly. Thanks for the good job ....I LOVE my new website. ”</p>
                                    <h1>Pranob Roy</h1>
                                    <h4>Director  of Institute of Alternative Medicines Kolkata</h4>
                                </div>
                                   
                              

                           
                        
                            
                        </div>
                            </div>
                            <div class="col-md-1"></div>
                        </div>

                    </div>


                </div>
                
                
                <!--testimonial part-->



                <!--    contact  -->

		</div>
        </div>
        
        
        
        
        
        
        
<!--        <div class="slideshow-text">

            <div class="item">PRIMACY INFOTECH
            </div>

            <div class="item"></div>
            <div class="item"></div>
        </div>-->

  <!--footer my-->
    <?php include 'h_footer.php'; ?>
</hader>



</html> 
