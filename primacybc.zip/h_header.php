<meta name="google-site-verification" content="3y7Lsde2vg5scHYTSw_lPc9HRyXHAAwFgiBTqbfmGaQ" />

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- ser -->
<!--  <script src="js/jquery-1.3.2.js"></script>-->

<script src="js/jquery.js"></script>


<!--    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow&v1' rel='stylesheet' type='text/css' />
    <link href='http://fonts.googleapis.com/css?family=Wire+One&v1' rel='stylesheet' type='text/css' />-->
<!-- hover -->
<link rel="stylesheet" href="hover.css">

<!-- <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">-->
<link rel="stylesheet" href="css/sstyle.css">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/common-style.css">


<!-- Global site tag (gtag.js) - Google Analytics -->


<!-- particles.js container -->




<!-- particles.js lib - https://github.com/VincentGarreau/particles.js -->
<script src="js/particles.js"></script>
</head>
<body>

<div id="particles-js">
</div>

<div class="count-particles">
</div>
<!-- stats.js lib -->
<!-- <script src="http://threejs.org/examples/js/libs/stats.min.js"></script> -->

<!--
    <div class="top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 pic0"><img src="images/primacy.png"></div>
                <div class="col-md-7">
						   <div class="col-md-12">
							   <div class="c-mob">
								   <div class="col-md-4">
										  <img src="images/inddd.png" alt="india">&nbsp;
										   <a href="tel:+91 9088015866" class="">+91 9088015866</a>
										  <a href="tel:+91 9088015865" class="">/65</a>
								   </div>
									<div class="col-md-4">
										   <img width="16" height="11" src="images/canada-flag-xs.png" alt="india"> &nbsp;
										   <a href="tel:+16474908004" class="Blondie-email">+16474908004</a>

								   </div>
									<div class="col-md-4">
										   <img width="16" height="11" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;
										   <a href="tel:+88 01759787636" class="Blondie-email">+88 01759787636</a>

								   </div>
								   </div>
					       </div>
                </div>
                <div class="hidden-xs col-md-2 dropdown ">
					<button class="btn btn-primary dropdown-toggle pull-right" type="button" data-toggle="dropdown"><i class="fas fa-globe"></i>&nbsp;Global
					<span class="caret"></span></button>
					<ul class="dropdown-menu pull-right">
					  <li><a href="https://www.primacyinfotech.in"><span><img src="images/inddd.png" alt="india"> &nbsp;India</span></a></li>
					  <li><a href="https://ca.primacyinfotech.com"><span><img width="16" height="11" src="images/canada-flag-xs.png" alt="india"> &nbsp;Canada</span></a></li>
					  <li><a href="https://primacyinfotechltd.com/"><span><img width="16" height="11" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;Bangladesh</span></a></li>
					</ul>
			  </div>
							<div class="col-md-6 pic1"><img src="images/primacy%20cms.png"></div>
            </div>
        </div>
    </div>

-->


<!-- <div class="col-sm-12 col-xs-12 menu-right">-->


<!--
    <div class="nav-side-menu" id="slide_menu2" style="display:none;">



    <div class="brand">Menu</div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

        <div class="menu-list">

            <ul id="menu-content" class="menu-content collapse out">



                <li>
                  <a href="index.php">
                  <i class="fa fa-dashboard fa-lg"></i> Home
                  </a>
                </li>

                <li  data-toggle="collapse" data-target="#products" class="collapsed active">
                  <a href="#"><i class="fa fa-gift fa-lg"></i> Services<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="products">
                    <li class="active"><a href="web-development.php">Web Development</a></li>
                           <li><a href="web-designing.php">Web Designing</a>
                    </li>
                      <li><a href="crm-erp.php">CRM & ERP</a>
                    </li>
                      <li><a href="mobile-application.php">Mobile Apps Development</a>
                    </li>
                       <li><a href="digital-marketing.php">Digital Marketing</a>
                    </li>
                       <li><a href="ui-ux.php">UI/UX Design</a>
                    </li>
                        <li><a href="portal-development.php">Portal Development</a>
                    </li>
                       <li><a href="ecommerce-development.php">Ecommerce Development</a>
                    </li>





                </ul>


                <li data-toggle="collapse" data-target="#service" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> Solution <span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="service">
                    <li class="active"><a href="http://www.travelbusinessportal.com/">Travel Portal</a></li>
                    <li><a href="school-mangement.php">School Management</a>
                       </li>
                      <li><a href="crm-erp.php">CRM & ERP</a>
                    </li>
                      <li><a href="loan">Loan Management</a>
                    </li>
                       <li><a href="health.php">Healthcare Management</a>
                    </li>
                       <li><a href="mlm.php">MLM</a>
                    </li>
                        <li><a href="portal-development.php">Readymade Ecommerce</a>
                    </li>

                       <li><a href="portal-development.php">Billing Software</a>
                    </li>
                       <li><a href="portal-development.php">Accounting Software</a>
                    </li>
                       <li><a href="portal-development.php">Video Portal</a>
                    </li>
                       <li><a href="portal-development.php">Readymade Ecommerce</a>
                    </li>

                </ul>
                       <li data-toggle="collapse" data-target="#about" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> About Us <span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="about">
                    <li class="active"><a href="http://www.travelbusinessportal.com/">Travel Portal</a></li>
					<li><a href="school-mangement.php">Why Us</a></li>
                    <li><a href="crm-erp.php">Company</a>
                    </li>
                      <li><a href="loan">Infrastructure</a>
                    </li>
                       <li><a href="health.php">Team</a>
                    </li>
                    <li><a href="sucess-story.php">Our Success Story</a>
                    </li>


                </ul>


                 <li>
                  <a href="contact.php">
                  <i class="fa fa-users fa-lg"></i> Contact us
                  </a>
                </li>

            </ul>
     </div>
     	<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-whatsapp"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-skype"></i></a></li>
						<li class="list-inline-item"><a href="" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
</div>
-->




<!--
    <div id="menuwrapper">
        <ul id="sidemenu">
            <li><a class="" href="https://primacyinfotech.com/"><i class="fas fa-home"><br>Home</i></a></li>

            <li><a href="#"><i class="fas fa-server"><br>
                        Service</i></a>
                <ul class="my-col-2">

                    <li>
                       <a href="web-developement.php"><i class="icofont-code icofont-2x"></i><br />
                        <div class="txt">Web Development</div>
						</a>
                    </li>
                        <li><a href="web-designing.php"><i class="icofont-dashboard-web icofont-2x"></i>

                            <div class="txt">Web Designing</div>
                        </a>
                    </li>
                      <li><a href="android-developemnt.php"><i class="icofont-brand-android-robot icofont-2x"></i><br />
                        <div class="txt">Apps Development</div>
						  </a>
                    </li>

                    <li><a href="crm-erp.php"><i class="icofont-computer icofont-2x"></i><br />
                        <div class="txt">CRM & ERP</div>
						</a>
                    </li>


                     <li><a href="digital-marketing.php"><i class="icofont-automation icofont-2x"></i><br />
                        <div class="txt">Digital Marketing</div>
						 </a>
                    </li>

                    <li><a href="ui-ux.php"><i class="icofont-penalty-card icofont-2x"></i><br />
                        <div class="txt">UI/UX Design</div>
						</a>
                    </li>


                    <li><a href="ecommerce-developemnt.php"><i class="icofont-shopping-cart icofont-2x"></i><br />
                        <div class="txt">Ecommerce Development</div>
						</a>
                    </li>
                     <li><a href="food-order-app.php"><i class="icofont-fast-food icofont-2x"></i><br />
                        <div class="txt">Food Delhivery App</div>
						</a>
                    </li>
                       <li><a href="portal-recharge.php"><i class="icofont-brand-china-mobile icofont-2x"></i><br />
                        <div class="txt">Recharge Portal</div>
						</a>
                    </li>

                </ul>

            </li>

            <li><a href="#"><i class="fas fa-server"><br>
                        Solution</i></a>
                <ul class="my-col-2">
                    <li><a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel Portal</div>
                        </a>
                    </li>
                    <li>
                       <a href="portal-school.php"><i class="icofont-building-alt icofont-2x"></i><br />
						   <div class="txt">School Management</div></a>
                    </li>
                      <li>
                       <a href="portal-lms.php"><i class="icofont-learn icofont-2x"></i><br />
						   <div class="txt">Learning Management</div></a>
                    </li>
                      <li><a href="portal-loan.php"><i class="icofont-money-bag icofont-2x"></i><br />
						  <div class="txt">Loan Management</div></a>
                    </li>
                    <li><a href="portal-health.php"><i class="icofont-doctor icofont-2x"></i><br />
						<div class="txt">Healthcare Management</div></a>
                    </li>
                    <li><a href="portal-mlm.php"><i class="icofont-company icofont-2x"></i><br />
						<div class="txt">MLM Software</div></a>
                    </li>
                    <li><a href="portal-accounting.php"><i class="icofont-paper icofont-2x"></i><br />
						<div class="txt">Accounting</div></a>
                    </li>
                     <li><a href="portal-video.php"><i class="icofont-video-cam icofont-2x"></i>

                            <div class="txt">Video Portal</div>
                        </a>
                    </li>
                    <li><a href="portal-realestate.php"><i class="icofont-search-property icofont-2x"></i>

                            <div class="txt">Realestate</div>
                        </a>
                    </li>
                     <li><a href="portal-ola.php"><i class="icofont-car-alt-1 icofont-2x"></i>

                            <div class="txt">OLA/Uber Clone</div>
                        </a>
                    </li>


                </ul>

            </li>

                <li><a href="#"><i class="fas fa-industry"><br>
                        Industry</i></a>
                <ul class="my-col-2">
                    <li><a href="#"><i class="icofont-doctor icofont-2x"></i><br />
                        <div class="txt">Healthcare</div>
                        </a>
                    </li>
                    <li>
                       <a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel</div>
						</a>
                    </li>
                      <li><a href="#"><i class="icofont-paper icofont-2x"></i><br />
                        <div class="txt">Financial</div>
						  </a>
                    </li>
                    <li><a href="#"><i class="icofont-ui-cart icofont-2x"></i><br />
                        <div class="txt">Retail</div>
						</a>
                    </li>
                    <li><a href="#"><i class="icofont-holding-hands icofont-2x"></i><br />
                        <div class="txt">Insurance</div>
						</a>
                    </li>
                     <li><a href="#"><i class="icofont-bank icofont-2x"></i>

                            <div class="txt">Banking</div>
                        </a>
                    </li>
                      <li><a href="#"><i class="icofont-man-in-glasses icofont-2x"></i>

                            <div class="txt">Goverment</div>
                        </a>
                    </li>
                      <li><a href="#"><i class="icofont-newspaper icofont-2x"></i>

                            <div class="txt">Media </div>
                        </a>
                    </li>










                </ul>

            </li>



            <li><a href="#"><i class="fas fa-paper-plane"><br>
                        About us</i></a>

                <ul class="my-col-2">
                    <li><a href="why-us.php"><i class="icofont-question-square icofont-2x"></i><br />
                        <div class="txt">Why Us</div>
                        </a>
                    </li>
                    <li>
                       <a href="our-company.php"><i class="icofont-building icofont-2x"></i><br />
                        <div class="txt">Company</div>
						</a>
                    </li>
                      <li><a href="career.php"><i class="icofont-search-job icofont-2x"></i><br />
                        <div class="txt">Career</div>
						  </a>
                    </li>
                    <li><a href="#"><i class="icofont-building-alt icofont-2x"></i><br />
                        <div class="txt">Infrastructure</div>
						</a>
                    </li>
                    <li><a href="#"><i class="icofont-team icofont-2x"></i><br />
                        <div class="txt">Team</div>
						</a>
                    </li>
                     <li><a href="sucess-story.php"><i class="icofont-notebook icofont-2x"></i><br />
                        <div class="txt">Our Case Study</div>
						</a>
                    </li>

             </ul>



            </li>

            <li><a class="noflyout selected" href="contact-us.php"><i class="fas fa-envelope"><br>Contact US</i></a></li>


            <li><a class="" href="https://primacyinfotech.com/"><i class="fas fa-home"><br>Home</i></a></li>

            <li><a href="#"><i class="fas fa-server"><br>
                        Service</i></a>
                <ul class="my-col-2">

                     <li><a href="web-development.php"><img src="images/software.png"><br />
                        <div class="txt">Software Development</div>
                        </a>
                    </li>
                    <li>
                       <a href="web-development.php"><img  src="images/web-devewlopemntt.png"><br />
                        <div class="txt">Web Development</div>
						</a>
                    </li>
                        <li><a href="web-designing.php"><img src="images/web-design-24.png">

                            <div class="txt">Web Designing</div>
                        </a>
                    </li>
                      <li><a href="mobile-application.php"><img src="images/app-development.png"><br />
                        <div class="txt">Apps Development</div>
						  </a>
                    </li>

                    <li><a href="crm-erp.php"><img src="images/dynamics-crm.png"><br />
                        <div class="txt">CRM & ERP</div>
						</a>
                    </li>


                     <li><a href="digital-marketing.php"><img src="images/seo.png"><br />
                        <div class="txt">Digital Marketing</div>
						 </a>
                    </li>

                    <li><a href="ui-ux.php"><img src="images/ui-design.png"><br />
                        <div class="txt">UI/UX Design</div>
						</a>
                    </li>

                      <li><a href="portal-development.php"><img width="24" height="24" src="images/portal.png"><br />
                        <div class="txt">Portal Development</div>
						  </a>
                    </li>
                    <li><a href="ecommerce-development.php"><img src="images/ecommerce.png"><br />
                        <div class="txt">Ecommerce Development</div>
						</a>
                    </li>








                </ul>

            </li>
                     <li><a href="#"><i class="fas fa-server"><br>
                        Solution</i></a>
                <ul class="my-col-2">
                    <li><a target="_blank" href="http://www.travelbusinessportal.com/"><img src="images/software.png"><br />
                        <div class="txt">Travel Portal</div>
                        </a>
                    </li>
                    <li>
                       <a href="school-mangement.php"><img  src="images/schooll.png"><br />
						   <div class="txt">School Management</div></a>
                    </li>
                      <li><a href="loan.php"><img src="images/app-development.png"><br />
						  <div class="txt">Loan Management</div></a>
                    </li>
                    <li><a href="health.php"><img src="images/wordpress.png"><br />
						<div class="txt">Healthcare Management</div></a>
                    </li>
                    <li><a href="mlm.php"><img src="images/dynamics-crm.png"><br />
						<div class="txt">MLM</div></a>
                    </li>
                     <li><a href="ecommerce-development.php"><img src="images/ecommerce.png">

                            <div class="txt">Readymade Ecommerce</div>
                        </a>
                    </li>









                </ul>

            </li>

                <li><a href="#"><i class="fas fa-server"><br>
                        Industry</i></a>
                <ul class="my-col-2">
                    <li><a href="#"><img src="images/software.png"><br />
                        <div class="txt">Healthcare</div>
                        </a>
                    </li>
                    <li>
                       <a target="_blank" href="http://www.travelbusinessportal.com/"><img  src="images/web-devewlopemntt.png"><br />
                        <div class="txt">Travel</div>
						</a>
                    </li>
                      <li><a href="#"><img src="images/app-development.png"><br />
                        <div class="txt">Financial</div>
						  </a>
                    </li>
                    <li><a href="#"><img src="images/wordpress.png"><br />
                        <div class="txt">Retail</div>
						</a>
                    </li>
                    <li><a href="#"><img src="images/dynamics-crm.png"><br />
                        <div class="txt">Insurance</div>
						</a>
                    </li>
                     <li><a href="#"><img src="images/web-design-24.png">

                            <div class="txt">Banking</div>
                        </a>
                    </li>
                      <li><a href="#"><img src="images/web-design-24.png">

                            <div class="txt">Goverment</div>
                        </a>
                    </li>
                      <li><a href="#"><img src="images/web-design-24.png">

                            <div class="txt">Media </div>
                        </a>
                    </li>










                </ul>

            </li>



            <li><a href="#"><i class="fas fa-paper-plane"><br>
                        About us</i></a>

                <ul class="my-col-2">
                    <li><a href="why-us.php"><img src="images/team.png"><br />
                        <div class="txt">Why Us</div>
                        </a>
                    </li>
                    <li>
                       <a href="our-company.php"><img  src="images/group.png"><br />
                        <div class="txt">Company</div>
						</a>
                    </li>
                      <li><a href="career.php"><img src="images/success.png"><br />
                        <div class="txt">Career</div>
						  </a>
                    </li>
                    <li><a href="#"><img src="images/infrastructure.png"><br />
                        <div class="txt">Infrastructure</div>
						</a>
                    </li>
                    <li><a href="#"><img src="images/group.png"><br />
                        <div class="txt">Team</div>
						</a>
                    </li>
                     <li><a href="sucess-story.php"><img src="images/dynamics-crm.png"><br />
                        <div class="txt">Our Case Study</div>
						</a>
                    </li>

             </ul>



            </li>

            <li><a class="noflyout selected" href="contact.php"><i class="fas fa-envelope"><br>Contact US</i></a></li>

        </ul>
    </div>
-->


<!--My fixed header-->

<div class="top-bar">
    <div class="c-mob2">
        <ul class="c-mob-3">
            <li><img src="assets/images/inddd.png" alt="india"></li>
            <li><a href="tel:+91 9088015866" class="">+91 9088015866</a></li>
            <li><a href="tel:+91 9088015865" class="">/65</a></li>


            <li><img width="16" height="11" src="assets/images/canada-flag-xs.png" alt="canada"></li> &nbsp;
            <li> <a href="tel:+16474908004" class="Blondie-email">+1 6474908004</a></li>



            <li><img width="16" height="11" src="assets/images/bangladesh-flag-xs.png" alt="bangladesh"></li> &nbsp;
            <li><a href="tel:+88 01759787636" class="Blondie-email">+88 01759787636</a></li>
        </ul>

    </div>
</div>

<div class="top">
    <div class="container">
        <div class="row">
            <div class="col-md-3 pic0"><a href="index.php"><img src="assets/images/logo-p.png" alt="primacy logo"></a></div>
            <div class="col-md-7">
                <!--				<div class="col-md-12">-->
                <div class="c-mob">
                    <div class="col-md-4">
                        <img src="assets/images/inddd.png" alt="india">&nbsp;
                        <a href="tel:+91 9088015866" class="">+91 9088015866</a>
                        <a href="tel:+91 9088015865" class="">/65</a>
                    </div>
                    <div class="col-md-4">
                        <img width="16" height="11" src="assets/images/canada-flag-xs.png" alt="canada"> &nbsp;
                        <a href="tel:+16474908004" class="Blondie-email">+1 6474908004</a>

                    </div>
                    <div class="col-md-4">
                        <img width="16" height="11" src="assets/images/bangladesh-flag-xs.png" alt="bangladesh"> &nbsp;
                        <a href="tel:+88 01759787636" class="Blondie-email">+88 01759787636</a>

                    </div>
                </div>
                <!--				</div>-->
            </div>
            <div class="col-md-2 dropdown ">
                <button class="my-button my-button2 my-button-home dropdown-toggle pull-right" type="button" data-toggle="dropdown"><i class="fas fa-globe"></i>&nbsp;Global

                    <span class="caret"></span></button>
                <ul class="dropdown-menu pull-right drop-home">
                    <li><a href="https://www.primacyinfotech.in/"><span><img src="assets/images/inddd.png" alt="india"> &nbsp;India</span></a></li>
                    <li><a href="https://ca.primacyinfotech.com/"><span><img width="16" height="11" src="assets/images/canada-flag-xs.png" alt="india"> &nbsp;Canada</span></a></li>
                    <li><a href="https://primacyinfotechltd.com/"><span><img width="16" height="11" src="assets/images/bangladesh-flag-xs.png" alt="india"> &nbsp;Bangladesh</span></a></li>
                </ul>
            </div>

        </div>
    </div>
</div>


<?php
session_start();
include("mail/src/Mailjet/php-mailjet-v3-simple.class.php");

$apiKey = 'f6013a7295c2b8cf05912fe6c0734850';
$secretKey = '0fc23d25c6361571ce4047efd75ffb4e';

$mj = new Mailjet($apiKey, $secretKey);


if (isset($_POST['submit']))
{
	$name=$_POST["name"];
	$emailid1=$_POST["emailid1"];
	$phone=$_POST["phone"];
	$comment=$_POST["comment"];

	$servername = "localhost";
	$username = "primacy_1";
	$password = "Piwd@2020";
	$dbname = "primacy_1";
	$con = new mysqli($servername, $username, $password, $dbname);
	if ($con->connect_error) {
	    die("Connection failed: " . $con->connect_error);
	}

	$sql = "INSERT INTO get_quote (name, email, phone, comment) VALUES ('".$name."', '".$email."', '".$phone."', '".$comment."')";

	if ($con->query($sql) === TRUE) {
		$message = "
		<html>
    		<head>
    		    <title>Get Quote</title>
    		</head>
    		<body>
    		    <p>Quote Details</p>
    		    <table>
    		        <tr>
    		            <td>Name : </td>
    		            <td>".$name."</td>
    		        </tr>
    		        <tr>
    		            <td>Email : </td>
    		            <td>".$emailid1."</td>
    		        </tr>
    		        <tr>
    		            <td>Phone : </td>
    		            <td>".$phone."</td>
    		        </tr>
    		        <tr>
    		            <td>Name : </td>
    		            <td>".$comment."</td>
    		        </tr>										<tr>
    		            <td>Url : </td>
    		            <td>".$_SERVER['HTTP_REFERER']."</td>
    		        </tr>										<tr>
    		            <td>IP : </td>
    		            <td>".$_SERVER['REMOTE_ADDR']."</td>
    		        </tr>										
    		    </table>
    		</body>
		</html>";
		//mail("piwd004@primacyinfotech.com","My subject",$message);
        // Create a new Object
        $mj = new Mailjet();
        $params = array(
            "method" => "POST",
            "from" => "info@primacyinfotech.com",
            "to" => "kabir@primacyinfotech.com",
            "subject" => "Quote from Primacy Infotech",
            "html" => "{$message}"
        );
        $result = $mj->sendEmail($params);
        $params1 = array(
            "method" => "POST",
            "from" => "info@primacyinfotech.com",
            "to" => "sudipta@primacyinfotech.com",
            "subject" => "Quote from Primacy Infotech",
            "html" => "{$message}"
        );
        $result1 = $mj->sendEmail($params1);



?>
<script>swal("Success!", "Thank you for your call back requset. Out team will Contact you shortly.", "success");</script>
<?php
	} else {
	    echo "Error: " . $sql . "<br>" . $con->error;
	}

	$con->close();

}
//include_once "../piss/config.php";
//include_once "../piss/project-security.php";
?>

 <script src="https://www.google.com/recaptcha/api.js"></script>
 <script>
   function onSubmit(token) {
     document.getElementById("demo-form").submit();
   }
 </script>