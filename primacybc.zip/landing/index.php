<!doctype html>

<html lang="en">



<head>

	<meta charset="UTF-8">

	<title>Primacy Infotech Pvt Ltd</title>





	<!-- Mobile Specific Meta -->

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

	

	<!-- Modernizr js -->

	<script src="assets/js/modernizr-2.8.0.min.js"></script>



	<!-- Bootstrap  -->

	<link href="assets/css/bootstrap.min.css" rel="stylesheet">



	<!-- icon fonts font Awesome -->

	<link href="assets/css/font-awesome.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" >





	<!-- icon fonts linecons -->

	<link href="assets/css/linecons-font-style.css" rel="stylesheet">



	<!-- Custom Styles -->

	<link href="assets/css/style.css" rel="stylesheet">



	<!-- Responsive Styles -->

	<link href="assets/css/responsive.css" rel="stylesheet">



	<!-- Important owl stylesheet -->

	<link rel="stylesheet" href="assets/css/owl.carousel.css">

<link rel="stylesheet" href="assets/css/lightbox.css">

	<!-- Important prettyPhoto stylesheet -->

	<link rel="stylesheet" href="assets/css/prettyPhoto.css">

	<link rel="stylesheet" href="assets/css/colorbox.css">



	<!-- favicon --> 

<!--	<link rel="shortcut icon" href="images/favicon.png">-->





<style>

.lead-form {

    width: 315px;

    background: #fff;

    margin: 10px auto;

    border-radius: 10px;

    /* box-shadow: 2px 1px 5px 1px #a7a5a5; */

}

	.lead-form h4 {

	 font-size:16px;

	 color:#af1717;

	 font-weight: bold;

		padding:12px;

	}

	input, button, select, textarea {

	    border:none;

	}

	.input-box {

   width: 256px;

    height: 40px;

    padding: 0 5px;



    border-radius: 3px;

    color: #636363;

    margin-top: 12px;

    margin-bottom: 3px;

    border-bottom: 2px solid #ccc;

    outline: none;

}

	.submit-btn {

     width: 256px;

    height: 47px;

    color: #fff;

    font-weight: 300;

    background-color: #1065b6;

    border: none;

    border-radius: 3px;

    margin-top: 12px;

    margin-bottom: -30px;

    cursor: pointer;

}

button.close {

    padding: 0;

    cursor: pointer;

    background: #ffffff;

    border: 0;

    -webkit-appearance: none;

}

.close {

    float: right;

    font-size: 28px;

    font-weight: bold;

    line-height: 1;

    color: #f00;

    /* text-shadow: 0 1px 0 #fff; */

    opacity: .5;

    filter: alpha(opacity=20);

}

.modal-header {

border-bottom: none; 

}

	.modal-content {

    background-color:#717171a6!important

}

	form.popup-form {

    margin-left: 35px;

    /* margin-bottom: 10px; */

	}

		.modal-dialog {

    width: 354px;

  

}i.fa.fa-bullhorn {

    color: #a51b1b;

    font-size: 19px;

}



	.my-btn{

    border: 1px solid #333;

    margin-top: 23px;

    color:#000;

}

		.my-btn:hover{

   background-color: :red;

			color:#fff;

}

		.my-btn2{

   display:none;

}

	

	

	#modal-content {

  display: none;

}



</style>

 <style>

	   /* home social-list */



.home-social-list {

  position: absolute;

  right:5px;

  top:30%;

  margin: 0;

  padding: 0;

  list-style: none;

  font-size: 1rem;

  line-height: 1.75;

  text-align: center;

  -webkit-transform: translateY(-55%);

  -ms-transform: translateY(-55%);

  transform: translateY(-55%);

	z-index:999;

}



.home-social-list::before {

  display: block;

  content: "";

  width: 2px;

  height: 42px;

  background-color: rgba(255, 255, 255, 0.15);

  margin-left: auto;

  margin-right: auto;

  margin-bottom: 12px;

}



.home-social-list li {

  padding-left: 0;

}



.home-social-list li a,

.home-social-list li a:visited {

  color: #FFFFFF;

}



.home-social-list li a:hover,

.home-social-list li a:focus,

.home-social-list li a:active {

  color: #44c455;

}





/* scroll down */



.home-scrolldown {

	color:#fff;

  position: absolute;

  bottom:2px;

  right: 2px;

  -webkit-transform: rotate(90deg);

  -ms-transform: rotate(90deg);

  transform: rotate(90deg);

  -webkit-transform-origin: right top;

  -ms-transform-origin: right top;

  transform-origin: right top;

  float: right;

	z-index:999;

	color:#fff;

	transition: all .5s;

}

.home-scrolldown span {

   color:#fff;

}



.home-scrolldown i {

  padding-left: 9px;

	color:#fff;

}



.home-scrolldown a:hover,

.home-scrolldown a:focus {

  color: #44c455 !important;

}



	 .event-content img {

    margin-left: 28px;

}











@media(max-width:420px){

    .top-section .link {

    margin: 40px auto;

}

    .footer-social-btn {

    

    display: none;

}

    .section-padding {

    padding-top: 15px;

    padding-bottom: 10px;

}

    .menu-bg-overlay {

    padding: 0px 0;

}

	.my-btn2{

   display:block;

		position:absolute;

		top:0;

		right:5px;

     }

     .home-social-list{

         display:none;

     }

     .home-scrolldown{

         display:none;

     }

	}

</style>	

</head>

	<body>

	

<ul class="home-social-list">

            <li>

				<a target="_blank" href="https://www.facebook.com/primacyit/"><i class="fab fa-facebook-f"></i></a>

            </li>

            <li>

                <a target="_blank" href="https://api.whatsapp.com/send?phone=919875627563"><i class="fab fa-whatsapp"></i></a>

            </li>

            <li>

                <a target="_blank" href="tel:+91 9088015866"><i class="fas fa-phone"></i></a>

            </li>

            <li>

                <a target="_blank" href="mailto:info@primacyinfotech.com"><i class="far fa-envelope"></i></a>

            </li>

        </ul>

        <!-- end home-social-list -->



      <div class="home-scrolldown">

            <a href="#service" class="scroll-icon smoothscroll">

                <span>Scroll Down</span>

                <i class="fas fa-long-arrow-alt-right"></i>

            </a>

		</div>	

	

<div id="modal-content">

    <div class="lead-form lead-form2">

                    <h4>Submit Your Details and Get 25% Off </h4>

					<form class="popup-form" method="post">	

        				<!--<label>Your Name*</label>-->

        				<input type="text" name="name" placeholder="Enter your Name" class="input-box" id="yurname" required="">

        				<!--	<label>Your Email*</label>-->

        				<input type="email" name="email" placeholder="Enter your Email" class="input-box" required="">

        				<!--	<label>Your Phone*</label>-->

        			<!--	<input type="text" name="phone" id="phone" placeholder="Enter your Phone" maxlength="10" class="input-box" onkeyup="checkInp()" required="">-->

        				<span id="message_2"></span>

        				<input type="text" name="phone" id="phone_2" placeholder="Enter your Phone" class="input-box" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="10" required>

        			    <!-- <label>Choose Service*</label>-->

        				<select class="input-box" name="service" id="sel1" required="">

							<option value=""> --Choose Services--</option>

							<option value="Web Development"> Web Development</option>

							<option value="App Development"> App Development</option>

							<option value=" Web Design"> Web Design</option>



							<option value="Digital Marketing / SEO"> Digital Marketing / SEO</option>

							<option value="MLM Development"> MLM Development</option>

							<option value="Domain/Hosting"> Domain/Hosting</option>

							<option value="Domain/Hosting"> others</option>

						</select>

        				<button type="submit" class="submit-btn btn-lg" name="submit" onclick="check_contact_no(2)">Submit</button>

					</form>

				</div>

       

</div>



	<!--callback requset popup-->

	<!-- Modal -->

        <div id="callback" class="modal fade animated swing" role="dialog">

          <div class="modal-dialog">



            <!-- Modal content-->

            <div class="modal-content" style="background-color: #fff!important;">

              <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal">&times;</button>

              </div>

              <div class="modal-body">

               <div class="request_form">

                 <form action="#" method="post">

                      <div class="form-group">

                        <label for="name" style="margin-left:0px;"> Name:</label>

                        <input type="text" name="cname" class="form-control" id="c_number" required>

                      </div>

                      <div class="form-group">

                        <label for="number" style="margin-left:0px;">Mobile Number:</label>

                        <!--<input type="text" class="form-control" id="cmobile" name="cmobile" pattern="^[6-9][0-9]{9}$">-->

                        

                        	<span id="message_4"></span>

        				<input type="text" name="cmobile" id="phone_4" placeholder="Enter your Phone" class="form-control" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="10" required>

                      </div>

                      <button name="submit2" type="submit" class="btn btn-success" onclick="check_contact_no(4)"><i class="fa fa-paper-plane"></i> Send Request</button>

                    </form>

               </div>

              </div>

              

            </div>



          </div>

        </div>

	<!--callback requset popup-->











	<!-- Modal -->

  <div class="modal fade" id="myModal" role="dialog">

    <div class="modal-dialog">

    

      <!-- Modal content-->

      <div class="modal-content mdc">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">×</button>

          <!--<h4 class="modal-title">Modal Header</h4>-->

        </div>

        <div class="modal-body">

                 <div class="lead-form lead-form2">

                    <h4>Submit Your Details and Get 25% Off </h4>

					<form class="popup-form" method="post">	

        				<!--<label>Your Name*</label>-->

        				<input type="text" name="name" placeholder="Enter your Name" class="input-box" required="">

        				<!--	<label>Your Email*</label>-->

        				<input type="email" name="email" placeholder="Enter your Email" class="input-box" required="">

        				<!--	<label>Your Phone*</label>-->

        				<span id="message_3"></span>

        				<input type="text" name="phone" id="phone_3" placeholder="Enter your Phone" class="input-box" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="10" required>

        			    <!-- <label>Choose Service*</label>-->

        				<select class="input-box" name="service" id="sel1" required="">

							<option value=""> --Choose Services--</option>

							<option value="Web Development"> Web Development</option>

							<option value="App Development"> App Development</option>

							<option value=" Web Design"> Web Design</option>



							<option value="Digital Marketing / SEO"> Digital Marketing / SEO</option>

							<option value="MLM Development"> MLM Development</option>

							<option value="Domain/Hosting"> Domain/Hosting</option>

							<option value="Domain/Hosting"> others</option>

						</select>

        				<button type="submit" class="submit-btn btn-lg" name="submit" onclick="check_contact_no(3)">Submit</button>

					</form>

				</div>

       

       

       

        </div>

      <!--  <div class="modal-footer">

          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        </div>-->

      </div>

      

    </div>

  </div>

  

  

  

  

  

		<!-- Main Menu -->

		<div class="main-menu-container navbar-fixed-top">

			<div id="main-menu" class="navbar navbar-default" role="navigation">

				<div class="container-fluid">

					

					<div class="navbar-header">

						<!-- responsive navigation -->

					<!--	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">

							<span class="sr-only">Toggle navigation</span>

							<i class="fa fa-bars"></i>

						</button>--> <!-- /.navbar-toggle -->

						<!-- Logo -->

						<h1>

							<a class="navbar-brand" href="http://primacyinfotech.com">

								<img class="logo" src="assets/images/logo.png" alt="Logo" rel="hoome">

							</a><!-- /.navbar-brand -->

						</h1>

					</div> <!-- /.navbar-header -->



					<nav class="collapse navbar-collapse">

						<!-- Main navigation -->

						<!--<a href="#donate" class="donate pull-right">Get A Quote <i class="fa fa-comments-o"></i></a>-->

	

						<ul id="headernavigation" class="nav navbar-nav pull-right">

						<li><a href="#top-section">Home</a></li>

						<li><a href="#service">Service</a></li>

							<li><a href="#about">About</a></li>

							<li><a href="#pricing">Package</a></li>

							

							

							<li><a href="#gallery">Gallery</a></li>

							

							

							

							<li><a href="#contact">Contact</a></li>

							<!-- <li><a href="#donate" class="donate">Donate <i class="fa fa-heart"></i></a></li> -->

							<button type="button" class="btn btn-outline-primary my-btn pull-right  hql" data-toggle="modal" data-target="#myModal">

  <i class="fa fa-bullhorn"></i>  Get Offer

  </button>	

				

						</ul> <!-- /.nav .navbar-nav -->

	</nav> <!-- /.navbar-collapse  -->

			<button type="button" class="btn btn-outline-primary my-btn my-btn2 pull-right  hql" data-toggle="modal" data-target="#myModal">

  <i class="fa fa-bullhorn"></i>  Get Offer

  </button>	

				

				</div> <!-- /.container -->

			</div><!-- /#main-menu -->

		</div><!-- /.main-menu-container -->

		<!-- Main Menu End -->











		<!-- Top Slider -->

		<section id="top-section">

			<div class="top-section parallax-style">

				<div class="parallax-overlay">

					<div class="slider-txt-container">

						<div id="top-carousel" class="carousel slide" data-ride="carousel">



							<ol class="carousel-indicators">

								<li data-target="#top-carousel" data-slide-to="0" class="active"></li>

								<li data-target="#top-carousel" data-slide-to="1"></li>

								<li data-target="#top-carousel" data-slide-to="2"></li>

							</ol><!-- /.carousel-indicators -->

							<div class="carousel-inner">



								<div class="item active">

									<p class="bold-txt">

										Make Your Own Online Shop 

									</p><!-- /.thin-text -->	

									<p class="bold-txt">

										Start From RS <span class="strikethrough-diagonal">14,999/-</span><mark>11,999/-</mark><sup class="blink">Limited Offer</sup></p><!-- /.thin-text -->

									<p class="thin-txt">

										Make Your Own ECommerce Website With Unlimite Product, Unlimted Category, Payment Gateway, Shipping Option, Powerful Admin Panel and Many More.

									</p><!-- /.thin-text -->

                                     <p class="bold-txt2">

                                      GET A <a target="_blank" href="tel:+91 9088015866"><span><img width="38" height="38" src="images/MeanFluffyGlassfrog-small.gif"></span><!--<i class="fas fa-phone-volume vol-my"></i>--></a> / 

                                      <a href="https://api.whatsapp.com/send?phone=919875627563" class="facebook-btn vol-my"><!--<i class="fab  fa-whatsapp-square"></i>--><span><img width="38" height="38" src="images/whatsapp.gif"></span></a> NOW- 9088015866

									</p>

									<p class="link">

										<!--<a href="#" class="btn custom-btn ">Learn More</a>-->

										 <button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal"href="#">Get Started <i class="fab fa-sistrix"></i></button>

             							 <button type="button" class="btn custom-btn mb" data-toggle="modal" data-target="#callback"href="#" style="color: #fff"><i class="fa fa-headset"></i> Call Back Request</button>

									</p> 				

								</div><!-- /.item -->



								<div class="item">

									<p class="bold-txt">

										Business Website With Admin Panel 

									</p><!-- /.thin-text -->	

									<p class="bold-txt">

										Start From RS <span class="strikethrough-diagonal">8,999/-</span><mark>	5,999/-</mark><sup class="blink">Limited Offer</sup></p><!-- /.thin-text -->

									<p class="thin-txt">

										Get a Complete Dynamic Website With Userfriendly Admin Panel, Responsive Layout,Upto 10 Pages and Many More.

									</p><!-- /.thin-text -->

                                      <p class="bold-txt2">

                                      GET A <a target="_blank" href="tel:+91 9088015866"><span><img width="38" height="38" src="images/MeanFluffyGlassfrog-small.gif"></span><!--<i class="fas fa-phone-volume vol-my"></i>--></a> / 

                                      <a href="https://api.whatsapp.com/send?phone=919875627563" class="facebook-btn vol-my"><!--<i class="fab  fa-whatsapp-square"></i>--><span><img width="38" height="38" src="images/whatsapp.gif"></span></a> NOW- 9088015866

									</p>

									<p class="link">

										<!--<a href="#" class="btn custom-btn ">Learn More</a>-->

										 <button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal"href="#">Get Started <i class="fab fa-sistrix"></i></button>

             							 <button type="button" class="btn custom-btn mb" data-toggle="modal" data-target="#callback"href="#" style="color: #fff"><i class="fa fa-headset"></i> Call Back Request</button>

									</p> 					

								</div><!-- /.item -->

								

									<div class="item">

									<p class="bold-txt">

										Make Your Own Android Application 



									</p><!-- /.thin-text -->	

									<p class="bold-txt">

										Start From RS <span class="strikethrough-diagonal">RS 24,999/-</span><mark>20,000/-</mark><sup class="blink">Limited Offer</sup></p><!-- /.thin-text -->

									<p class="thin-txt">

										Android Application With Admin Panel, Payment Gateway System, Booking System, Live Tracking System And Many More.

									</p><!-- /.thin-text -->

                                      <p class="bold-txt2">

                                      GET A <a target="_blank" href="tel:+91 9088015866"><span><img width="38" height="38" src="images/MeanFluffyGlassfrog-small.gif"></span><!--<i class="fas fa-phone-volume vol-my"></i>--></a> / 

                                      <a href="https://api.whatsapp.com/send?phone=919875627563" class="facebook-btn vol-my"><!--<i class="fab  fa-whatsapp-square"></i>--><span><img width="38" height="38" src="images/whatsapp.gif"></span></a> NOW- 9088015866

									</p>

									<p class="link">

										<!--<a href="#" class="btn custom-btn ">Learn More</a>-->

										 <button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal"href="#">Get Started <i class="fab fa-sistrix"></i></button>

             							 <button type="button" class="btn custom-btn mb" data-toggle="modal" data-target="#callback"href="#" style="color: #fff"><i class="fa fa-headset"></i> Call Back Request</button>

									</p> 					

								</div><!-- /.item -->





							

							</div><!-- /.carousel-inner -->

							<a class="slide-nav left" href="#top-carousel" data-slide="prev"><span></span></a>

							<a class="slide-nav right" href="#top-carousel" data-slide="next"><span></span></a>

						</div><!-- /#top-carousel -->

					</div><!-- /.slider-txt-container -->

				</div><!-- /.parallax-overlay -->

			</div><!-- /.top-section -->

		</section><!-- /#top-section -->

		<!-- Top Slider End-->





		<!-- Services Section -->

		<section id="service">

			<div class="services-section white-bg  section-padding">

				<div class="top-angle">

				</div><!-- /.top-angle -->

				<div class="container">

					<div class="section-head">

						<h2 class="section-title">

							Services

						</h2>

						<!--<p class="section-description">

							ALL OF OUR SERVICES IS CENTRALIZED TO THE WELFARE OF THE CHILDREN. WE SERVE THE CHILD WITH FOOD, EDUCATION, HABITATION, SAFETY AND EVERYTHING THE NEED. 

						</p>-->

					</div><!-- /.section-head -->



					<div class="section-content">

						<div class="row">

							<div class="col-md-4 from-bottom delay-200">

								<div class="service-box">

									<div class="hex service-icon-hex">

										<div class="service-icon">

											<span aria-hidden="true" class="li_star"></span>

										</div><!-- /.service-icon -->

									</div><!-- /.hex -->

									<h3 class="service-title content-title">

										Website Design 

									</h3><!-- /.service-title content-title -->

									<p class="service-description">

										

We offer custom and affordable Web Design Services.Our qualified web designers take your ideas, plan on it &amp; implement it to create your website. 

									</p><!-- /.service-description -->



									<!--<div class="services-button">

										<a href="#" class="btn custom-btn ">

											Learn More

										</a>

									</div>-->

								</div><!-- /.service-box -->

							</div><!-- /.col-md-4 -->



							<div class="col-md-4 from-bottom delay-600">

								<div class="service-box">

									<div class="hex service-icon-hex">

										<div class="service-icon">

											<span aria-hidden="true" class="li_like"></span>

										</div><!-- /.service-icon -->

									</div><!-- /.hex -->

									<h3 class="service-title content-title">

										WEB DEVELOPMENT



									</h3><!-- /.service-title content-title -->

									<p class="service-description">

										We are a web development company.We thoroughly understand your software specifications and develop, test and implement them.

									</p><!-- /.service-description -->



									

								</div><!-- /.service-box -->

							</div><!-- /.col-md-4 -->



							<div class="col-md-4 from-bottom delay-1000">

								<div class="service-box">

									<div class="hex service-icon-hex">

										<div class="service-icon">

											<span aria-hidden="true" class="li_world"></span>

										</div><!-- /.service-icon -->

									</div><!-- /.hex -->

									<h3 class="service-title content-title">

										Mobile Apps



									</h3><!-- /.service-title content-title -->

									<p class="service-description">

										We are app developers. Our mobile app development is highly polished. Our team of app designers craft powerful mobile applications for iPhone &aMobile Appsmp; Android.

									</p><!-- /.service-description -->



									

								</div><!-- /.service-box -->

							</div><!-- /.col-md-4 -->

							

							

							

										<div class="col-md-4 from-bottom delay-1000">

								<div class="service-box">

									<div class="hex service-icon-hex">

										<div class="service-icon">

											<span aria-hidden="true" class="li_shop"></span>

										</div><!-- /.service-icon -->

									</div><!-- /.hex -->

									<h3 class="service-title content-title">

										E-COMMERCE WEBSITE SERVICES



									</h3><!-- /.service-title content-title -->

									<p class="service-description">

										We understand your business relies on selling your products or services. Offering an array of E-Commerce web design services for your business. Contact us to start selling today!

									</p><!-- /.service-description -->



									

								</div><!-- /.service-box -->

							</div><!-- /.col-md-4 -->

							

							

										<div class="col-md-4 from-bottom delay-600">

								<div class="service-box">

									<div class="hex service-icon-hex">

										<div class="service-icon">

											<span aria-hidden="true" class="li_key"></span>

										</div><!-- /.service-icon -->

									</div><!-- /.hex -->

									<h3 class="service-title content-title">

                                       CUSTOMER SUPPORT

									</h3><!-- /.service-title content-title -->

									<p class="service-description">

										Best of all, we won’t rest until you get exactly what you wanted to get done. We take pride in ensuring all of our customers are satisfied with our final product.

									</p><!-- /.service-description -->



									

								</div><!-- /.service-box -->

							</div><!-- /.col-md-4 -->

							

							

							

										<div class="col-md-4 from-bottom delay-200">

								<div class="service-box">

									<div class="hex service-icon-hex">

										<div class="service-icon">

											<span aria-hidden="true" class="li_lock"></span>

										</div><!-- /.service-icon -->

									</div><!-- /.hex -->

									<h3 class="service-title content-title">

										SEARCH ENGINE OPTIMIZATION SERVICES

									</h3><!-- /.service-title content-title -->

									<p class="service-description">

										Want your website to rank higher on Google? We offer cheap Search Engine Optimization services for your keywords to rank higher.

									</p><!-- /.service-description -->



									

								</div><!-- /.service-box -->

							</div><!-- /.col-md-4 -->

							

							

							

							

							

						</div><!-- /.row -->

					</div><!-- /.section-content -->

				</div><!-- /.container-->

			</div><!-- /.services-section -->

		</section><!-- /#services -->

		<!--Services Section End-->







		<!-- About Section -->

		<section id="about">

			<div class="about-section"> 

				<div class="my-overlay section-padding">

					<div class="top-angle">

					</div><!-- /.top-angle -->

					<div class="container">

						<div class="section-head">

							<h2 class="section-title wh">About</h2>

							<p class="section-description wh">

								Primacy Infotech Pvt. Ltd. one of the Best Website Design Development Company in Kolkata, India. We Provide Web Design, Web Development, Web Hosting, Application Development, Mobile App Development, Digital marketing Services at affordable Cost.

							</p><!-- /.section-description -->

						</div><!-- /.section-head -->



						<div class="section-content">

							<div class="row">

								<div class="content-box col-md-8 from-bottom delay-200">

									<div class="hex content-icon-hex pull-left">

										<div class="content-icon">

											<span aria-hidden="true" class="li_bulb"></span>

										</div>

									</div><!-- /.content-icon-hex -->

									<h3 class="content-title wh">Why Choose US</h3>

									<p class="wh">

										<strong>Our goal is to provide complete, tailor-made internet presence solutions and flexible packages to match your corporate needs.We provide Websites in affordable rate. Our website making cost is low than any other company.</strong>

									</p>

								 <ul class="about-celeb">

								 	<li><img src="images/about/w-icon1.png" alt=""></li>

								 

								 	<li><img src="images/about/w-icon2.png" alt=""></li>

								 	<li><img src="images/about/w-icon3.png" alt=""></li>

								 	<li><img src="images/about/w-icon4.png" alt=""></li>

								 

								 </ul>

			                    <img class="satclient" src="images/about/whyus-sign.png" alt="">

												

								</div><!-- /.content-box -->



								<div class="media-content media-right col-md-4 from-bottom delay-600">

						  <div class="container-skills">

													<div class="html">

													<p class="bar-title wh">

														Web Development

														<span class="percent align-right">90%</span>

													</p>

													<div class="bar">

														<div class="bar-fill bar-fill-html start"></div>

													</div>

													</div>

													<div class="javascript">

														<p class="bar-title wh">

														App Development

															<span class="percent align-right">85%</span>

														</p>

														<div class="bar wh">

															<div class="bar-fill bar-fill-javascript start"></div>

														</div>

													</div>

													<div class="jquery">

														<p class="bar-title wh">

															Web Designing

															<span class="percent align-right">98%</span>

														</p>

														<div class="bar">

															<div class="bar-fill bar-fill-jquery start"></div>

														</div>

													</div>

													<div class="responsive-design">

														<p class="bar-title wh">

															Digital Marketing

															<span class="percent align-right">89%</span>

														</p>

														<div class="bar">

															<div class="bar-fill bar-fill-responsive start"></div>

														</div>

													</div>

											

												</div>

										

								</div><!-- /.media-content -->

								

								

								

								

							</div><!-- row -->

						</div><!-- /.section-content -->

					</div><!-- /.container -->

				</div><!-- /.white-bg -->



	

				

				

			</div><!-- /.about-section -->

		</section><!-- /#about-->

		<!-- About Section End -->

















		<!-- Pricing Section -->

		<section id="pricing">

			<div class="pricing-section">

				<div class="gray-bg  section-padding">

					<div class="top-angle">

					</div><!-- /.top-angle -->

					<div class="container">

						<div class="row">

							<div class="section-content">

												<h3 style="color:#666;" class="parallax-title">

								Affordable Prices & Packages

							</h3>

							<p style="text-align:center;font-weight:bold;">We don’t have any hidden charges. You can choose your suitable plan as you want.



</p>

								<div class="col-md-3 from-bottom delay-200">

						

									<div class="content-box">

						

										<div class="hex content-icon-hex hex-margin">

											<div class="content-icon">

												<span aria-hidden="true" class="li_banknote"></span>

											</div>

										</div><!-- /.content-icon-hex -->

										

										<h3 class="content-title-red">

											Free Stuffs with Every Package





										</h3><!-- /.content-title -->

										<p><i class="fa fa-cog fa-spin" style="font-size:24px"></i>&nbsp; Logo Designing</p>

										<p><i class="fa fa-cog fa-spin" style="font-size:24px"></i>&nbsp; Free Maintainence for 6 month</p>

										<p><i class="fa fa-cog fa-spin" style="font-size:24px"></i>&nbsp; Facebook Page Creation</p>

										<p><i class="fa fa-cog fa-spin" style="font-size:24px"></i>&nbsp; Submit to Google</p>

										<p><i class="fa fa-cog fa-spin" style="font-size:24px"></i>&nbsp; Social Share Widget</p>

                                        <p><i class="fa fa-cog fa-spin" style="font-size:24px"></i>&nbsp; Online chatting with Customer widget</p>

                                        <p><i class="fa fa-cog fa-spin" style="font-size:24px"></i>&nbsp;  Set up Google analitical account setup



</p>

                                       

									</div><!-- /.content-box -->

								</div><!-- /.col-md-4 -->



								<div class="col-md-9 from-right delay-200">

									<div class="pricing-table">

										

								<div id="causes-post-slider9"  class="owl-carousel owl-theme">

											<div class="item col-md-12">

												<div class="causes-post">

														<div class="pricing-item">

													<div class="item-head">

														<span class="item-name">Basic Website Package&nbsp;</span>



														<span class="item-currency">Rs</span><span class="item-price">5999</span> 

													</div><!-- /.item-head -->

													<ul class="item-description">

														<li>All Graphics including Logo, Banner</li>

														<li>Responsive Design</li>

														<li>Website Development&nbsp;using &amp; CMS&nbsp;</li>

														<li>Upto 5-6 Pages&nbsp;</li>

														<li>Web Space(1 GB)&nbsp;</li>

														<li>Unlimited Services&nbsp;</li>

														<li>User&nbsp;friendly&nbsp;admin&nbsp;</li>

														<li>C panel Map&nbsp;Integration&nbsp;on contract&nbsp;&nbsp;</li>

														<li>Inquiry&nbsp;from&nbsp;</li>

													</ul><!-- /.item-description -->

													<div class="item-footer">

														<!--<a href="#" class="btn custom-btn ">Purchase</a>-->

														<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal"href="#">Call Us Now <i class="fab fa-sistrix"></i></button>

													</div><!-- /.item-footer -->

												</div><!-- /.pricing-item --



												</div><!-- /.causes-post -->

											</div><!-- /.item col-md-12 -->

															</div>



										   <div class="item col-md-12">

												<div class="causes-post">



												<div class="pricing-item even">

													<div class="item-head2">

														<span class="item-name">Standard Website Package&nbsp; </span>

														<span class="item-currency">Rs</span><span class="item-price strikethrough-diagonal2 ">15,000</span> 

														<span class="item-currency">&nbsp;</span><span class="item-price">11,999</span> 

													</div><!-- /.item-head -->

													<ul class="item-description">

														<li style="color:red;">Everything Included in Basic Package</li>

														<li>E commerce&nbsp;Product system with Payment&nbsp;getaway Integration&nbsp;&nbsp;&nbsp;</li>

														<li>Upto 10 Pages&nbsp;</li>

														<li>Po Discount Coupon System&nbsp;</li>

														<li>Printable Invoices</li>

														<li>Sales Reports</li>

														<li>Indexing Service</li>

														<li>Social Accounts &amp; Networking Integration</li>

														<li>Visitor &amp; User Tracking System</li>

														

													</ul><!-- /.item-description -->

													<div class="item-footer">

														<!--<a href="#" class="btn custom-btn ">Purchase</a>-->

														<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal"href="#">Call Us Now <i class="fab fa-sistrix"></i></button>

													</div><!-- /.item-footer -->

												</div><!-- /.pricing-item -->

											</div>

															</div>



										  <div class="item col-md-12">

												<div class="causes-post">



												<div class="pricing-item">

													<div class="item-head">

														<span class="item-name">Premium&nbsp;Website Package</span>

														<span class="item-currency">Rs</span><span class="item-price">19999</span> 

													</div><!-- /.item-head -->

													<ul class="item-description">

														<li style="color:red;">Everything Included in Basic &amp; Standard Package</li>

														<li>Upto 16 Pages&nbsp;</li>

														<li>Unlimited Web Space&nbsp;</li>

														<li>Unlimited Emails&nbsp;&nbsp;</li>

														<li>Indexing Service</li>

														<li>Social Accounts &amp; Networking Integration</li>

														<li>Visitor &amp; User Tracking System</li>

														<li>Store in E-commerce Sites like Amazon,Snapdeal Flipkart Etc</li>

													

													</ul><!-- /.item-description -->

													<div class="item-footer">

														<!--<a href="#" class="btn custom-btn ">Purchase</a>-->

														<button type="button" class="btn custom-btn slid-button mb " data-toggle="modal" data-target="#myModal"href="#">Call Us Now <i class="fab fa-sistrix"></i></button>

													</div><!-- /.item-footer -->

												</div><!-- /.pricing-item -->



																</div>

															</div>



								</div>

									</div><!-- /.pricing-table -->

								</div><!-- /.col-md-8 -->

							</div><!-- /.section-content -->

						</div><!-- /.row -->

					</div><!-- /.container -->

					<div class="bottom-angle">

					</div><!-- /.bottom-angle -->

				</div><!-- ./gray-bg -->

			</div><!-- /.pricing-section -->

		</section><!-- /#pricing -->

		<!-- Pricing Section End -->





		<!-- Clients Section -->

		<section id="clients">

			<div class="clients-section parallax-style">

				<div class="my-overlay ">

					<div class="container">

						<div class="section-head">

							<h3 class="parallax-title">

								Our Partners

							</h3>

						</div><!-- /.section-head -->

<div class="row">

								<div id="causes-post-slider2"  class="owl-carousel owl-theme">

								

									<div class="item col-md-12">

										<div class="causes-post">

											

												<img src="images/clients-logo/3.png" alt="Clients Logo">

												

											

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

									

										<div class="item col-md-12">

										<div class="causes-post">

											

												<img src="images/clients-logo/4.png" alt="Clients Logo">

												

											

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

									

										<div class="item col-md-12">

										<div class="causes-post">

											

												<img src="images/clients-logo/5.png" alt="Clients Logo">

												

											

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

									

										<div class="item col-md-12">

										<div class="causes-post">

											

												<img src="images/clients-logo/6.png" alt="Clients Logo">

												

											

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

									

										<div class="item col-md-12">

										<div class="causes-post">

											

												<img src="images/clients-logo/7.png" alt="Clients Logo">

												

											

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

									

										<div class="item col-md-12">

										<div class="causes-post">

											

												<img src="images/clients-logo/8.png" alt="Clients Logo">

												

											

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

								

									

									

									

										<div class="item col-md-12">

										<div class="causes-post">

											

												<img src="images/clients-logo/stm2-1.png" alt="Clients Logo">

												

											

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

									

									

							



									<div class="item col-md-12">

										<div class="causes-post">

											<img src="images/clients-logo/logo-template-CDR2.png" alt="Clients Logo">

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									<div class="item col-md-12">

										<div class="causes-post">

											<figure>

										<img src="images/clients-logo/chaaplessnew4t.png" alt="Clients Logo">

												

											</figure>	

											

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->



									<div class="item col-md-12">

										<div class="causes-post">

											

											<img src="images/clients-logo/trisamtech.png" alt="Clients Logo">

												

											

										

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

												<div class="item col-md-12">

										<div class="causes-post">

											

											<img src="images/clients-logo/ATBSS-LogoHD-1.png" alt="Clients Logo">

												

											

										

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

												<div class="item col-md-12">

										<div class="causes-post">

											

											<img src="images/clients-logo/ramisha%20(1).png" alt="Clients Logo">

												

											

										

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

												<div class="item col-md-12">

										<div class="causes-post">

											

											<img src="images/clients-logo/zetnikws.png" alt="Clients Logo">

												

										

										

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->

									

									

												<div class="item col-md-12">

										<div class="causes-post">

										

											<img src="images/clients-logo/stm2-1.png" alt="Clients Logo">

												

										

										

										</div><!-- /.causes-post -->

									</div><!-- /.item col-md-12 -->



								</div><!-- /.causes-post-slider -->

							</div><!-- /row -->

							

						

						

					</div><!-- /.container -->

				</div><!-- /.parallax-overlay -->

			</div><!-- /.clients-section -->

		</section><!-- /#clients -->

		<!-- Clients Section End -->







	

		<!--Causes Section-->

	<!-- Upcoming Events Section -->

		<section id="gallery">

			<div class="upcoming-events-section gray-bg  section-padding">



				<div class="top-angle"></div>



				<div class="container">

					<div class="row">

						<div class="col-md-4">

							<div class="content-box">

								<div class="hex content-icon-hex hex-margin">

									<div class="content-icon">

										<span aria-hidden="true" class="li_calendar"></span>

									</div><!-- /.content-icon -->

								</div><!-- /.content-icon-hex -->

								<h3 class="content-title">

								Our Latest Projects

								</h3>

							

							</div><!-- /.content-box -->



							<div class="slide-nav-container customNavigation">

								<a class="slide-nav left slide-left" href="#event-post-slider" data-slide="prev"><i class="fa fa-chevron-left"></i></a>

								<a class="slide-nav right slide-right" href="#event-post-slider" data-slide="next"><i class="fa fa-chevron-right"></i></a>

							</div><!-- /.slide-nav-container -->

						</div><!-- /.col-md-4 -->



						<div class="col-md-8">

							<div class="row">

								<div class="event-container">

									<div id="event-post-slider"  class="owl-carousel owl-theme">



										<div class="item col-md-12">

											<div class="event-content">

											

											<a class="example-image-link" href="images/gallery/big5.png" data-lightbox="example-set" data-title="Rayna.">

											    <img src="images/gallery/big5.png" alt="Post Image">

											</a>

											</div><!-- /.event-content  -->

										</div><!-- /.item col-md-12 -->



										<div class="item col-md-12">

												<div class="event-content">

								              <a class="example-image-link" href="images/gallery/big2.png" data-lightbox="example-set" data-title="Anis Marketing">

										

											<img src="images/gallery/big2.png" alt="Post Image">

											</a>

											</div><!-- /.event-content  -->

										</div><!-- /.item col-md-12 -->



										<div class="item col-md-12">

											<div class="event-content">

											    <a class="example-image-link" href="images/gallery/big-6.png" data-lightbox="example-set" data-title="Howzent">

										

										<img src="images/gallery/big-6.png" alt="Post Image">

										</a>

											</div><!-- /.event-content  -->

										</div><!-- /.item col-md-12 -->



										<div class="item col-md-12">

											<div class="event-content">

											    <a class="example-image-link" href="images/gallery/big-7.png" data-lightbox="example-set" data-title="E Pariseva Kendra">

										

											<img src="images/gallery/big-7.png" alt="Post Image">

											</a>

											</div><!-- /.event-content  -->

										</div><!-- /.item col-md-12 -->

										

										

											<div class="item col-md-12">

											<div class="event-content">

											    <a class="example-image-link" href="images/gallery/relax.png" data-lightbox="example-set" data-title="Relax India">

										

										<img src="images/gallery/relax.png" alt="Post Image">

										</a>

											</div><!-- /.event-content  -->

										</div><!-- /.item col-md-12 -->

										

										

										

											<div class="item col-md-12">

											<div class="event-content">

											    <a class="example-image-link" href="images/gallery/big-6.png" data-lightbox="example-set" data-title="Howzent">

										

											<img src="images/gallery/big-6.png" alt="Post Image">

											</a>

											</div><!-- /.event-content  -->

										</div><!-- /.item col-md-12 -->

										

										

								





									</div><!-- /#event-post-slider -->



								</div><!-- /.event-container-->

							</div><!-- /.row -->

						</div><!-- /.com-md-8 -->

					</div><!-- /.row --> 

				</div><!-- /.container -->

				<div class="bottom-angle"></div>

			</div><!-- /.upcoming-events-section -->

		</section><!-- /.upcoming-events -->	

		<!--Upcoming Events Section End-->







		

		

		<!--Causes Section End-->

















        	<!--Testimonial Section-->

		<section id="testimonial">

			<div class="testimonial-section parallax-style">

				<div class="my-overlay section-padding">

					<div class="container">

						<div class="row">

							<div class="col-md-12">

								<div id="testimonial-carousel" class="carousel slide" data-ride="carousel">

									<ol class="carousel-indicators">

										<li data-target="#testimonial-carousel" data-slide-to="0" class="active"></li>

										<li data-target="#testimonial-carousel" data-slide-to="1"></li>

											<li data-target="#testimonial-carousel" data-slide-to="2" class="active"></li>

										<li data-target="#testimonial-carousel" data-slide-to="3"></li>

										

									

									</ol><!-- /.carousel-indicators -->

									<div class="carousel-inner">

										<div class="item active">

											<div class="testimonial-figure">



												<h3 class="parallax-title author-name">

													AYAN ROY

												</h3><!-- /.parallax-title -->

												<h4>Director of Relaxindia.org</h4>

												<p class="authors-review">

													“If you are looking for a Web Development company who is fast, organized and very detailed oriented... then you will find it with Primacy Infotech Pvt. Ltd. They designed, our idea of a website to all our specifications. They also made many creative improvements that we never thought of. We would recommend Primacy Infotech Pvt. Ltd. to anyone. ”





												</p><!-- /.authors-review -->

												<div class="author-avatar">

													<img class="img-circle" src="images/testimonial-carousel/qw.jpg" alt="carousel image">

												</div><!-- /.author-avatar -->

											</div><!-- /.testimonial-figure -->

										</div><!-- /.item -->

										<div class="item">

											<div class="testimonial-figure">

												<h3 class="parallax-title author-name">

													DEBASISH BISWAS



												</h3><!-- /.parallax-title -->

												<h4>Chief Instructor of Gpluseducation</h4>

												<p class="authors-review">

													“Great Team to work with, really attentive and react to request immediately. Excellent work and I'm really pleased with the results. Thanks Primacy Infotech Pvt. Ltd..”





												</p><!-- /.authors-review -->

												<div class="author-avatar">

													<img class="img-circle" src="images/testimonial-carousel/OD-OD-FINAl-2-75x75.jpg" alt="carousel image">	

												</div><!-- /.author-avatar -->

											</div><!-- /.testimonial-figure -->

										</div><!-- /.item -->

										

												<div class="item">

											<div class="testimonial-figure">

												<h3 class="parallax-title author-name">

													Anwar Sekh





												</h3><!-- /.parallax-title -->

												<h4>MD of Epariseva.com</h4>

												<p class="authors-review">

													“They provide great quality for the best prices that I have found in the business. I have been very happy with their work to date and recommend them highly. Thanks for the good job ....I LOVE my new website. ”









												</p><!-- /.authors-review -->

												<div class="author-avatar">

													<img class="img-circle" src="images/testimonial-carousel/dff.jpg" alt="carousel image">	

												</div><!-- /.author-avatar -->

											</div><!-- /.testimonial-figure -->

										</div><!-- /.item -->

										

										

										

										

										

										

										

										

										

										

										

										

										

										

											<div class="item">

											<div class="testimonial-figure">

												<h3 class="parallax-title author-name">

Sumanta Bhattacharjee.





												</h3><!-- /.parallax-title -->

												<h4>Director  of Institute of Alternative Medicines Kolkata</h4>

												<p class="authors-review">

													“We came to Primacy Infotech Pvt. Ltd. with a vision for our website. you listened, that vision with your constructive criticism and insight, produced a very attractive website! We hear nothing but positive comments! So again, THANK YOU! ”













												</p><!-- /.authors-review -->

												<div class="author-avatar">

													<img class="img-circle" src="images/testimonial-carousel/fff.jpg" alt="carousel image">	

												</div><!-- /.author-avatar -->

											</div><!-- /.testimonial-figure -->

										</div><!-- /.item -->

										

										

										

										

										

										

										

										

										

											<div class="item">

											<div class="testimonial-figure">

												<h3 class="parallax-title author-name">

													Pranob Roy





												</h3><!-- /.parallax-title -->

												<h4>MD of Flikin.com</h4>

												<p class="authors-review">

													“They provide great quality for the best prices that I have found in the business. I have been very happy with their work to date and recommend them highly. Thanks for the good job ....I LOVE my new website. ”









												</p><!-- /.authors-review -->

												<div class="author-avatar">

													<img class="img-circle" src="images/testimonial-carousel/dff.jpg" alt="carousel image">	

												</div><!-- /.author-avatar -->

											</div><!-- /.testimonial-figure -->

										</div><!-- /.item -->

										

										

										

										

										

								

									</div><!-- /.carousel-inner -->

								</div><!-- /#testimonial-carousel -->

							</div><!-- /.col-md-12 -->

						</div><!-- /.row -->

					</div><!-- /.container -->

				</div><!-- /.parallax-overlay -->

			</div><!-- /.testimonial-section -->

		</section><!-- /#testimonial -->

		<!--Testimonial Section End-->

 



		

		<!-- Contact Section -->

		<section id="contact">

			<div class="contact-section  section-padding">

				<div class="top-angle">

				</div><!-- /.top-angle -->

				<div class="container">

					<div class="section-head">

						<h2 class="section-title">

							Contact

						</h2>

					<!--	<p class="section-description">

							IF YOU FEEL, NEED WORKING FOR CHILD PLEASE CONTACT WITH US AND LET US KNOW HOW YOU LIKE TO WORK FOR THEM. CONTENT WITH US IF ANY MORE INFORMATION NEEDED.

						</p>-->

					</div><!-- /.section-head -->

				</div><!-- /.container -->



				<div class="container">

					<div class="row">

						<div class="col-md-6">

							<div class="contact-form-container">

								<h3 class="content-title">

									Drop us a message

								</h3>



								<form class="contact-form" id="contact-form" method="post">

									<div id="name_error" class="error">

										<img src="assets/images/email/error.png" alt="Error!">

										Please enter your name.

									</div><!-- /#name_error -->

									<div class="input-container li_user">

										<input type="text" class="form-control" name="name" id="name" placeholder="Name" required>

									</div><!-- /.input-container-->



									<div id="email_error" class="error">

										<img src="assets/images/email/error.png" alt="Error!">

										Please enter your valid E-mail ID.

									</div><!-- /#email_error -->

									<div class="input-container li_mail">

										<input type="email" class="form-control" name="email" id="email" placeholder="Email" required>

									</div><!-- /.input-container -->

									

									<div id="email_error" class="error">

										<img src="assets/images/email/error.png" alt="Error!">

										Please enter your valid Mobile Number.

									</div><!-- /#email_error -->

									<div class="input-container li_mail">

									    <span id="message_1"> </span>

										<input type="text" class="form-control" name="phone" id="phone_1" placeholder="Phone" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="10" required>

									</div><!-- /.input-container -->



									<div id="message_error" class="error">

										<img src="assets/images/email/error.png" alt="Error!">

										Please enter your message.

									</div><!-- /#message_error -->

									<div class="input-container li_pen">

										<textarea class="form-control" id="message" name="message" cols="45" placeholder="Message" rows="6"></textarea>

									</div><!-- /.input-container -->

									

									<div id="mail_success" class="success">

										<img src="assets/images/email/success.png" alt="Success!">

										Your message has been sent successfully.

									</div><!-- /#mail_success -->



									<div id='mail_fail' class='error'>

										<img src="assets/images/email/error.png" alt="Error!"> Sorry, error occured this time sending your message.

									</div><!-- /#mail_fail -->



									<button type="submit" class="btn custom-btn" name="submit1" onclick=" check_contact_no(1)">Submit</button>

								</form><!-- /.contact-form -->



							</div><!-- /.contact-form-container -->

						</div><!-- /.col-md-6 -->



						<div class="col-md-6">

							<div class="contact-info">

								<h3 class="content-title">

									Contact Info

								</h3>

							<!--	<p class="content-description">

									If you need more charity website templates or this charity website template contact with us. We will help you to make successful any of your charity works. Feel free to contact with us through mail address.

								</p>-->

								<address> 

									<ul class="contact-address">

									<li  style="color:#000,font-size:20px;font-weight:600;"><span><img src="images/inddd.png">&nbsp;India Office:</span></li>

										<li class="fa-map-marker">

											BF 79,BF Block ,Sector I,Salt Lake, Kolkata-64,WB,India

										</li>

										<li  class="fa-phone">

											<p>+91 9088015866,+91 9088015865 </p>

										</li>

										<li class="fa-envelope">

											info@primacyinfotech.com

										</li>

									<li  style="color:#000,font-size:20px;font-weight:600;"><span><img src="images/canada-flag-xs.png">&nbsp;Canada Office:</span></li>

										<li class="fa-map-marker">

											4656 Full Moon Circle Mississauga ON L4Z 2L7

										</li>

											<li  class="fa-phone">

											<p>+91 9088015866,+91 9088015865 </p>

										</li>

										<li class="fa-envelope">

											info@primacyinfotech.com

										</li>

									

										

									</ul><!-- /.contact-address --> 

								</address>

							</div><!-- /.contact-info -->

						</div><!-- /.col-md-6 -->

					</div><!-- /.row -->

				</div><!-- /.container -->

				<div class="bottom-angle">

				</div><!-- /.bottom-angle -->

			</div><!-- /.contact-section -->

		</section><!-- /#contact -->

		<!-- Contact Section End -->









		<!-- Google Map Section -->

		<div id="google-map">

		

				<!--<div id="googleMaps" class="google-map-container"></div>-->

				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3683.502460043862!2d88.41527041443443!3d22.59770463774481!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a0275edb646aaab%3A0x6dfe693a48717e5f!2sPrimacy+Infotech+Pvt.+Ltd.!5e0!3m2!1sen!2sin!4v1549888181663" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

			

		</div><!-- /#google-map-->

		<!-- Google Map Section End -->	









		<!-- Scroll to Top -->

		<div id="scroll-to-top">

			<div class="hex scroll-top">

				<span><i class="fa fa-chevron-up"></i></span>

			</div>

		</div><!-- /#scroll-to-top -->

		<!-- Scroll to Top End-->	









		<!-- Footer Section -->

		<footer id="footer-section">

			<div class="footer-section">

				<div class="container">

					<div class="footer-social-btn pull-right">

						<!--<a href="#" class="twitter-btn"><i class="fa fa-twitter"></i></a>-->

						<a href="https://www.facebook.com/primacyit/" class="facebook-btn"><i class="fab fa-2x fa-facebook"></i></a>

						<a href="https://api.whatsapp.com/send?phone=919875627563" class="facebook-btn"><i class="fab fa-2x fa-whatsapp-square"></i></a>

						<a href="https://www.linkedin.com/in/primacy-infotech-b96736154/" class="facebook-btn"><i class="fab fa-2x fa-linkedin"></i></a>

						

						<a href="https://www.youtube.com/channel/UCa4mcQ046494I8Vieqhg0Ow" class="facebook-btn"><i class="fab fa-2x fa-youtube-square"></i></a>

						<!--<a href="#" class="github-btn"><i class="fa fa-github-alt"></i></a>

						<a href="#" class="vimeo-btn"><i class="fa fa-vimeo-square"></i></a>

						<a href="#" class="pinterest-btn"><i class="fa fa-pinterest"></i></a>

						<a href="#" class="google-plus-btn"><i class="fa fa-google-plus"></i></a>

						<a href="#" class="youtube-btn"><i class="fa fa-youtube"></i></a>

						<a href="#" class="dribbble-btn"><i class="fa fa-dribbble"></i></a>

						<a href="#" class="linkedin-btn"><i class="fa fa-linkedin"></i></a>-->

					</div><!-- /.footer-social-btn -->

					<div class="copyrights pull-left">

						&copy; <a href="http:www.primacyinfotech.in"> Primacy Infotech Pvt.</a> 2019, All rights reserved 

						

						

					</div><!-- /.copyrights -->



					

				</div><!-- /.container -->

			</div><!-- /.footer-section -->

		</footer><!-- /#footer-section -->

		<!-- Footer Section End -->





<!--mobile footer-->

    <div class="footer-navbar animated fadeInUp">

<!--      <a href="#home" class="skype"><i class="fa fa-twitter" aria-hidden="true"></i>

</a>-->

      <a href="https://www.facebook.com/primacyit/" target="_blank" class="facebook"><i class="fab fa-facebook-f"></i></a>

      <a href="https://api.whatsapp.com/send?phone=919875627563" target="_blank" class="home"><i class="fab fa-whatsapp"></i></a>

      <!--<a href="https://api.whatsapp.com/send?phone=919875627563" target="_blank" class="skype"><i class="fab fa-skype"></i></a>-->

      <a href="tel:+9088015866" class="phone"><i class="fas fa-phone"></i></a>

      <a href="mailto:info@primacyinfotech.com"><i class="fa fa-envelope"></i></a>

    </div>

    <!--mobile footer-->



<style>

    /*mobilefooter*/

.footer-navbar {

  overflow: hidden;

  background-color: #333;

  position: fixed;

  bottom: 0;

  width: 100%;

  display: none;

      z-index: 99999;

}



.footer-navbar a {

  float: left;

  display: block;

  color: #f2f2f2;

  text-align: center;

  padding: 14px 28px;

  text-decoration: none;

  font-size: 18px;

}



.footer-navbar a:hover {

  background: #f1f1f1;

  color: black;

}



.footer-navbar a.active {

  background-color: #4CAF50;

  color: white;

}

.footer-navbar a.facebook {

  background-color:  #3b5998;

  color: white;

}

.footer-navbar a.skype {

  background-color:  #00AFF0;

  color: white;

}

.footer-navbar a.phone {

  background-color:  darkred;

  color: white;

}

	#cboxContent {

    background: #56565680;

    overflow: hidden;

}





/*mobilefooter*/

@media only screen and (max-width: 600px) {.footer-navbar {display: block;}}









</style>







    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>



		<!-- Include jquery.min.js plugin -->

		<script src="assets/js/jquery-2.1.0.min.js"></script>



		<!-- Include email-validation.js Email Validator -->

		<script src="assets/js/email-validation.js"></script>



		<script src="assets/js/jquery.visible.min.js"></script>



		<!-- included plugins inside  plugins.js -->

		<script src="assets/js/plugins.js"></script>



		<!-- included plugins inside  plugins.js -->

		<script src="assets/js/jquery.parallax.js"></script>				



		<!-- Include functions.js -->

		<script src="assets/js/functions.js"></script>



		<!-- Google Maps Script  -->

		<script src="http://maps.google.com/maps/api/js?sensor=true"></script> 



		<!-- Gmap3.js For Static Maps -->

		<script src="assets/js/gmap3.js"></script>

		<script src="assets/js/colorbox-min.js"></script>

		<script src="assets/js/cookie.min.js"></script>

<script src="assets/js/lightbox.js"></script>

		<script type="text/javascript">



			/*---------------------- Current Menu Item -------------------------*/

			jQuery(document).ready(function($) {

				"use strict";



				$('#main-menu #headernavigation').onePageNav({

					currentClass: 'active',

					changeHash: false,

					scrollSpeed: 750,

					scrollThreshold: 0.5,

					scrollOffset: 60,

					filter: '',

					easing: 'swing'

				}); 



				$('#event_time_countdown').countDown({

					targetDate: {

						'day': 23,

						'month': 9,

						'year': 2020,

						'hour': 0,

						'min': 0,

						'sec': 0

					},

					omitWeeks: true

				});





				/*----------- Google Map - with support of gmaps.js ----------------*/

				function isMobile() { 

					return ('ontouchstart' in document.documentElement);

				}



				function init_gmap() {

					if ( typeof google == 'undefined' ) return;

					var options = {

						center: [23.709921, 90.407143],

						zoom: 15,

						mapTypeControl: true,

						mapTypeControlOptions: {

							style: google.maps.MapTypeControlStyle.DROPDOWN_MENU

						},

						navigationControl: true,

						scrollwheel: false,

						streetViewControl: true

					}



					if (isMobile()) {

						options.draggable = false;

					}



					$('#googleMaps').gmap3({

						map: {

							options: options

						},

						marker: {

							latLng: [23.709921, 90.407143],

							options: { icon: 'assets/images/mapicon.png' }

						}

					});

				}



				init_gmap();



			});

		</script>

		<script>

// When the user scrolls the page, execute myFunction 

window.onscroll = function() {myFunction()};



function myFunction() {

  var winScroll = document.body.scrollTop || document.documentElement.scrollTop;

  var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;

  var scrolled = (winScroll / height) * 100;

  document.getElementById("myBar").style.width = scrolled + "%";

}

</script>

<script>

		$(".clear-cookie").on("click", function() {

  Cookies.remove('colorboxShown');

  $(this).replaceWith("<p><em>Cookie cleared. Re-run demo</em></p>");

});



$(".order-cheezburger").on("click", function() {

  $.colorbox.close();

});



function onPopupOpen() {

  $("#modal-content").show();

  $("#yurname").focus();

}



function onPopupClose() {

  $("#modal-content").hide();

  Cookies.set('colorboxShown', 'yes', {

    expires: 1

  });

  $(".clear-cookie").fadeIn();

  lastFocus.focus();

}



function displayPopup() { 

  $.colorbox({

    inline: true,

    href: "#modal-content",

    className: "cta",

    width:390,

    height: 420,

    onComplete: onPopupOpen,

    onClosed: onPopupClose

  });

}



var lastFocus;

var popupShown = Cookies.get('colorboxShown');



if (popupShown) {

  console.log("Cookie found. No action necessary");

  $(".clear-cookie").show();

} else {

  console.log("No cookie found. Opening popup in 3 seconds");

  $(".clear-cookie").hide();

  setTimeout(function() {

    lastFocus = document.activeElement;

    displayPopup();

  }, 10000);

}</script>



<script type="text/javascript">

var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();

(function(){

var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];

s1.async=true;

s1.src='https://embed.tawk.to/5c3f2feaab5284048d0d395e/default';

s1.charset='UTF-8';

s1.setAttribute('crossorigin','*');

s0.parentNode.insertBefore(s1,s0);

})();

</script>

<!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-110654741-6"></script>

<script>

  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());



  gtag('config', 'UA-110654741-6');

</script>





<!-- Global site tag (gtag.js) - Google Ads: 751223910 -->

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-751223910"></script>

<script>

  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());



  gtag('config', 'AW-751223910');

</script>

<!-- Event snippet for Leads conversion page

In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->

<script>

function gtag_report_conversion(url) {

  var callback = function () {

    if (typeof(url) != 'undefined') {

      window.location = url;

    }

  };

  gtag('event', 'conversion', {

      'send_to': 'AW-751223910/q0bDCJv_75gBEOaIm-YC',

      'event_callback': callback

  });

  return false;

}

</script>

</body>





<?php

    if(isset($_POST['submit1']))

    {

        $name = $_POST['name'];

        $email = $_POST['email'];

        $phone = $_POST['phone'];

        $message = $_POST['message'];

        

        $servername = "localhost";

        $username = "primacy_leads";

        $password = "iQKWuGYI7rob";

        $dbname = "primacy_leads";

        

        // Create connection

        $conn1 = new mysqli($servername, $username, $password, $dbname);

        // Check connection

        if ($conn1->connect_error) {

            die("Connection failed: " . $conn1->connect_error);

        } 

        

        $date10 = date('Y-m-d');

        $datetime10 = date('Y-m-d H:i:s');

        $ip10 = $_SERVER['REMOTE_ADDR'];

        

        $sql1 = "INSERT INTO leads (name, phone, email, message, date, doc, ip) VALUES ('$name', '$phone', '$email', '$message', '$date10', '$datetime10', '$ip10')";

        $conn1->query($sql1);

        

        

        $to = "rumita@primacyinfotech.com,sudipta@primacyinfotech.com";

        $subject = "Contact Request";

        

        $message = "

        <html>

        <head>

        <title>Contact Request</title>

        </head>

        <body>

        <p>Contact Request</p>

        <table>

        <tr>

            <th>Name</th>

            <th>Phone No</th>

            <th>Email</th>

            <th>Message</th>

        </tr>

        <tr>

            <td>".$name."</td>

            <td>".$phone."</td>

            <td>".$email."</td>

            <td>".$message."</td>

        </tr>

        </table>

        </body>

        </html>";

        

        //Always set content-type when sending HTML email

        $headers = "MIME-Version: 1.0" . "\r\n";

        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        

        // More headers

        $headers .= 'From: <info@primacyinfotech.com>' . "\r\n";

        $headers .= 'Cc: kabir@primacyinfotech.com' . "\r\n";

        

        if(mail($to,$subject,$message,$headers))

        {

            echo ("<script LANGUAGE='JavaScript'>swal('Thank you for visiting out site', 'Sortly we will contact', 'success');</script>");

        }

        else

        {

            

        }

        

        

    }

?>



<?php

    if(isset($_POST['submit2']))

    {

        $cname = $_POST['cname'];

        $cphone = $_POST['cmobile'];

        

        $servername = "localhost";

        $username = "primacy_leads";

        $password = "iQKWuGYI7rob";

        $dbname = "primacy_leads";

        

        // Create connection

        $conn1 = new mysqli($servername, $username, $password, $dbname);

        // Check connection

        if ($conn1->connect_error) {

            die("Connection failed: " . $conn1->connect_error);

        } 

        

        $date1 = date('Y-m-d');

        $datetime1 = date('Y-m-d H:i:s');

        $ip1 = $_SERVER['REMOTE_ADDR'];

        

        $sql1 = "INSERT INTO leads (name, phone, email, service, date, doc, ip) VALUES ('$cname', '$cphone', '0', '0', '$date1', '$datetime1', '$ip1')";

        $conn1->query($sql1);        

        /*$to = "sohinee@primacyinfotech.com";
        $subject = "Call Back Request";
        $message = "
        <html>
        <head>
        <title>Call Back Request</title>
        </head>
        <body>
        <p>Call Back Request</p>
        <table>
        <tr>
            <th>Name</th>
            <th>Phone No</th>
        </tr>
        <tr>
            <td>".$cname."</td>
            <td>".$cphone."</td>
        </tr>
        </table>
        </body>
        </html>";     

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: <info@primacyinfotech.com>' . "\r\n";
        $headers .= 'Cc: kabir@primacyinfotech.com' . "\r\n";        

        if(mail($to,$subject,$message,$headers))
        {
            echo ("<script LANGUAGE='JavaScript'>swal('Thank you for visiting out site', 'Sortly we will contact', 'success');</script>");
        }*/

        $body = [
    'Messages' => [
        [
        'From' => [
            'Email' => "info@primacyinfotech.com",
            'Name' => "primacyinfotech"
        ],
        'To' => [
            [
            'Email' => "sohinee@primacyinfotech.com",
            'Name' => "Sohinee"
            ],
            [
            'Email' => "kabir@primacyinfotech.com",
            'Name' => "Kabir"
            ]
        ],
        'Subject' => "Call Back Request",
        'HTMLPart' => "<html>
        <head>
        <title>Call Back Request</title>
        </head>
        <body>
        <p>Call Back Request</p>
        <table>
        <tr>
            <th>Name</th>
            <th>Phone No</th>
        </tr>
        <tr>
            <td>".$cname."</td>
            <td>".$cphone."</td>
        </tr>
        </table>
        </body>
        </html>"
        ]
    ]
];
 
$ch = curl_init();
 
curl_setopt($ch, CURLOPT_URL, "https://api.mailjet.com/v3.1/send");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json')
);
curl_setopt($ch, CURLOPT_USERPWD, "f6013a7295c2b8cf05912fe6c0734850:0fc23d25c6361571ce4047efd75ffb4e");
$server_output = curl_exec($ch);
curl_close ($ch);
 
$response = json_decode($server_output);
if ($response->Messages[0]->Status == 'success') {
    echo ("<script LANGUAGE='JavaScript'>swal('Thank you for visiting out site', 'Sortly we will contact', 'success');</script>");
}

        

    }

?>







<?php

    if(isset($_POST['submit']))

    {

        $name = $_POST['name'];

        $phone = $_POST['phone'];

        $email = $_POST['email'];

        $service = $_POST['service'];

        

        $servername = "localhost";

        $username = "primacy_leads";

        $password = "iQKWuGYI7rob";

        $dbname = "primacy_leads";

        

        // Create connection

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection

        if ($conn->connect_error) {

            die("Connection failed: " . $conn->connect_error);

        } 

        

        $date = date('Y-m-d');

        $datetime = date('Y-m-d H:i:s');

        $ip = $_SERVER['REMOTE_ADDR'];

        

        $sql = "INSERT INTO leads (name, phone, email, service, date, doc, ip) VALUES ('$name', '$phone', '$email', '$service', '$date', '$datetime', '$ip')";

        $conn->query($sql);        

        /*$to = "sohinee@primacyinfotech.com";
        $subject = "Adword Lead Details";
        $message = "
        <html>
        <head>
        <title>Lead Email</title>
        </head>
        <body>
        <p>Lead Details</p>
        <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone No</th>
            <th>Service</th>
        </tr>
        <tr>
            <td>".$name."</td>
            <td>".$email."</td>
            <td>".$phone."</td>
            <td>".$service."</td>
        </tr>
        </table>
        </body>
        </html>";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: <info@primacyinfotech.com>' . "\r\n";
        $headers .= 'Cc: kabir@primacyinfotech.com' . "\r\n";        

        if(mail($to,$subject,$message,$headers))
        {
            echo ("<script LANGUAGE='JavaScript'>swal('Thank you for visiting out site', 'Sortly we will contact', 'success');</script>");
        }*/

        $body = [
    'Messages' => [
        [
        'From' => [
            'Email' => "info@primacyinfotech.com",
            'Name' => "primacyinfotech"
        ],
        'To' => [
            [
            'Email' => "sohinee@primacyinfotech.com",
            'Name' => "Sohinee"
            ],
            [
            'Email' => "kabir@primacyinfotech.com",
            'Name' => "Kabir"
            ]
        ],
        'Subject' => "Adword Lead Details",
        'HTMLPart' => "<html>
        <head>
        <title>Lead Email</title>
        </head>
        <body>
        <p>Lead Details</p>
        <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone No</th>
            <th>Service</th>
        </tr>
        <tr>
            <td>".$name."</td>
            <td>".$email."</td>
            <td>".$phone."</td>
            <td>".$service."</td>
        </tr>
        </table>
        </body>
        </html>"
        ]
    ]
];
 
$ch = curl_init();
 
curl_setopt($ch, CURLOPT_URL, "https://api.mailjet.com/v3.1/send");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json')
);
curl_setopt($ch, CURLOPT_USERPWD, "f6013a7295c2b8cf05912fe6c0734850:0fc23d25c6361571ce4047efd75ffb4e");
$server_output = curl_exec($ch);
curl_close ($ch);
 
$response = json_decode($server_output);
if ($response->Messages[0]->Status == 'success') {
    echo ("<script LANGUAGE='JavaScript'>swal('Thank you for visiting out site', 'Sortly we will contact', 'success');</script>");
}

        

        /*$config['protocol'] = 'smtp';

		$config['smtp_host'] = 'ssl://smtp.gmail.com';

		$config['smtp_port'] = 465;

		$config['smtp_user'] = 'testing.primacy@gmail.com';

		$config['smtp_pass'] = 'primacy2018';

		$config['charset'] = 'utf-8';

		$config['wordwrap'] = TRUE;

		$config['crlf'] = '\r\n';

		

		$this->load->library('email');

		$this->email->initialize($config);

		$this->email->set_newline("\r\n");



		$this->email->from('Claims@A1Resolve.com', 'A1Resolve Admin Team');

		$this->email->to('qobo@banit.me');

		$this->email->cc('ceo@a1resolve.com');

		

		$this->email->subject($subject);

		$this->email->message($message);

		$this->email->set_mailtype('html');

		$this->email->send();

        */

          

    }

?>



<!--phone no validation code-->

                                                    <script>

                                                    	function check_contact_no(i)

                                                    	{

                                                    		var contact_no= $("#phone_"+i).val();

                                                    		if(contact_no!='')

                                                    		{

                                                    			var re = new RegExp("^[6-9][0-9]{9}$");

                                                    			if (re.test(contact_no)) {

                                                    				$("#message_"+i).html('');

                                                    			} else {

                                                    				$("#phone_"+i).val('');

                                                    				$("#message_"+i).html('<span style="color:red;">Invalid Mobile Number!!!</span>');

                                                    			}

                                                    		}

                                                    	}

                                                    </script>

<!--phone no validation code-->

</html>