

<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css'>
<!-- icon---->
<link  rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" >
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/icofont/icofont.min.css">
    <!-- ser -->
           <!--  <script src="js/jquery-1.3.2.js"></script>-->

    <script src="../js/jquery.js"></script>

    <!-- animation -->
    <link href="https://fonts.googleapis.com/css?family=Lora" rel="stylesheet">
<!--    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow&v1' rel='stylesheet' type='text/css' />
    <link href='http://fonts.googleapis.com/css?family=Wire+One&v1' rel='stylesheet' type='text/css' />-->
    <!-- hover -->
    <link rel="stylesheet" href="../hover.css">

   <!-- <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">-->
    <link rel="stylesheet" href="../css/sstyle.css">

     <link rel="stylesheet" href="../css/style.css">
      <link rel="stylesheet" href="../css/common-style.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js"></script>

<script type="text/javascript">
    $(function() {
        $(window).scrollTo(0,1);
    }
</script>
</script>
<link rel="stylesheet" href="../owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="../owlcarousel/assets/owl.theme.default.min.css">
<script src="../owlcarousel/owl.carousel.min.js"></script>

<link rel="icon" href="../pilogofab.png" type="image/gif" sizes="HeightxWidth|any">

<link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.css"/>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-110654741-8"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-110654741-8');
</script>
<script src="https://unpkg.com/sweetalert%402.1.2/dist/sweetalert.min.js"></script>

</head>


<!-- Mirrored from primacyinfotech.com/about.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jan 2020 10:50:30 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<body>
    <!-- particles.js container -->




    <!-- particles.js lib - https://github.com/VincentGarreau/particles.js -->
    <script src="../js/particles.js"></script>

    <div id="particles-js">
    </div>

    <div class="count-particles">
    </div>
    <!-- stats.js lib -->
    <!-- <script src="http://threejs.org/examples/js/libs/stats.min.js"></script> -->

<!--
    <div class="top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 pic0"><img src="images/primacy.png"></div>
                <div class="col-md-7">
						   <div class="col-md-12">
							   <div class="c-mob">
								   <div class="col-md-4">
										  <img src="images/inddd.png" alt="india">&nbsp;
										   <a href="tel:+91 9088015866" class="">+91 9088015866</a>
										  <a href="tel:+91 9088015865" class="">/65</a>
								   </div>
									<div class="col-md-4">
										   <img width="16" height="11" src="images/canada-flag-xs.png" alt="india"> &nbsp;
										   <a href="tel:+16474908004" class="Blondie-email">+16474908004</a>
										
								   </div>
									<div class="col-md-4">
										   <img width="16" height="11" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;
										   <a href="tel:+88 01759787636" class="Blondie-email">+88 01759787636</a>
										  
								   </div>
								   </div>
					       </div>
                </div>
                <div class="hidden-xs col-md-2 dropdown ">
					<button class="btn btn-primary dropdown-toggle pull-right" type="button" data-toggle="dropdown"><i class="fas fa-globe"></i>&nbsp;Global
					<span class="caret"></span></button>
					<ul class="dropdown-menu pull-right">
					  <li><a href="https://www.primacyinfotech.in"><span><img src="images/inddd.png" alt="india"> &nbsp;India</span></a></li>
					  <li><a href="https://ca.primacyinfotech.com"><span><img width="16" height="11" src="images/canada-flag-xs.png" alt="india"> &nbsp;Canada</span></a></li>
					  <li><a href="http://bd.primacyinfotech.com"><span><img width="16" height="11" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;Bangladesh</span></a></li>
					</ul>
			  </div>
							<div class="col-md-6 pic1"><img src="images/primacy%20cms.png"></div>
            </div>
        </div>
    </div>
    
-->
    
    
   <!-- <div class="col-sm-12 col-xs-12 menu-right">-->
    
    
<!--
    <div class="nav-side-menu" id="slide_menu2" style="display:none;">



    <div class="brand">Menu</div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">

                    
 
                <li>
                  <a href="index.php">
                  <i class="fa fa-dashboard fa-lg"></i> Home
                  </a>
                </li>

                <li  data-toggle="collapse" data-target="#products" class="collapsed active">
                  <a href="#"><i class="fa fa-gift fa-lg"></i> Services<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="products">
                    <li class="active"><a href="web-development.php">Web Development</a></li>
                           <li><a href="web-designing.php">Web Designing</a>
                    </li>
                      <li><a href="crm-erp.php">CRM & ERP</a>
                    </li>
                      <li><a href="mobile-application.php">Mobile Apps Development</a>
                    </li>
                       <li><a href="digital-marketing.php">Digital Marketing</a>
                    </li>
                       <li><a href="ui-ux.php">UI/UX Design</a>
                    </li>
                        <li><a href="portal-development.php">Portal Development</a>
                    </li>
                       <li><a href="ecommerce-development.php">Ecommerce Development</a>
                    </li>
               
                 
                  
                    
                     
                </ul>


                <li data-toggle="collapse" data-target="#service" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> Solution <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="service">
                    <li class="active"><a href="http://www.travelbusinessportal.com/">Travel Portal</a></li>
                    <li><a href="school-mangement.php">School Management</a>
                       </li>
                      <li><a href="crm-erp.php">CRM & ERP</a>
                    </li>
                      <li><a href="loan">Loan Management</a>
                    </li>
                       <li><a href="health.php">Healthcare Management</a>
                    </li>
                       <li><a href="mlm.php">MLM</a>
                    </li>
                        <li><a href="portal-development.php">Readymade Ecommerce</a>
                    </li>
               
                       <li><a href="portal-development.php">Billing Software</a>
                    </li>
                       <li><a href="portal-development.php">Accounting Software</a>
                    </li>
                       <li><a href="portal-development.php">Video Portal</a>
                    </li>
                       <li><a href="portal-development.php">Readymade Ecommerce</a>
                    </li>
                      
                </ul>
                       <li data-toggle="collapse" data-target="#about" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> About Us <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="about">
                    <li class="active"><a href="http://www.travelbusinessportal.com/">Travel Portal</a></li>
					<li><a href="school-mangement.php">Why Us</a></li>
                    <li><a href="crm-erp.php">Company</a>
                    </li>
                      <li><a href="loan">Infrastructure</a>
                    </li>
                       <li><a href="health.php">Team</a>
                    </li>
                    <li><a href="sucess-story.php">Our Success Story</a>
                    </li>
                     
                      
                </ul>


                 <li>
                  <a href="contact.php">
                  <i class="fa fa-users fa-lg"></i> Contact us
                  </a>
                </li>

            </ul>
     </div> 
     	<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-whatsapp"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-skype"></i></a></li>
						<li class="list-inline-item"><a href="" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul> 
</div>
-->




<!--
    <div id="menuwrapper">
        <ul id="sidemenu">
            <li><a class="" href="https://primacyinfotech.com/"><i class="fas fa-home"><br>Home</i></a></li>

            <li><a href="#"><i class="fas fa-server"><br>
                        Service</i></a>
                <ul class="my-col-2">

                    <li>
                       <a href="web-developement.php"><i class="icofont-code icofont-2x"></i><br />
                        <div class="txt">Web Development</div>
						</a>
                    </li>
                        <li><a href="web-designing.php"><i class="icofont-dashboard-web icofont-2x"></i>
                            
                            <div class="txt">Web Designing</div>
                        </a>
                    </li>
                      <li><a href="android-developemnt.php"><i class="icofont-brand-android-robot icofont-2x"></i><br />
                        <div class="txt">Apps Development</div>
						  </a>
                    </li>
               
                    <li><a href="crm-erp.php"><i class="icofont-computer icofont-2x"></i><br />
                        <div class="txt">CRM & ERP</div> 
						</a>
                    </li>
                  
                    
                     <li><a href="digital-marketing.php"><i class="icofont-automation icofont-2x"></i><br />
                        <div class="txt">Digital Marketing</div>
						 </a>
                    </li>
                  
                    <li><a href="ui-ux.php"><i class="icofont-penalty-card icofont-2x"></i><br />
                        <div class="txt">UI/UX Design</div>
						</a>
                    </li>
              
                 
                    <li><a href="ecommerce-developemnt.php"><i class="icofont-shopping-cart icofont-2x"></i><br />
                        <div class="txt">Ecommerce Development</div>
						</a>
                    </li>
                     <li><a href="food-order-app.php"><i class="icofont-fast-food icofont-2x"></i><br />
                        <div class="txt">Food Delhivery App</div> 
						</a>
                    </li>
                       <li><a href="portal-recharge.php"><i class="icofont-brand-china-mobile icofont-2x"></i><br />
                        <div class="txt">Recharge Portal</div> 
						</a>
                    </li>

                </ul>

            </li>

            <li><a href="#"><i class="fas fa-server"><br>
                        Solution</i></a>
                <ul class="my-col-2">
                    <li><a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel Portal</div>
                        </a>
                    </li>
                    <li>
                       <a href="portal-school.php"><i class="icofont-building-alt icofont-2x"></i><br />
						   <div class="txt">School Management</div></a>
                    </li>
                      <li>
                       <a href="portal-lms.php"><i class="icofont-learn icofont-2x"></i><br />
						   <div class="txt">Learning Management</div></a>
                    </li>
                      <li><a href="portal-loan.php"><i class="icofont-money-bag icofont-2x"></i><br />
						  <div class="txt">Loan Management</div></a> 
                    </li>
                    <li><a href="portal-health.php"><i class="icofont-doctor icofont-2x"></i><br />
						<div class="txt">Healthcare Management</div></a>
                    </li>
                    <li><a href="portal-mlm.php"><i class="icofont-company icofont-2x"></i><br />
						<div class="txt">MLM Software</div></a>
                    </li>
                    <li><a href="portal-accounting.php"><i class="icofont-paper icofont-2x"></i><br />
						<div class="txt">Accounting</div></a>
                    </li>
                     <li><a href="portal-video.php"><i class="icofont-video-cam icofont-2x"></i>
                            
                            <div class="txt">Video Portal</div>
                        </a>
                    </li>
                    <li><a href="portal-realestate.php"><i class="icofont-search-property icofont-2x"></i>
                            
                            <div class="txt">Realestate</div>
                        </a>
                    </li>
                     <li><a href="portal-ola.php"><i class="icofont-car-alt-1 icofont-2x"></i>
                            
                            <div class="txt">OLA/Uber Clone</div>
                        </a>
                    </li>


                </ul>

            </li>
            
                <li><a href="#"><i class="fas fa-industry"><br>
                        Industry</i></a>
                <ul class="my-col-2">
                    <li><a href="#"><i class="icofont-doctor icofont-2x"></i><br />
                        <div class="txt">Healthcare</div>
                        </a>
                    </li>
                    <li>
                       <a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel</div>
						</a>
                    </li>
                      <li><a href="#"><i class="icofont-paper icofont-2x"></i><br />
                        <div class="txt">Financial</div>
						  </a>
                    </li>
                    <li><a href="#"><i class="icofont-ui-cart icofont-2x"></i><br />
                        <div class="txt">Retail</div>
						</a>
                    </li>
                    <li><a href="#"><i class="icofont-holding-hands icofont-2x"></i><br />
                        <div class="txt">Insurance</div>
						</a>
                    </li>
                     <li><a href="#"><i class="icofont-bank icofont-2x"></i>
                            
                            <div class="txt">Banking</div>
                        </a>
                    </li>
                      <li><a href="#"><i class="icofont-man-in-glasses icofont-2x"></i>
                            
                            <div class="txt">Goverment</div>
                        </a>
                    </li>
                      <li><a href="#"><i class="icofont-newspaper icofont-2x"></i>
                            
                            <div class="txt">Media </div>
                        </a>
                    </li>
                    
                    
                     
                    
                
                     




                </ul>

            </li>
            
            
            
            <li><a href="#"><i class="fas fa-paper-plane"><br>
                        About us</i></a>
                        
                <ul class="my-col-2">
                    <li><a href="why-us.php"><i class="icofont-question-square icofont-2x"></i><br />
                        <div class="txt">Why Us</div>
                        </a>
                    </li>
                    <li>
                       <a href="our-company.php"><i class="icofont-building icofont-2x"></i><br />
                        <div class="txt">Company</div>
						</a>
                    </li>
                      <li><a href="career.php"><i class="icofont-search-job icofont-2x"></i><br />
                        <div class="txt">Career</div>
						  </a>
                    </li>
                    <li><a href="#"><i class="icofont-building-alt icofont-2x"></i><br />
                        <div class="txt">Infrastructure</div>
						</a>
                    </li>
                    <li><a href="#"><i class="icofont-team icofont-2x"></i><br />
                        <div class="txt">Team</div>
						</a>
                    </li>
                     <li><a href="sucess-story.php"><i class="icofont-notebook icofont-2x"></i><br />
                        <div class="txt">Our Case Study</div>
						</a>
                    </li>
                     
             </ul>



            </li>
    
            <li><a class="noflyout selected" href="contact-us.php"><i class="fas fa-envelope"><br>Contact US</i></a></li>

                    
            <li><a class="" href="https://primacyinfotech.com/"><i class="fas fa-home"><br>Home</i></a></li>

            <li><a href="#"><i class="fas fa-server"><br>
                        Service</i></a>
                <ul class="my-col-2">
                  
                     <li><a href="web-development.php"><img src="images/software.png"><br />
                        <div class="txt">Software Development</div>
                        </a>
                    </li>
                    <li>
                       <a href="web-development.php"><img  src="images/web-devewlopemntt.png"><br />
                        <div class="txt">Web Development</div>
						</a>
                    </li>
                        <li><a href="web-designing.php"><img src="images/web-design-24.png">
                            
                            <div class="txt">Web Designing</div>
                        </a>
                    </li>
                      <li><a href="mobile-application.php"><img src="images/app-development.png"><br />
                        <div class="txt">Apps Development</div>
						  </a>
                    </li>
               
                    <li><a href="crm-erp.php"><img src="images/dynamics-crm.png"><br />
                        <div class="txt">CRM & ERP</div>
						</a>
                    </li>
                  
                    
                     <li><a href="digital-marketing.php"><img src="images/seo.png"><br />
                        <div class="txt">Digital Marketing</div>
						 </a>
                    </li>
                  
                    <li><a href="ui-ux.php"><img src="images/ui-design.png"><br />
                        <div class="txt">UI/UX Design</div>
						</a>
                    </li>
              
                      <li><a href="portal-development.php"><img width="24" height="24" src="images/portal.png"><br />
                        <div class="txt">Portal Development</div>
						  </a>
                    </li>
                    <li><a href="ecommerce-development.php"><img src="images/ecommerce.png"><br />
                        <div class="txt">Ecommerce Development</div>
						</a>
                    </li>
           
                    
                
                     




                </ul>

            </li>
                     <li><a href="#"><i class="fas fa-server"><br>
                        Solution</i></a>
                <ul class="my-col-2">
                    <li><a target="_blank" href="http://www.travelbusinessportal.com/"><img src="images/software.png"><br />
                        <div class="txt">Travel Portal</div>
                        </a>
                    </li>
                    <li>
                       <a href="school-mangement.php"><img  src="images/schooll.png"><br />
						   <div class="txt">School Management</div></a>
                    </li>
                      <li><a href="loan.php"><img src="images/app-development.png"><br />
						  <div class="txt">Loan Management</div></a>
                    </li>
                    <li><a href="health.php"><img src="images/wordpress.png"><br />
						<div class="txt">Healthcare Management</div></a>
                    </li>
                    <li><a href="mlm.php"><img src="images/dynamics-crm.png"><br />
						<div class="txt">MLM</div></a>
                    </li>
                     <li><a href="ecommerce-development.php"><img src="images/ecommerce.png">
                            
                            <div class="txt">Readymade Ecommerce</div>
                        </a>
                    </li>
                    
                     
                    
                
                     




                </ul>

            </li>
            
                <li><a href="#"><i class="fas fa-server"><br>
                        Industry</i></a>
                <ul class="my-col-2">
                    <li><a href="#"><img src="images/software.png"><br />
                        <div class="txt">Healthcare</div>
                        </a>
                    </li>
                    <li>
                       <a target="_blank" href="http://www.travelbusinessportal.com/"><img  src="images/web-devewlopemntt.png"><br />
                        <div class="txt">Travel</div>
						</a>
                    </li>
                      <li><a href="#"><img src="images/app-development.png"><br />
                        <div class="txt">Financial</div>
						  </a>
                    </li>
                    <li><a href="#"><img src="images/wordpress.png"><br />
                        <div class="txt">Retail</div>
						</a>
                    </li>
                    <li><a href="#"><img src="images/dynamics-crm.png"><br />
                        <div class="txt">Insurance</div>
						</a>
                    </li>
                     <li><a href="#"><img src="images/web-design-24.png">
                            
                            <div class="txt">Banking</div>
                        </a>
                    </li>
                      <li><a href="#"><img src="images/web-design-24.png">
                            
                            <div class="txt">Goverment</div>
                        </a>
                    </li>
                      <li><a href="#"><img src="images/web-design-24.png">
                            
                            <div class="txt">Media </div>
                        </a>
                    </li>
                    
                    
                     
                    
                
                     




                </ul>

            </li>
            
            
            
            <li><a href="#"><i class="fas fa-paper-plane"><br>
                        About us</i></a>
                        
                <ul class="my-col-2">
                    <li><a href="why-us.php"><img src="images/team.png"><br />
                        <div class="txt">Why Us</div>
                        </a>
                    </li>
                    <li>
                       <a href="our-company.php"><img  src="images/group.png"><br />
                        <div class="txt">Company</div>
						</a>
                    </li>
                      <li><a href="career.php"><img src="images/success.png"><br />
                        <div class="txt">Career</div>
						  </a>
                    </li>
                    <li><a href="#"><img src="images/infrastructure.png"><br />
                        <div class="txt">Infrastructure</div>
						</a>
                    </li>
                    <li><a href="#"><img src="images/group.png"><br />
                        <div class="txt">Team</div>
						</a>
                    </li>
                     <li><a href="sucess-story.php"><img src="images/dynamics-crm.png"><br />
                        <div class="txt">Our Case Study</div>
						</a>
                    </li>
                     
             </ul>



            </li>

            <li><a class="noflyout selected" href="contact.php"><i class="fas fa-envelope"><br>Contact US</i></a></li>

        </ul>
    </div>
-->


<!--My fixed header-->

		<div class="top-bar">
			<div class="c-mob2">
				<ul class="c-mob-3">
					<li><img src="../assets/images/inddd.png" alt="india"></li>
					<li><a href="tel:+91 9088015866" class="">+91 9088015866</a></li>
					<li><a href="tel:+91 9088015865" class="">/65</a></li>


					<li><img width="16" height="11" src="../assets/images/canada-flag-xs.png" alt="canada"></li> &nbsp;
					<li> <a href="tel:+16474908004" class="Blondie-email">+1 6474908004</a></li> 
 


					<li><img width="16" height="11" src="../assets/images/bangladesh-flag-xs.png" alt="bangladesh"></li> &nbsp;
					<li><a href="tel:+88 01759787636" class="Blondie-email">+88 01759787636</a></li>
				</ul>

			</div>
		</div>

<div class="top"> 
	<div class="container">
		<div class="row">
			<div class="col-md-3 pic0"><a href="../index.php"><img src="../assets/images/logo-p.png" alt="primacy logo"></a></div>
			<div class="col-md-7">
<!--				<div class="col-md-12">-->
					<div class="c-mob">
						<div class="col-md-4">
							<img src="../assets/images/inddd.png" alt="india">&nbsp;
							<a href="tel:+91 9088015866" class="">+91 9088015866</a>
							<a href="tel:+91 9088015865" class="">/65</a>
						</div>
						<div class="col-md-4">
							<img width="16" height="11" src="../assets/images/canada-flag-xs.png" alt="canada"> &nbsp;
							<a href="tel:+16474908004" class="Blondie-email">+1 6474908004</a>
   
						</div>
						<div class="col-md-4">
							<img width="16" height="11" src="../assets/images/bangladesh-flag-xs.png" alt="bangladesh"> &nbsp;
							<a href="tel:+88 01759787636" class="Blondie-email">+88 01759787636</a>

						</div>
					</div>
<!--				</div>-->
			</div>
			<div class="col-md-2 dropdown ">
				<button class="my-button my-button2 dropdown-toggle pull-right" type="button" data-toggle="dropdown"><i class="fas fa-globe"></i>&nbsp;Global

					<span class="caret"></span></button>
				<ul class="dropdown-menu pull-right">
					<li><a href="https://www.primacyinfotech.in/"><span><img src="../assets/images/inddd.png" alt="india"> &nbsp;India</span></a></li>
					<li><a href="https://ca.primacyinfotech.com/"><span><img width="16" height="11" src="../assets/images/canada-flag-xs.png" alt="india"> &nbsp;Canada</span></a></li>
					<li><a href="http://bd.primacyinfotech.com/"><span><img width="16" height="11" src="../assets/images/bangladesh-flag-xs.png" alt="india"> &nbsp;Bangladesh</span></a></li>
				</ul>
			</div>

		</div>
	</div>
</div>



<!--end fixed header-->
  <!--side menuu on desktop-->
	  <div id="menuwrapper">
        <ul id="sidemenu">
            <li><a class="" href="../index.php"><i class="fas fa-home"><br>Home</i></a></li>

            <li><a href="#"><i class="fas fa-server"><br>
                        Service</i></a>
                <ul class="my-col-2">
<!--
                    <li><a href="web-developemnt.php"><img src="assets/images/small/software.png"><br />
                        <div class="txt">Software Development</div>
                        </a>
                    </li>
-->
                    <li>
                       <a href="../service/web-developement.php"><i class="icofont-code icofont-2x"></i><br />
                        <div class="txt">Web Development</div>
						</a>
                    </li>
                        <li><a href="../service/web-designing.php"><i class="icofont-dashboard-web icofont-2x"></i>
                            
                            <div class="txt">Web Designing</div>
                        </a>
                    </li>
                      <li><a href="../service/mobile-app-developemnt.php"><i class="icofont-brand-android-robot icofont-2x"></i><br />
                        <div class="txt">Apps Development</div>
						  </a>
                    </li>
               
                    <li><a href="../service/crm-erp-portal-development%20.php"><i class="icofont-computer icofont-2x"></i><br />
                        <div class="txt">CRM & ERP</div> 
						</a>
                    </li>
                  
                    
                     <li><a href="../service/digital-marketing.php"><i class="icofont-automation icofont-2x"></i><br />
                        <div class="txt">Digital Marketing</div>
						 </a>
                    </li>
                  
                    <li><a href="../service/ui-ux%20Desing.php"><i class="icofont-penalty-card icofont-2x"></i><br />
                        <div class="txt">UI/UX Design</div>
						</a>
                    </li>
              
                 
                    <li><a href="ecommerce-development.html"><i class="icofont-shopping-cart icofont-2x"></i><br />
                        <div class="txt">Ecommerce Development</div>
						</a>
                    </li>
                 
           
                    
                
                     




                </ul>

            </li>
<!--
            <a href="#"><i class="fas fa-server fas-2x"><br>
                        Solution</i></a>
-->
            <li><a href="#"><i class="fas fa-server"><br>
                        Solution</i></a>
                <ul class="my-col-2">
                    <li><a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel Portal</div>
                        </a>
                    </li>
                    <li>
                       <a href="../product/school-managmest-system.php"><i class="icofont-building-alt icofont-2x"></i><br />
						   <div class="txt">School Management</div></a>
                    </li>
                       <li><a href="../product/portal-accounting.php"><i class="icofont-paper icofont-2x"></i><br />
						<div class="txt">Accounting</div></a>
                    </li>

                </ul>

            </li>
              <li><a href="#"><i class="fas fa-server"><br>
                        Product</i></a>
                <ul class="my-col-2">
                          <li><a href="../product/readymade-food-delivery-app.php"><i class="icofont-fast-food icofont-2x"></i><br />
                        <div class="txt">Food Delhivery App</div> 
						</a>
                    </li>
                      <li><a href="../product/readymade-grocery-delivery-app.php"><i class="icofont-grocery icofont-2x"></i><br />
                        <div class="txt">Grocery Shop</div> 
						</a>
                    </li>
                       <li><a href="../product/recharge-bill-payment-portal-b2b-b2c.php"><i class="icofont-brand-china-mobile icofont-2x"></i><br />
                        <div class="txt">Recharge Portal</div> 
						</a>
                    </li>

                      <li>
                       <a href="../product/readymade-online-education-app.php"><i class="icofont-learn icofont-2x"></i><br />
						   <div class="txt">Learning Management</div></a>
                    </li>
                      <li><a href="../product/loan-mangment-system.php"><i class="icofont-money-bag icofont-2x"></i><br />
						  <div class="txt">Loan Management</div></a> 
                    </li>
                    <li><a href="portal-health.html"><i class="icofont-doctor icofont-2x"></i><br />
						<div class="txt">Healthcare Management</div></a>
                    </li>
                    <li><a href="../service/mlm-software-development%20.php"><i class="icofont-company icofont-2x"></i><br />
						<div class="txt">MLM Software</div></a>
                    </li>
                 
                     <li><a href="../product/readymade-video-streaming-app.php"><i class="icofont-video-cam icofont-2x"></i>
                            
                            <div class="txt">Video Portal</div>
                        </a>
                    </li>
                    <li><a href="../product/readymade-realestate-portal.php"><i class="icofont-search-property icofont-2x"></i>
                            
                            <div class="txt">Realestate</div>
                        </a>
                    </li>
                     <li><a href="../product/readymade-cab-booking%20app.php"><i class="icofont-car-alt-1 icofont-2x"></i>
                            
                            <div class="txt">OLA/Uber Clone</div>
                        </a>
                    </li>
                    
                     
                    
                
                     




                </ul>

            </li>
            
                <li><a href="#"><i class="fas fa-industry"><br>
                        Industry</i></a>
                <ul class="my-col-2">
                    <li><a href="../industry/industry-healthcare.php"><i class="icofont-doctor icofont-2x"></i><br />
                        <div class="txt">Healthcare</div>
                        </a>
                    </li>
                    <li>
                       <a target="_blank" href="http://www.travelbusinessportal.com/"><i class="icofont-airplane-alt icofont-2x"></i><br />
                        <div class="txt">Travel</div>
						</a>
                    </li>
                      <li><a href="../industry/industry-education.php"><i class="icofont-paper icofont-2x"></i><br />
                        <div class="txt">Financial</div>
						  </a>
                    </li>
                    <li><a href="../industry/industry-retail.php"><i class="icofont-ui-cart icofont-2x"></i><br />
                        <div class="txt">Retail</div>
						</a>
                    </li>
                    <li><a href="../industry/industry-insurance.php"><i class="icofont-holding-hands icofont-2x"></i><br />
                        <div class="txt">Insurance</div>
						</a>
                    </li>
                     <li><a href="../industry/industry-bankin-finance.php"><i class="icofont-bank icofont-2x"></i>
                            
                            <div class="txt">Banking</div>
                        </a>
                    </li>
                      <li><a href="../industry/industry-goverment.php"><i class="icofont-man-in-glasses icofont-2x"></i>
                            
                            <div class="txt">Goverment</div>
                        </a>
                    </li>
                      <li><a href="../industry/industry-media.php"><i class="icofont-newspaper icofont-2x"></i>
                            
                            <div class="txt">Media </div>
                        </a>
                    </li>
                    
                    
                     
                    
                
                     




                </ul>

            </li>
            
            
            
            <li><a href="#"><i class="fas fa-paper-plane"><br>
                        About us</i></a>
                        
                <ul class="my-col-2">
                    <li><a href="#"><i class="icofont-question-square icofont-2x"></i><br />
                        <div class="txt">Why Us</div>
                        </a>
                    </li>
                    <li>
                       <a href="our-company.php"><i class="icofont-building icofont-2x"></i><br />
                        <div class="txt">Company</div>
						</a>
                    </li>
                      <li><a href="career.php"><i class="icofont-search-job icofont-2x"></i><br />
                        <div class="txt">Career</div>
						  </a>
                    </li>
                    <li><a href="#"><i class="icofont-building-alt icofont-2x"></i><br />
                        <div class="txt">Infrastructure</div>
						</a>
                    </li>
                    <li><a href="#"><i class="icofont-team icofont-2x"></i><br />
                        <div class="txt">Team</div>
						</a>
                    </li>
                     <li><a href="#"><i class="icofont-notebook icofont-2x"></i><br />
                        <div class="txt">Our Case Study</div>
						</a>
                    </li>
                     
             </ul>



            </li>
    
            <li><a class="noflyout selected" href="contact.php"><i class="fas fa-envelope"><br>Contact US</i></a></li>

        </ul>
        
    </div>
<!--end side menuu on desktop-->




<div class="nav-side-menu" id="slide_menu2" style="display:none;">



    <div class="brand">Menu</div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                <li>
                  <a href="../index-2.html">
                  <i class="fa fa-dashboard fa-lg"></i> Home
                  </a>
                </li>

                <li  data-toggle="collapse" data-target="#products" class="collapsed active">
                  <a href="#"><i class="fa fa-gift fa-lg"></i> Services<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="products">
                    <li class="active"><a href="../service/web-developement.php">Web Development</a></li>
                           <li><a href="../service/web-designing.php">Web Designing</a>
                    </li>
                    <li>
                        <a href="../service/mobile-app-developemnt.php">Apps Development</a>
                    </li>
                      <li><a href="../service/crm-erp-portal-development%20.php">CRM & ERP</a>
                    </li>
                  
                       <li><a href="../service/digital-marketing.php">Digital Marketing</a>
                    </li>
                       <li><a href="../service/ui-ux%20Desing.php">UI/UX Design</a>
                    </li>
					<li><a href="ecommerce-development.html">Ecommerce Development</a></li>
               
                       
               
                  
                  
                    
                     
                </ul>


                <li data-toggle="collapse" data-target="#service2" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> Solution <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="service2">
                        <li class="active"><a href="http://www.travelbusinessportal.com/">Travel Portal</a></li>
                           <li><a href="../product/school-managmest-system.php">School Management</a>
                    </li>
                    <li><a href="../product/portal-accounting.php">Accounting</a>
                    </li>
                        
                      
                </ul>
                 <li data-toggle="collapse" data-target="#service" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> Product <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="service">
                          
                        <li><a href="../product/readymade-food-delivery-app.php">Food Delhivery App</a>
                    </li>
                           <li><a href="../product/readymade-grocery-delivery-app.php">Grocery Shop</a>
                    </li>
                        <li><a href="../product/recharge-bill-payment-portal-b2b-b2c.php">Recharge Portal</a>
                    </li>
                        
                     <li><a href="../product/readymade-online-education-app.php">Learning Management</a>
                    </li>
                        <li><a href="../product/loan-mangment-system.php">Loan Management</a>
                    </li>
                   
                   
                       <li><a href="portal-health.html">Healthcare Management</a>
                    </li>
                       <li><a href="../service/mlm-software-development%20.php">MLM Software</a>
                    </li>
                    
                        <li><a href="../product/readymade-video-streaming-app.php">Video Portal</a>
                    </li>
                       <li><a href="../product/readymade-realestate-portal.php">Realestate</a>
                    </li>
                       <li><a href="../product/portal-ola-2.php">OLA/Uber Clone</a>
                    </li>
                        
                      
                </ul>
                
                <li data-toggle="collapse" data-target="#about" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> Industry<span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="about">
                   
                           <li><a href="../industry/industry-healthcare.php">Healthcare</a>
                    </li>
                      <li><a href="../industry/industry-travel.php">Travel</a>
                    </li>
                      <li><a href="../industry/industry-education.php">Financial</a>
                    </li>
                       <li><a href="../industry/industry-retail.php">Retail</a>
                    </li>
                    <li><a href="../industry/industry-insurance.php">Insurance</a>
                    </li>
                    <li><a href="../industry/industry-bankin-finance.php">Banking</a>
                    </li>
                      <li><a href="../industry/industry-goverment.php">Goverment</a>
                    </li>
                    <li><a href="../industry/industry-media.php">Media</a>
                    </li>
                     
                      
                </ul>
                
                
<!--
                <li data-toggle="collapse" data-target="#about" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> Industry<span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="about">
                   
                           <li><a href="why-us.php">Why Us</a>
                    </li>
                      <li><a href="our-company.php">Company</a>
                    </li>
                      <li><a href="career.php">Career</a>
                    </li>
                       <li><a href="#">Infrastructure</a>
                    </li>
                    <li><a href="#">Team</a>
                    </li>
                    <li><a href="industry-media.php">Media</a>
                    </li>
                     
                      
                </ul>
-->
                <li data-toggle="collapse" data-target="#about3" class="collapsed">
                  <a href="#"><i class="fa fa-globe fa-lg"></i> About Us <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="about3">
                   
<!--                           <li><a href="why-us.php">Why Us</a>-->
                   <li><a href="#">Why Us</a>
                    </li>
                      <li><a href="our-company.php">Company</a>
                    </li>
                      <li><a href="career.php">Career</a>
                    </li>
                       <li><a href="#">Infrastructure</a>
                    </li>
                    <li><a href="#">Team</a>
                    </li>
                    <li>
<!--                    <a href="sucess-story.php">Our Case Study</a>-->
                   <a href="#">Our Case Study</a>
                    </li>
                     
                      
                </ul>
               <!--   <li>
                  <a href="about.php">
                  <i class="fa fa-user fa-lg"></i> About Us
                  </a>
                  </li>-->
<!-- vb
                 <li>
                  <a href="our-company.php">
                  <i class="fa fa-user fa-lg"></i> Company
                  </a>
                  </li>
-->

                 <li>
                  <a href="contact.php">
                  <i class="fa fa-users fa-lg"></i> Contact us
                  </a>
                </li>
            </ul>
     </div>
     	<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="https://www.facebook.com/primacyit/"><i class="fab fa-facebook-f"></i></a></li>
						<li class="list-inline-item"><a href="https://api.whatsapp.com/send?phone=919875627563"><i class="fab fa-whatsapp"></i></a></li>

						<li class="list-inline-item"><a href="https://in.linkedin.com/company/primacy-infotech-pvt-ltd"><i class="fab fa-linkedin-in"></i></a></li>
						<!--<li class="list-inline-item"><a href=""><i class="fab fa-skype"></i></a></li>
-->
						<li class="list-inline-item"><a href="mailto:info@primacyinfotech.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
</div>

<div class="split-slideshow">
	<div class="slideshow">
		<div class="slider">

			<div class="item">
				<section class="still">
					<div class="sfirst" id="home">


						<div class="col-md-12">
							<h1>About us</h1><br>
							<p>Primacy Infotech as come a long way in the industry of internet marketing. With our several years of experience we understand the changing needs of small businesses in their online promotions. .

								Primacy Infotech specializes in a variety of sectors like web designing, three-dimensional and two-dimensional animations, computer-based tutorials, brouchure, multimedia presentations, web-designing and software development.
                             </p>

						</div>




					</div>
				</section>
			</div>

			<div class="item">
				<section class="still">
					<div class="sfirst" id="home">


						<div class="col-md-12">
							<h1>Company intro</h1><br>
							<p>We introduce ourselves as Primacy Infotech IT services and Products Company at KOLKATA. The company is promoted by a BE & MCA Professionals. Reliability & Optimality, and we specialize in developing high-impact software. We are looking to expand our team and operations.</p>
							<br>


						</div>




					</div>
				</section>
			</div>


			<div class="item">

				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="sheading">
								<h2>WHY CHOOSE US
								</h2>
								<br />
							</div>
						</div>
					</div>
					<div class="row">

						<div class="col-md-1"></div>
						<div class="col-md-10">
							<div id="mee3" class="owl-carousel owl-theme">

								<div class="up hvr-float-shadow">

									<div class="bg-back2 backk3">
										<h2>PASSIONATE
										</h2>
										<br/>
										<h5>We love nothing more that working on a great project with a fantastic client. We care about our clients and can often be found working out of hours to get everything ‘just right’!</h5>

									</div>



								</div>


								<div class="up hvr-float-shadow">
									<div class="bg-back2 backk3">
										<h2>CREATIVE & TECHNICAL
										</h2>
										<h5>Whether it’s website or graphic design,web design, web development or custom programming we like to keep everything under one roof to make it easier for our customers.
										</h5>
									</div>
								</div>


								<div class="up hvr-float-shadow">
									<div class="bg-back2 backk3">
										<h2>EXPERIENCE</h2>

										<h5>As a company we have been trading since 2012. We love discussing and planning new projects and have years of knowledge and experience that we bring to the table.Our technical team are so experience.
										</h5>

									</div>


								</div>
								<div class="up hvr-float-shadow">
									<div class="bg-back2 backk3">
										<h2>AFFORDABLE COST
										</h2>

										<h5>Our goal is to provide complete, tailor-made internet presence solutions and flexible packages to match your corporate needs.We provide Websites in affordable rate.Our website making cost is low than any other company.

										</h5>

									</div>


								</div>
							</div>
							<div class="col-md-1"></div>
						</div>


					</div>
				</div>

			</div>




			<div class="item">

				<div class="container">
					<div class="row">

						<div class="col-md-12">
							<div class="sheading">
								<h2>Website Design Process</h2>
							</div>
						</div>
					</div>
					<div class="row">

						<div class="col-md-1 "></div>
						<div class="col-xs-12 col-md-11">





							<div class="flex-container">
								<div>
									<img src="../images/thumnail/development/esyly-custo.png">
									<h5>PLAN IT
									</h5>
								</div>
								<div class="imn">
									<img src="../images/thumnail/development/user.png">
									<h5>DESIGN IT
									</h5>
								</div>
								<div class="imn">
									<img src="../images/thumnail/development/suport-1.png">
									<h5>DEVELOP IT
									</h5>
								</div>
								<div>
									<img src="../images/thumnail/development/user.pn_.png">
									<h5>LAUNCH IT
									</h5>
								</div>
								<div class="imn">
									<img src="../images/thumnail/development/rupress.png">
									<h5>PROMOTE IT
									</h5>
								</div>
								<div class="imn">
									<img src="../images/thumnail/development/des.png">
									<h5>MAINTAIN IT
									</h5>
								</div>


							</div>







						</div>
						<div class="col-md-1"></div>
					</div>


				</div>
			</div>


		





			<!--   contact  -->

		</div>
	</div>
</div>
<!--        <div class="slideshow-text">

            <div class="item">PRIMACY INFOTECH
            </div>

            <div class="item"></div>
            <div class="item"></div>
        </div>-->

<!--footer my-->
<style>
	i.fas.fa-mobile-alt {
		color: #fff;
	}
</style> 
<footer>
	
<!--
	<div class="menu-footer">

		<ul class="menu2">
			<li><a class="" href="index.php"><i class="fas fa-home">&nbsp;Home</i></a></li> 
			<li><a href="about.php"><i class="fas fa-paper-plane">&nbsp;
						About us</i></a></li>

			<li><a class="noflyout selected" href="our-company.php"><i class="fas fa-building">&nbsp;Company</i></a></li>
			<li><a class="noflyout selected" href="contact.php"><i class="fas fa-envelope">&nbsp;Contact US</i></a></li>
			<li class="menu-icon"><img src="images/icon_footer-toggle.png"></li>



		</ul>
	</div>

	<div class="footer-mega-menu">
		<section id="footer">
			<div class="container-fluid">

				<div class="col-xs-12 col-sm-3 col-md-2">
					<h5>Our Services</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">
						<li><a href="web-development.php"><i class="fa fa-angle-double-right"></i>Web Development</a></li>

						<li><a href="web-designing.php"><i class="fa fa-angle-double-right"></i>Web Designing</a></li>
						<li><a href="mobile-application.php"><i class="fa fa-angle-double-right"></i>Mobile Apps Development</a></li>
						<li><a href="crm-erp.php"><i class="fa fa-angle-double-right"></i>CRM & ERP</a></li>
						<li><a href="digital-marketing.php"><i class="fa fa-angle-double-right"></i>Digital Marketing</a></li>
			      <li><a href="ui-ux.php"><i class="fa fa-angle-double-right"></i>UI/UX Design</a>
                    </li>
                 
                
				
					</ul>
				</div>
				<div class="col-xs-12 col-sm-3 col-md-2">
					<h5>Our Solutions</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">
							<li><a target="_blank" href="http://www.travelbusinessportal.com/">Travel Portal
									</a>
								</li>
								<li>
								   <a href="school-mangement.php"><i class="fa fa-angle-double-right"></i>School Management</a>
								</li>
								  <li><a href="#"><i class="fa fa-angle-double-right"></i>Loan Management</a>
								</li>
								<li><a href="#"><i class="fa fa-angle-double-right"></i>Healthcare Management</a>
								</li>
								<li><a href="mlm.php"><i class="fa fa-angle-double-right"></i>MLM</a>
								</li>
						<li><a href="http://makeyourecommerce.com"><i class="fa fa-angle-double-right"></i>Readymade Ecommerce</a>
								</li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-3 col-md-2">
					<h5>Quick links</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">
						<li><a href="index.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="about.php"><i class="fa fa-angle-double-right"></i>About</a></li>
						<li><a href="our-company.php"><i class="fa fa-angle-double-right"></i>Company</a></li>
						<li><a href="privacy-policy.php"><i class="fa fa-angle-double-right"></i>Privacy Policy</a></li>
						<li><a href="terms-of-service.php"><i class="fa fa-angle-double-right"></i>Terms & Condition</a></li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-3 col-md-5">
					<h5>Address</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">

						<li><a href="https://wwww.primacyinfotech.in"><span><img src="images/inddd.png" alt="india"> &nbsp;BF 79,BF Block ,Sector I,Salt Lake, Kolkata-64,WB,India</span></a></li>
						<li><i class="fas fa-mobile-alt"></i>&nbsp;
							<a href="tel:+9088015866">9088015866</a>
							<a href="tel:+9088015865">/65</a>
						</li>

						<li><a href="https://wwww.primacyinfotech.in"><span><img width="20" height="15" src="images/canada-flag-xs.png" alt="india"> &nbsp;Primacy Infotech Inc.
									4656 Full Moon Circle
									Mississauga ON </span></a></li>
						<li><i class="fas fa-mobile-alt"></i>&nbsp;
							 <a href="tel:+1 4169999429" class="Blondie-email"> +16474908004</a>
						
						</li>
						<li><a href="https://wwww.primacyinfotech.in"><span><img width="20" height="15" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;31, KR PLAZA,Purana Paltan, Dhaka-1000
								</span></a></li>
						<li><i class="fas fa-mobile-alt"></i>&nbsp;
							<a href="tel:+8801759787636">+88 01759787636</a>
							<a href="tel:+9088015865">/65</a>
						</li>
					</ul>
				</div>
				<div class="col-xs-1 col-sm-1 col-md-1">
					<div class="menu-icon2">
						<img src="images/icon_footer-toggle.png">


					</div>
				</div>
			</div>
			<br /><br />
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-whatsapp"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fab fa-skype"></i></a></li>
						<li class="list-inline-item"><a href="" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>
			<br />
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">

					<p class="copyright">&copy 2019 All right Reversed.<a class="text-green ml-2" href="https://primacyinfotech.com/" target="_blank">Primacy Infotech Inc.</a></p>
				</div>
				<hr>

			</div>
		</section>
	</div>
	
-->
		
		
		
		
		<div class="menu-footer">

		<ul class="menu2">
			<li><a class="" href="../index-2.html"><i class="fas fa-home">&nbsp;Home</i></a></li>
			<li><a href="about.php"><i class="fas fa-paper-plane">&nbsp;
						About us</i></a></li>

			<li><a class="noflyout selected" href="our-company.php"><i class="fas fa-building">&nbsp;Company</i></a></li>
			<li><a class="noflyout selected" href="contact.php"><i class="fas fa-envelope">&nbsp;Contact US</i></a></li>
			<li class="menu-icon"><img src="../assets/images/icon_footer-toggle.png"></li>



		</ul>
	</div>

	<div class="footer-mega-menu">
		<section id="footer">
			<div class="container-fluid">
               <div class="row">
				<div class="col-12 col-sm-3 col-md-2">
					<h5>Our Services</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">
						<li><a href="../service/web-developement.php"><i class="fa fa-angle-double-right"></i>Web Development</a></li>

						<li><a href="../service/web-designing.php"><i class="fa fa-angle-double-right"></i>Web Designing</a></li>
						<li><a href="../service/mobile-app-developemnt.php"><i class="fa fa-angle-double-right"></i>Mobile Apps Development</a></li>
						<li><a href="../service/crm-erp-portal-development%20.php"><i class="fa fa-angle-double-right"></i>CRM & ERP</a></li>
						<li><a href="../service/digital-marketing.php"><i class="fa fa-angle-double-right"></i>Digital Marketing</a></li>
			      <li><a href="../service/ui-ux%20Desing.php"><i class="fa fa-angle-double-right"></i>UI/UX Design</a>
                    </li>
                 
                
				
					</ul>
				</div>
				<div class="col-12 col-sm-3 col-md-2">
					<h5>Our Portal</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">
							<li><a target="_blank" href="http://www.travelbusinessportal.com/"><i class="fa fa-angle-double-right"></i>Travel Portal
									</a>
								</li>
								<li>
								   <a href="../product/school-managmest-system.php"><i class="fa fa-angle-double-right"></i>School Management</a>
								</li>
								  <li><a href="../product/loan-mangment-system.php"><i class="fa fa-angle-double-right"></i>Loan Management</a>
								</li>
								<li><a href="portal-health.html"><i class="fa fa-angle-double-right"></i>Healthcare Management</a>
								</li>
								<li><a href="../service/mlm-software-development%20.php"><i class="fa fa-angle-double-right"></i>MLM</a>
								</li>
						<li><a href="../product/readymade-realestate-portal.php"><i class="fa fa-angle-double-right"></i>Real Estate</a>
						<li><a href="../product/portal-accounting.php"><i class="fa fa-angle-double-right"></i>Accounting</a>
							
								</li>
					</ul>
				</div>
				<div class="col-12 col-sm-3 col-md-2">
					<h5>Quick links</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">
						<li><a href="../index-2.html"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="about.php"><i class="fa fa-angle-double-right"></i>About</a></li>
						<li><a href="our-company.php"><i class="fa fa-angle-double-right"></i>Company</a></li>
						<li><a href="privacy-policy.php"><i class="fa fa-angle-double-right"></i>Privacy Policy</a></li>
						<li><a href="terms-of-service.php"><i class="fa fa-angle-double-right"></i>Terms & Condition</a></li>
					</ul>
				</div>
				<div class="col-12 col-sm-3 col-md-5">
					<h5>Address</h5>
					<hr class="line">
					<ul class="list-unstyled quick-links">

						<li><a href="https://wwww.primacyinfotech.in/"><span><img src="../images/inddd.png" alt="india"> &nbsp;BF 79,BF Block ,Sector I,Salt Lake, Kolkata-64,WB,India</span></a></li>
						<li><i class="fas fa-mobile-alt"></i>&nbsp;
							<a href="tel:+9088015866">9088015866</a>
							<a href="tel:+9088015865">/65</a>
						</li>

						<li><a href="https://wwww.primacyinfotech.in/"><span><img width="20" height="15" src="../images/canada-flag-xs.png" alt="india"> &nbsp;Primacy Infotech Inc.
									4656 Full Moon Circle
									Mississauga ON</span></a></li>
						<li><i class="fas fa-mobile-alt"></i>&nbsp;
							 <a href="tel:+1 4169999429" class="Blondie-email">+1 6474908004</a>
						
						</li>
						<li><a href="https://wwww.primacyinfotech.in/"><span><img width="20" height="15" src="../images/bangladesh-flag-xs.png" alt="india"> &nbsp;31, KR PLAZA,Purana Paltan, Dhaka-1000
								</span></a></li>
						<li><i class="fas fa-mobile-alt"></i>&nbsp;
							<a href="tel:+8801759787636">+88 01759787636</a> 
<!--							<a href="tel:+9088015865">/65</a>-->
						</li>
					</ul>
				</div>
				<div class="col-1 col-sm-1 col-md-1">
					<div class="menu-icon2">
						<img src="../assets/images/icon_footer-toggle.png">


					</div>  
				</div>
			    </div>
			</div>
			<br /><br />
			<div class="row">
				<div class="col-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="https://www.facebook.com/primacyit/"><i class="fab fa-facebook-f"></i></a></li>
						<li class="list-inline-item"><a href="https://api.whatsapp.com/send?phone=919875627563"><i class="fab fa-whatsapp"></i></a></li>
						<li class="list-inline-item"><a href="https://in.linkedin.com/company/primacy-infotech-pvt-ltd"><i class="fab fa-linkedin-in"></i></a></li>
<!--						<li class="list-inline-item"><a href=""><i class="fab fa-skype"></i></a></li>-->
						<li class="list-inline-item"><a href="mailto:info@primacyinfotech.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>
			<br />
			<div class="row">
				<div class="col-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">

					<p class="copyright">&copy 2019 All right Reversed.<a class="text-green ml-2" href="../index.php" target="_blank">Primacy Infotech Inc.</a></p>
				</div>
				<hr>

			</div>
		</section>
	</div>
</footer>
<!--end-->




<!--mobile footer-->
<!--
<div class="footer-navbar animated fadeInUp">
	<a href="#" onclick="open_menu()"> <i class="fas fa-ellipsis-h"></i></a>
	<a href="https://api.whatsapp.com/send?phone=919088015865&text=Hi%20Team%20PrimacyInfotech.com!%20I%20was%20just%20viewing%20your%20website%20and%20am%20interested%20in%20knowing%20more%20about%20your%20Services" class="active"><i class="fab fa-whatsapp"></i></a>

	<a href="tel:+919088015866" class="skype"><i class="fa fa-phone"></i></a>
	<a href="mailto:info@primacyinfotech.com" class="phone"><i class="fa fa-envelope"></i></a>
	
	<div class="dropup">
    <button class="btn btn-default btn-danger btn-sm dropdown-toggle my-toogle" type="button" data-toggle="dropdown">Global
    <span class="caret"></span></button>
    <ul class="dropdown-menu mena">
      <li><a href="https://www.primacyinfotech.in"><span><img src="images/inddd.png" alt="india"> &nbsp;India</span></a></li>
					  <li><a href="https://www.ca.primacyinfotech.com"><span><img width="16" height="11" src="images/canada-flag-xs.png" alt="india"> &nbsp;Canada</span></a></li>
					  <li><a href="https://bd.primacyinfotech.com/"><span><img width="16" height="11" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;Bangladesh</span></a></li> 
    </ul>
  </div>



</div>
-->

<!--mobile footer-->

<!--mobile footer-->
<div class="footer-navbar animated fadeInUp">
	<a href="#" onclick="open_menu()"> <i class="fas fa-ellipsis-h"></i></a>
	<a href="https://api.whatsapp.com/send?phone=919088015865&amp;text=Hi%20Team%20PrimacyInfotech.com!%20I%20was%20just%20viewing%20your%20website%20and%20am%20interested%20in%20knowing%20more%20about%20your%20Services" class="active"><i class="fab fa-whatsapp"></i></a>
<!--	<a href="https://www.facebook.com/primacyit/" target="_blank" class="facebook"><i class="fab fa-facebook-f"></i></a>-->
	<!--<a href="skype:kabir52247?call" class="skype"><i class="fab fa-skype"></i></a>-->
	<a href="tel:+919088015866" class="skype"><i class="fa fa-phone"></i></a>
	<a href="mailto:info@primacyinfotech.com" class="phone"><i class="fa fa-envelope"></i></a>
	
<!--	<a id="global-dropdown" href="#" class="phone">Global</a>-->

<!--
		<ul id="my-global" style="display:none;">
		     <li><a href="https://wwww.primacyinfotech.in"><span><img src="images/inddd.png" alt="india"> &nbsp;India</span></a></li>
			 <li><a href="https://wwww.primacyinfotech.in"><span><img width="16" height="11" src="images/canada-flag-xs.png" alt="india"> &nbsp;Canada</span></a></li>
			<li><a href="https://wwww.primacyinfotech.in"><span><img width="16" height="11" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;Bangladesh</span></a>
			</li>
		</ul>
-->

	
<!--
			<div class="dropup">
    <button class="btn btn-default btn-danger btn-sm dropdown-toggle my-toogle" type="button" data-toggle="dropdown">Global
    <span class="caret"></span></button>
    <ul class="dropdown-menu mena">
      <li><a href="https://wwww.primacyinfotech.in"><span><img src="images/inddd.png" alt="india"> &nbsp;India</span></a></li>
					  <li><a href="https://wwww.primacyinfotech.in"><span><img width="16" height="11" src="images/canada-flag-xs.png" alt="india"> &nbsp;Canada</span></a></li>
					  <li><a href="https://wwww.primacyinfotech.in"><span><img width="16" height="11" src="images/bangladesh-flag-xs.png" alt="india"> &nbsp;Bangladesh</span></a></li>
    </ul>
  </div>
-->


</div>

<!--mobile footer-->

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/565b419c81505c8622dd95ea/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<!-- ....menu.... -->
<script>
	$(document).ready(function() {
		$('ul > li > ul').css('height', $(window).height() + 'px');
		$('#sidemenu').css('height', $(window).height() + 'px');
	});
</script>
<!--<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>-->
<script src='../cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.12/jquery.mousewheel.js'></script>
<script src='../cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js'></script>
<script src="../js/index.js"></script>




<script src="../maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script src="../js/my-js.js"></script>

<script>
	function open_menu() {
		//alert("hii");
		$('#slide_menu2').slideToggle('slow');
		//alert($('#ravi_1').val());
	}
</script>

<!-- particles-js -->
  <script src="../cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>
  <script>
/*	gallery */
$(document).ready(function(){

    $(".filter-button").click(function(){
        var value = $(this).attr('data-filter');
        
        if(value == "all")
        {
            $('.filter').show('1000');
        }
        else
        {
            $(".filter").not('.'+value).hide('3000');
            $('.filter').filter('.'+value).show('3000');
            
        }

	        	if ($(".filter-button").removeClass("active")) {
			$(this).removeClass("active");
		    }
		    	$(this).addClass("active");
	    	});
});
/*	end gallery */

$(document).ready(function(){
    $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
    });
});
   
  
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-147240416-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-147240416-1');
</script>



<!-- Go to www.addthis.com/dashboard to customize your tools -->
 <script type="text/javascript" src="../s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5d75ee21150e9a13"></script>
</body>


<!-- Mirrored from primacyinfotech.com/about.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jan 2020 10:50:32 GMT -->
</html>